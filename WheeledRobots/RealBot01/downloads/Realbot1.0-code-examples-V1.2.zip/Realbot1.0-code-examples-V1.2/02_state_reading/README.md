# 02 状态读取

`read_state.py` 读取 `/odom`、`/robot_driver/battery_state` 和 `/robot_slave/states`，不发布 Topic、不调用 Service，不写盘。

推荐在客户开发电脑的交付包根目录执行，通过 SSH 标准输入将脚本传给机器人端 Python，不在机器人留下脚本副本：

```bash
export ROBOT_IP=192.168.127.10
ssh "realman@${ROBOT_IP}" \
  "bash -lc 'source /opt/ros/humble/setup.bash &&
             source /home/realman/workspace/rm_robot_ws/install/setup.bash &&
             python3 - --timeout 10'" \
  < examples/02_state_reading/read_state.py
```

三类状态都输出非空样本且退出码为 `0` 才算通过。任一 Topic 超时时保留输出，先查 Topic 是否存在、类型和 QoS，不因只读失败自动重启机器人服务。
