#!/usr/bin/env python3
"""Read three verified Realbot1.0 state streams for at most ten seconds."""

from __future__ import annotations

import argparse
import json
import math
import time
from datetime import datetime, timezone
from typing import Any


TOPICS = {
    "odom": "/odom",
    "states": "/robot_slave/states",
    "battery": "/robot_driver/battery_state",
}
DEFAULT_TIMEOUT_SECONDS = 10.0
QOS_CONTRACT = {
    "history": "KEEP_LAST",
    "depth": 10,
    "reliability": "BEST_EFFORT",
    "durability": "VOLATILE",
}


def state_record(source: str, values: dict[str, Any]) -> dict[str, Any]:
    """Return one compact, machine-readable log record."""
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
        "event": "state_sample",
        "source": source,
        "values": values,
    }


def json_line(record: dict[str, Any]) -> str:
    return json.dumps(record, ensure_ascii=False, separators=(",", ":"))


def decode_states(data: str) -> dict[str, Any]:
    parsed = json.loads(data)
    if not isinstance(parsed, dict):
        raise ValueError("states payload must be a JSON object")
    result: dict[str, Any] = {}
    for name in ("arm_left", "arm_right", "body", "head"):
        section = parsed.get(name)
        if isinstance(section, dict):
            result[name] = {
                "position_millideg": section.get("position"),
                "joint_error": section.get("joint_err"),
                "system_error": section.get("sys_err"),
            }
    for name in ("hand_left", "hand_right"):
        section = parsed.get(name)
        if isinstance(section, dict):
            result[name] = {
                "position": section.get("position"),
                "system_state": section.get("sys_state"),
            }
    if not result:
        raise ValueError("states payload contains no recognized robot state sections")
    return result


def validate_timeout(value: float) -> float:
    timeout_seconds = float(value)
    if not math.isfinite(timeout_seconds) or not 0.0 < timeout_seconds <= DEFAULT_TIMEOUT_SECONDS:
        raise ValueError("timeout must be greater than 0 and at most 10 seconds")
    return timeout_seconds


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Read verified Realbot1.0 state topics")
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT_SECONDS)
    return parser


def run(timeout_seconds: float) -> int:
    timeout_seconds = validate_timeout(timeout_seconds)

    import rclpy
    from nav_msgs.msg import Odometry
    from rclpy.node import Node
    from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
    from rm_robot_interfaces.msg import RobotPower
    from std_msgs.msg import String

    qos = QoSProfile(
        history=HistoryPolicy.KEEP_LAST,
        depth=QOS_CONTRACT["depth"],
        reliability=ReliabilityPolicy.BEST_EFFORT,
        durability=DurabilityPolicy.VOLATILE,
    )

    class StateReader(Node):
        def __init__(self) -> None:
            super().__init__("realbot_state_reader")
            self.received: set[str] = set()
            self.create_subscription(Odometry, TOPICS["odom"], self.on_odom, qos)
            self.create_subscription(String, TOPICS["states"], self.on_states, qos)
            self.create_subscription(RobotPower, TOPICS["battery"], self.on_battery, qos)

        def emit_once(self, source: str, values: dict[str, Any]) -> None:
            if source in self.received:
                return
            self.received.add(source)
            self.get_logger().info(json_line(state_record(source, values)))

        def on_odom(self, message: Any) -> None:
            pose = message.pose.pose
            twist = message.twist.twist
            self.emit_once(
                "odom",
                {
                    "x_m": round(float(pose.position.x), 4),
                    "y_m": round(float(pose.position.y), 4),
                    "linear_x_m_s": round(float(twist.linear.x), 4),
                    "angular_z_rad_s": round(float(twist.angular.z), 4),
                },
            )

        def on_states(self, message: Any) -> None:
            try:
                values = decode_states(message.data)
            except (json.JSONDecodeError, ValueError) as exc:
                self.get_logger().error(
                    json_line({"event": "invalid_state_json", "error": str(exc)})
                )
                return
            self.emit_once("states", values)

        def on_battery(self, message: Any) -> None:
            self.emit_once(
                "battery",
                {
                    "total_voltage_raw": int(message.total_voltage),
                    "current_raw": int(message.current),
                    "remaining_capacity_raw": int(message.remain_capacity),
                    "remaining_percent": int(message.remain_percent),
                },
            )

    rclpy.init()
    node = StateReader()
    deadline = time.monotonic() + timeout_seconds
    try:
        while rclpy.ok() and time.monotonic() < deadline and len(node.received) < len(TOPICS):
            rclpy.spin_once(node, timeout_sec=min(0.2, max(0.0, deadline - time.monotonic())))
        missing = sorted(set(TOPICS) - node.received)
        if missing:
            node.get_logger().error(
                json_line({"event": "state_timeout", "timeout_seconds": timeout_seconds, "missing": missing})
            )
            return 2
        return 0
    except KeyboardInterrupt:
        node.get_logger().info(json_line({"event": "interrupted"}))
        return 130
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


def main() -> int:
    args = build_parser().parse_args()
    return run(args.timeout)


if __name__ == "__main__":
    raise SystemExit(main())
