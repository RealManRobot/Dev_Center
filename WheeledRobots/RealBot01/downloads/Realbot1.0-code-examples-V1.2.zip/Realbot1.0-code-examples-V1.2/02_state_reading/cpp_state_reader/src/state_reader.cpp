#include <chrono>
#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "rm_robot_interfaces/msg/robot_power.hpp"

using namespace std::chrono_literals;

class StateReader final : public rclcpp::Node {
 public:
  StateReader() : Node("realbot_cpp_state_reader") {
    auto qos = rclcpp::QoS(rclcpp::KeepLast(10))
                   .best_effort()
                   .durability_volatile();
    subscription_ = create_subscription<rm_robot_interfaces::msg::RobotPower>(
        "/robot_driver/battery_state", qos,
        [this](const rm_robot_interfaces::msg::RobotPower::SharedPtr message) {
          RCLCPP_INFO(get_logger(),
                      "battery total_voltage_raw=%u current_raw=%u "
                      "remaining_capacity_raw=%u remaining_percent=%u",
                      message->total_voltage, message->current,
                      message->remain_capacity, message->remain_percent);
          received_ = true;
        });
  }

  bool received() const { return received_; }

 private:
  bool received_{false};
  rclcpp::Subscription<rm_robot_interfaces::msg::RobotPower>::SharedPtr subscription_;
};

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  auto node = std::make_shared<StateReader>();
  const auto deadline = std::chrono::steady_clock::now() + 10s;
  while (rclcpp::ok() && !node->received() &&
         std::chrono::steady_clock::now() < deadline) {
    rclcpp::spin_some(node);
    rclcpp::sleep_for(20ms);
  }
  const bool success = node->received();
  if (!success) {
    RCLCPP_ERROR(node->get_logger(), "battery state timed out after 10 seconds");
  }
  rclcpp::shutdown();
  return success ? 0 : 2;
}
