#!/usr/bin/env python3
"""Virtual Pico UDP source for staged Realbot VR compatibility tests.

The emitted schema is the contract that the future Pico input adapter must
produce.  Network impairment options alter delivery only; packet timestamps
remain capture timestamps so the gateway can measure source age.
"""

from __future__ import annotations

import argparse
import heapq
import json
import math
import random
import socket
import time
from dataclasses import dataclass
from gateway_core import PICO_UDP_SCHEMA


@dataclass(order=True)
class ScheduledDatagram:
    send_at: float
    order: int
    payload: bytes


@dataclass(frozen=True)
class PoseSample:
    position_m: tuple[float, float, float]
    quaternion_xyzw: tuple[float, float, float, float]


def septic_scurve(progress: float) -> float:
    value = min(1.0, max(0.0, progress))
    return 35 * value**4 - 84 * value**5 + 70 * value**6 - 20 * value**7


def out_and_back_phase(elapsed: float, duration: float) -> float:
    half = duration / 2.0
    progress = elapsed / half if elapsed <= half else (duration - elapsed) / half
    return septic_scurve(progress)


def axis_angle_quaternion(axis: str, angle_deg: float) -> tuple[float, float, float, float]:
    half = math.radians(angle_deg) / 2.0
    sine = math.sin(half)
    vector = {
        "x": (sine, 0.0, 0.0),
        "y": (0.0, sine, 0.0),
        "z": (0.0, 0.0, sine),
    }[axis]
    return (*vector, math.cos(half))


def trajectory_sample(
    trajectory: str,
    elapsed: float,
    duration: float,
    distance_m: float,
    rotation_deg: float,
) -> PoseSample:
    elapsed = min(duration, max(0.0, elapsed))
    phase = out_and_back_phase(elapsed, duration)
    zero_q = (0.0, 0.0, 0.0, 1.0)
    if trajectory == "origin":
        return PoseSample((0.0, 0.0, 0.0), zero_q)
    if trajectory in ("x", "y", "z"):
        position = [0.0, 0.0, 0.0]
        position[{"x": 0, "y": 1, "z": 2}[trajectory]] = distance_m * phase
        return PoseSample(tuple(position), zero_q)  # type: ignore[arg-type]
    if trajectory == "xy":
        component = distance_m * phase / math.sqrt(2.0)
        return PoseSample((component, component, 0.0), zero_q)
    if trajectory == "circle":
        # Starts and ends at zero; maximum distance from the origin is distance_m.
        radius = distance_m / 2.0
        theta = 2.0 * math.pi * (elapsed / duration)
        return PoseSample(
            (radius * (1.0 - math.cos(theta)), radius * math.sin(theta), 0.0),
            zero_q,
        )
    if trajectory.startswith("rotation-"):
        axis = trajectory.rsplit("-", 1)[1]
        return PoseSample(
            (0.0, 0.0, 0.0), axis_angle_quaternion(axis, rotation_deg * phase)
        )
    raise ValueError(f"unsupported trajectory: {trajectory}")


def pico_packet(
    sequence: int,
    timestamp: float,
    sample: PoseSample,
    *,
    trigger: bool,
    recenter: bool,
) -> bytes:
    body = {
        "schema": PICO_UDP_SCHEMA,
        "command": "recenter" if recenter else "pose",
        "sequence": sequence,
        "timestamp": timestamp,
        "position_m": list(sample.position_m),
        "quaternion_xyzw": list(sample.quaternion_xyzw),
        "trigger": trigger,
        "recenter": recenter,
    }
    return json.dumps(body, separators=(",", ":")).encode("utf-8")


def in_dropout(elapsed: float, start: float | None, duration_ms: float) -> bool:
    if start is None:
        return False
    return start <= elapsed < start + duration_ms / 1000.0


def validate_args(args: argparse.Namespace) -> None:
    if not 1 <= args.port <= 65535:
        raise SystemExit("ERROR: --port must be in [1, 65535]")
    if not 1 <= args.rate_hz <= 120:
        raise SystemExit("ERROR: --rate-hz must be in [1, 120]")
    if not 0 <= args.distance_mm <= 2.0:
        raise SystemExit("ERROR: --distance-mm must be in [0, 2]")
    if not 0 <= args.rotation_deg <= 0.5:
        raise SystemExit("ERROR: --rotation-deg must be in [0, 0.5]")
    for field in ("lead_seconds", "motion_seconds", "settle_seconds"):
        if getattr(args, field) < 0:
            raise SystemExit(f"ERROR: --{field.replace('_', '-')} must be non-negative")
    if args.motion_seconds <= 0:
        raise SystemExit("ERROR: --motion-seconds must be positive")
    if args.cycle_seconds is not None and not (
        0 < args.cycle_seconds <= args.motion_seconds
    ):
        raise SystemExit(
            "ERROR: --cycle-seconds must be positive and no greater than motion duration"
        )
    if args.delay_ms < 0 or args.jitter_ms < 0 or args.dropout_ms < 0:
        raise SystemExit("ERROR: network impairment values must be non-negative")
    if args.dropout_at is not None and args.dropout_at < 0:
        raise SystemExit("ERROR: --dropout-at must be non-negative")
    if args.trigger_release_at is not None and args.trigger_release_at < 0:
        raise SystemExit("ERROR: --trigger-release-at must be non-negative")
    if args.drop_every < 0 or args.duplicate_every < 0 or args.reorder_every < 0:
        raise SystemExit("ERROR: packet interval options must be non-negative")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Virtual Pico UDP test bench")
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, default=10086)
    parser.add_argument("--rate-hz", type=float, default=90.0)
    parser.add_argument("--lead-seconds", type=float, default=2.0)
    parser.add_argument("--motion-seconds", type=float, default=16.0)
    parser.add_argument("--settle-seconds", type=float, default=3.0)
    parser.add_argument(
        "--cycle-seconds",
        type=float,
        help="Repeat the selected zero-returning trajectory at this period",
    )
    parser.add_argument(
        "--trajectory",
        choices=(
            "origin", "x", "y", "z", "xy", "circle",
            "rotation-x", "rotation-y", "rotation-z",
        ),
        default="origin",
    )
    parser.add_argument("--distance-mm", type=float, default=0.0)
    parser.add_argument("--rotation-deg", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=20260806)
    parser.add_argument("--delay-ms", type=float, default=0.0)
    parser.add_argument("--jitter-ms", type=float, default=0.0)
    parser.add_argument("--drop-every", type=int, default=0)
    parser.add_argument("--duplicate-every", type=int, default=0)
    parser.add_argument("--reorder-every", type=int, default=0)
    parser.add_argument("--dropout-at", type=float)
    parser.add_argument("--dropout-ms", type=float, default=0.0)
    parser.add_argument("--trigger-release-at", type=float)
    parser.add_argument("--no-recenter-at-start", action="store_true")
    parser.add_argument("--report")
    return parser


def flush_due(
    queue: list[ScheduledDatagram],
    sender: socket.socket,
    target: tuple[str, int],
    now: float,
) -> int:
    sent = 0
    while queue and queue[0].send_at <= now:
        item = heapq.heappop(queue)
        sender.sendto(item.payload, target)
        sent += 1
    return sent


def run(args: argparse.Namespace) -> dict[str, object]:
    validate_args(args)
    rng = random.Random(args.seed)
    started = time.monotonic()
    capture_started = time.time()
    total = args.lead_seconds + args.motion_seconds + args.settle_seconds
    sequence = 0
    enqueue_order = 0
    queue: list[ScheduledDatagram] = []
    counters = {
        "frames_captured": 0,
        "datagrams_sent": 0,
        "frames_dropped": 0,
        "duplicates_scheduled": 0,
        "reordered_scheduled": 0,
        "dropout_frames": 0,
        "trigger_release_frames": 0,
        "recenter_commands": 0,
        "capture_deadlines_skipped": 0,
    }
    target = (args.host, args.port)
    trigger_released = False
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sender:
        while True:
            now = time.monotonic()
            elapsed = now - started
            counters["datagrams_sent"] += flush_due(queue, sender, target, now)
            if elapsed > total:
                break

            deadline = started + sequence / args.rate_hz
            if now < deadline:
                time.sleep(min(0.002, deadline - now))
                continue
            period = 1.0 / args.rate_hz
            if now - deadline >= period:
                missed = int((now - deadline) // period)
                sequence += missed
                counters["capture_deadlines_skipped"] += missed

            counters["frames_captured"] += 1
            if elapsed < args.lead_seconds or elapsed >= args.lead_seconds + args.motion_seconds:
                sample = PoseSample((0.0, 0.0, 0.0), (0.0, 0.0, 0.0, 1.0))
            else:
                motion_elapsed = elapsed - args.lead_seconds
                trajectory_duration = args.motion_seconds
                if args.cycle_seconds is not None:
                    motion_elapsed %= args.cycle_seconds
                    trajectory_duration = args.cycle_seconds
                sample = trajectory_sample(
                    args.trajectory,
                    motion_elapsed,
                    trajectory_duration,
                    args.distance_mm / 1000.0,
                    args.rotation_deg,
                )

            release = (
                args.trigger_release_at is not None
                and elapsed >= args.trigger_release_at
            )
            if release:
                trigger_released = True
                counters["trigger_release_frames"] += 1
            recenter = sequence == 0 and not args.no_recenter_at_start
            if recenter:
                counters["recenter_commands"] += 1
            payload = pico_packet(
                sequence,
                capture_started + elapsed,
                sample,
                trigger=not release,
                recenter=recenter,
            )

            should_drop = args.drop_every > 0 and sequence > 0 and sequence % args.drop_every == 0
            dropout = in_dropout(elapsed, args.dropout_at, args.dropout_ms)
            if should_drop or dropout:
                counters["frames_dropped"] += 1
                if dropout:
                    counters["dropout_frames"] += 1
            else:
                jitter = rng.uniform(-args.jitter_ms, args.jitter_ms)
                send_at = now + max(0.0, args.delay_ms + jitter) / 1000.0
                if args.reorder_every > 0 and sequence > 0 and sequence % args.reorder_every == 0:
                    send_at += 2.5 / args.rate_hz
                    counters["reordered_scheduled"] += 1
                heapq.heappush(queue, ScheduledDatagram(send_at, enqueue_order, payload))
                enqueue_order += 1
                if args.duplicate_every > 0 and sequence > 0 and sequence % args.duplicate_every == 0:
                    heapq.heappush(
                        queue,
                        ScheduledDatagram(send_at + 0.0005, enqueue_order, payload),
                    )
                    enqueue_order += 1
                    counters["duplicates_scheduled"] += 1
            sequence += 1
            if trigger_released:
                # A real controller stops producing active pose targets after release.
                break

        flush_deadline = time.monotonic() + max(1.0, (args.delay_ms + args.jitter_ms) / 1000.0 + 0.5)
        while queue and time.monotonic() < flush_deadline:
            counters["datagrams_sent"] += flush_due(
                queue, sender, target, time.monotonic()
            )
            if queue:
                time.sleep(min(0.002, max(0.0, queue[0].send_at - time.monotonic())))

    report: dict[str, object] = {
        "program": "virtual_pico_testbench",
        "schema": PICO_UDP_SCHEMA,
        "target": {"host": args.host, "port": args.port},
        "trajectory": args.trajectory,
        "distance_mm": args.distance_mm,
        "rotation_deg": args.rotation_deg,
        "rate_hz": args.rate_hz,
        "cycle_seconds": args.cycle_seconds,
        "duration_seconds": time.monotonic() - started,
        "network": {
            "delay_ms": args.delay_ms,
            "jitter_ms": args.jitter_ms,
            "drop_every": args.drop_every,
            "duplicate_every": args.duplicate_every,
            "reorder_every": args.reorder_every,
            "dropout_at": args.dropout_at,
            "dropout_ms": args.dropout_ms,
            "trigger_release_at": args.trigger_release_at,
        },
        **counters,
        "pending_datagrams": len(queue),
        "result": "PASS" if not queue else "FAIL",
    }
    if args.report:
        from pathlib import Path

        path = Path(args.report)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report


def main() -> int:
    args = build_parser().parse_args()
    return 0 if run(args)["result"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
