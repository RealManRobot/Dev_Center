#!/usr/bin/env python3
"""Offline tests for the customer movej_follow compatibility gateway."""

from __future__ import annotations

import json
import math
import sys
import unittest
from argparse import Namespace
from pathlib import Path


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from gateway_core import (  # noqa: E402
    LatestVRBuffer,
    PICO_UDP_SCHEMA,
    Pose,
    VRMapper,
    goal_action,
    parse_vr_packet,
    stream_action,
    time_adjusted_alpha,
    tracking_action,
    validate_config,
    validate_joint_target,
)
from virtual_pico_testbench import (  # noqa: E402
    PoseSample,
    pico_packet,
    trajectory_sample,
    validate_args,
)
from virtual_vr_sender import out_and_back, septic_scurve  # noqa: E402
from offline_policy_replay import replay as replay_policy  # noqa: E402
from vr_movej_follow_gateway import (  # noqa: E402
    ArmStateMonitor,
    SourceClockEstimator,
    effective_target_age_seconds,
    observe_postflight,
)


def packet(sequence: int, trigger: bool = True) -> bytes:
    return json.dumps(
        {
            "sequence": sequence,
            "timestamp": 1.0 + sequence,
            "position_m": [sequence / 1000000.0, 0.0, 0.0],
            "quaternion_xyzw": [0.0, 0.0, 0.0, 1.0],
            "trigger": trigger,
        }
    ).encode("utf-8")


class GatewayCoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.config = json.loads((HERE / "config.example.json").read_text())

    def test_example_config_is_valid(self) -> None:
        validate_config(self.config)

    def test_latest_buffer_replaces_instead_of_queuing(self) -> None:
        buffer = LatestVRBuffer()
        buffer.ingest(packet(1), 10.0)
        buffer.ingest(packet(2), 10.01)
        self.assertEqual(buffer.accepted, 2)
        self.assertEqual(buffer.latest.packet.sequence, 2)
        self.assertAlmostEqual(buffer.age(10.06), 0.05)

    def test_invalid_and_out_of_order_are_counted(self) -> None:
        buffer = LatestVRBuffer()
        buffer.ingest(b"not-json", 1.0)
        buffer.ingest(packet(2), 2.0)
        buffer.ingest(packet(2), 2.5)
        buffer.ingest(packet(1), 3.0)
        self.assertEqual(buffer.invalid, 1)
        self.assertEqual(buffer.out_of_order, 1)
        self.assertEqual(buffer.duplicates, 1)
        self.assertEqual(buffer.latest.packet.sequence, 2)

    def test_stream_actions_are_fail_safe(self) -> None:
        self.assertEqual(stream_action(0.05, True, self.config), "send_fresh")
        self.assertEqual(stream_action(0.15, True, self.config), "hold_stale")
        self.assertEqual(stream_action(0.251, True, self.config), "stop_vr_watchdog")
        self.assertEqual(stream_action(0.01, False, self.config), "stop_deadman_released")

    def test_source_timestamp_age_cannot_look_fresh_on_late_delivery(self) -> None:
        buffer = LatestVRBuffer()
        clock = SourceClockEstimator()
        buffer.ingest(packet(1), 10.0)
        arrival, source, effective = effective_target_age_seconds(
            buffer, 10.01, 3.00, clock
        )
        self.assertAlmostEqual(arrival, 0.01)
        self.assertAlmostEqual(source, 0.0)
        self.assertAlmostEqual(effective, 0.01)
        buffer.ingest(packet(2), 10.10)
        arrival, source, effective = effective_target_age_seconds(
            buffer, 10.11, 4.40, clock
        )
        self.assertAlmostEqual(arrival, 0.01)
        self.assertAlmostEqual(source, 0.40)
        self.assertAlmostEqual(effective, 0.40)

    def test_postflight_marks_unhealthy_joint_state(self) -> None:
        class FakeController:
            def preflight(self):
                return {
                    "state": {"joint": [0] * 7},
                    "joint_error": {
                        "err_flag": [0, 0, 0, 0, 0, 0, 1],
                        "brake_state": [0] * 7,
                    },
                    "enable": {"en_state": [1] * 7},
                }

        result = observe_postflight(FakeController(), 0.0, [0] * 7)
        self.assertEqual(result["result"], "FAIL")
        self.assertEqual(result["unhealthy_sample_count"], 1)

    def test_config_rejects_unsafe_overrides(self) -> None:
        cases = {
            "output_rate_hz": 4.0,
            "max_translation_mm": 2.1,
            "postflight_observe_seconds": 59.9,
            "controller_ip": "192.168.127.19",
        }
        for key, value in cases.items():
            changed = dict(self.config)
            changed[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                validate_config(changed)

    def test_frequency_staircase_is_explicit(self) -> None:
        for rate in (2.0, 3.0, 5.0, 10.0, 20.0):
            changed = dict(self.config)
            changed["output_rate_hz"] = rate
            validate_config(changed)

    def test_state_monitor_keeps_feedback_off_the_command_path(self) -> None:
        class FakeController:
            def request(self, command):
                if command["command"] != "get_joint_err_flag":
                    raise AssertionError(command)
                return {"err_flag": [0] * 7, "brake_state": [0] * 7}

            def current_state(self):
                return {"joint": [0] * 7, "pose": [0] * 6}

        monitor = ArmStateMonitor(FakeController(), 20.0)
        monitor.start()
        monitor.wait_ready(0.2)
        snapshot = monitor.latest(0.2)
        self.assertEqual(snapshot["state"]["joint"], [0] * 7)
        monitor.stop()

    def test_pico_schema_and_recenter(self) -> None:
        payload = pico_packet(
            7,
            123.5,
            PoseSample((0.1, 0.2, 0.3), (0.0, 0.0, 0.0, 1.0)),
            trigger=True,
            recenter=True,
        )
        parsed = parse_vr_packet(payload)
        self.assertTrue(parsed.recenter)
        self.assertTrue(parsed.trigger)
        self.assertEqual(json.loads(payload)["schema"], PICO_UDP_SCHEMA)
        mapper = VRMapper(Pose((1.0, 2.0, 3.0), (1.0, 0.0, 0.0, 0.0)), self.config)
        self.assertEqual(mapper.recenter(parsed), mapper.robot_origin)

    def test_filter_alpha_is_time_corrected(self) -> None:
        self.assertAlmostEqual(time_adjusted_alpha(0.25, 1.0 / 90.0), 0.25)
        self.assertAlmostEqual(
            time_adjusted_alpha(0.25, 0.2),
            1.0 - (1.0 - 0.25) ** 18,
        )
        with self.assertRaises(ValueError):
            time_adjusted_alpha(0.25, -0.01)

    def test_runtime_recenter_uses_current_measured_pose(self) -> None:
        startup = Pose((1.0, 2.0, 3.0), (1.0, 0.0, 0.0, 0.0))
        current = Pose((1.1, 2.1, 3.1), (1.0, 0.0, 0.0, 0.0))
        mapper = VRMapper(startup, self.config)
        recenter_packet = parse_vr_packet(packet(1))
        self.assertEqual(mapper.recenter(recenter_packet, current), current)
        self.assertEqual(mapper.robot_origin, current)
        self.assertEqual(mapper.last_target, current)

    def test_input_burst_maps_latest_goal_without_external_waypointing(self) -> None:
        origin = Pose((0.0, 0.0, 0.0), (1.0, 0.0, 0.0, 0.0))
        mapper = VRMapper(origin, self.config)
        buffer = LatestVRBuffer()
        buffer.ingest(packet(0), 0.0)
        mapper.recenter(buffer.latest.packet, origin)

        # Ninety input frames arrive before the next 5 Hz robot output slot.
        # Only the latest frame is mapped.  movej_follow receives the filtered
        # latest goal and owns trajectory planning; the gateway does not turn
        # it into a queue of 0.2 mm Cartesian waypoints.
        for sequence in range(1, 91):
            payload = json.dumps(
                {
                    "sequence": sequence,
                    "timestamp": 1.0 + sequence / 90.0,
                    "position_m": [0.002 * sequence / 90.0, 0.0, 0.0],
                    "quaternion_xyzw": [0.0, 0.0, 0.0, 1.0],
                    "trigger": True,
                }
            ).encode("utf-8")
            buffer.ingest(payload, sequence / 90.0)
        target, clips = mapper.map(buffer.latest.packet, 0.2)
        displacement = math.sqrt(sum(value * value for value in target.position_m))
        self.assertGreater(displacement, 0.00198)
        self.assertLessEqual(displacement, 0.002)
        self.assertNotIn("step", clips)
        with self.assertRaises(ValueError):
            mapper.map(buffer.latest.packet, 0.0)

    def test_goal_policy_coalesces_jitter_and_rejects_discontinuity(self) -> None:
        origin = Pose((0.0, 0.0, 0.0), (1.0, 0.0, 0.0, 0.0))
        jitter = Pose((0.000005, 0.0, 0.0), (1.0, 0.0, 0.0, 0.0))
        action, metrics = goal_action(jitter, origin, self.config)
        self.assertEqual(action, "hold_deadband")
        self.assertAlmostEqual(metrics["position_delta_mm"], 0.005)

        fresh = Pose((0.001, 0.0, 0.0), (1.0, 0.0, 0.0, 0.0))
        self.assertEqual(goal_action(fresh, origin, self.config)[0], "send_latest")

        discontinuity = Pose((0.0021, 0.0, 0.0), (1.0, 0.0, 0.0, 0.0))
        self.assertEqual(
            goal_action(discontinuity, origin, self.config)[0],
            "stop_position_jump",
        )

    def test_tracking_lag_is_observed_without_blocking_latest_goal(self) -> None:
        initial = [0.0] * 7
        status, metrics = tracking_action(
            [0.0] * 7,
            [0.75] * 7,
            initial,
            self.config,
        )
        self.assertEqual(status, "warn_tracking_lag")
        self.assertAlmostEqual(metrics["tracking_error_deg"], 0.75)

        status, metrics = tracking_action(
            [1.31] * 7,
            [0.75] * 7,
            initial,
            self.config,
        )
        self.assertEqual(status, "stop_measured_excursion")
        self.assertAlmostEqual(metrics["measured_excursion_limit_deg"], 1.3)

    def test_virtual_pico_trajectory_envelopes(self) -> None:
        for trajectory in ("x", "y", "z", "xy", "circle"):
            samples = [
                trajectory_sample(trajectory, index / 100.0, 1.0, 0.002, 0.0)
                for index in range(101)
            ]
            self.assertLessEqual(
                max(math.sqrt(sum(v * v for v in sample.position_m)) for sample in samples),
                0.002000001,
            )
            self.assertEqual(samples[0].position_m, (0.0, 0.0, 0.0))
            self.assertAlmostEqual(
                math.sqrt(sum(v * v for v in samples[-1].position_m)), 0.0, places=9
            )
        rotated = trajectory_sample("rotation-x", 0.5, 1.0, 0.0, 0.5)
        self.assertNotEqual(rotated.quaternion_xyzw, (0.0, 0.0, 0.0, 1.0))

    def test_cycle_period_must_fit_motion_duration(self) -> None:
        args = Namespace(
            port=10086,
            rate_hz=90.0,
            distance_mm=2.0,
            rotation_deg=0.0,
            lead_seconds=2.0,
            motion_seconds=16.0,
            settle_seconds=2.0,
            cycle_seconds=20.0,
            delay_ms=0.0,
            jitter_ms=0.0,
            dropout_ms=0.0,
            dropout_at=None,
            trigger_release_at=None,
            drop_every=0,
            duplicate_every=0,
            reorder_every=0,
        )
        with self.assertRaises(SystemExit):
            validate_args(args)

    def test_joint_step_and_excursion_guards(self) -> None:
        origin = [0.0] * 7
        result = validate_joint_target([0.1] * 7, origin, origin, self.config)
        self.assertAlmostEqual(result["target_jump_deg"], 0.1)
        with self.assertRaises(RuntimeError):
            validate_joint_target([1.001] * 7, origin, origin, self.config)
        near = [0.95] * 7
        with self.assertRaises(RuntimeError):
            validate_joint_target([1.01] * 7, near, origin, self.config)

    def test_virtual_sender_curve_starts_and_returns_to_zero(self) -> None:
        self.assertEqual(septic_scurve(0.0), 0.0)
        self.assertEqual(septic_scurve(1.0), 1.0)
        self.assertEqual(out_and_back(0.0, 4.0, 0.002, "z"), [0.0, 0.0, 0.0])
        self.assertAlmostEqual(out_and_back(2.0, 4.0, 0.002, "z")[2], 0.002)
        self.assertAlmostEqual(out_and_back(4.0, 4.0, 0.002, "z")[2], 0.0)

    def test_controller_planned_policy_replay_at_candidate_rates(self) -> None:
        for config_name in (
            "config.10hz.candidate.json",
            "config.20hz.candidate.json",
        ):
            config = json.loads((HERE / config_name).read_text())
            for input_rate in (45.0, 90.0, 120.0):
                for trajectory in ("x", "y", "z", "xy", "circle"):
                    result = replay_policy(
                        config, trajectory, input_rate_hz=input_rate
                    )
                    self.assertEqual(result["jump_stops"], 0)
                    self.assertGreater(result["commands"], 100)
                    self.assertLess(result["return_error_mm"], 0.01)

    def test_network_anomalies_keep_only_latest_and_fail_safe(self) -> None:
        buffer = LatestVRBuffer()
        self.assertIsNotNone(buffer.ingest(packet(10), 1.00))
        self.assertIsNone(buffer.ingest(packet(10), 1.01))
        self.assertIsNone(buffer.ingest(packet(9), 1.02))
        self.assertIsNotNone(buffer.ingest(packet(15), 1.03))
        self.assertEqual(buffer.latest.packet.sequence, 15)
        self.assertEqual(buffer.duplicates, 1)
        self.assertEqual(buffer.out_of_order, 1)
        self.assertEqual(stream_action(buffer.age(1.18), True, self.config), "hold_stale")
        self.assertEqual(
            stream_action(buffer.age(1.281), True, self.config),
            "stop_vr_watchdog",
        )
        self.assertEqual(
            stream_action(buffer.age(1.04), False, self.config),
            "stop_deadman_released",
        )

    def test_customer_sources_have_no_auto_clear_or_private_path(self) -> None:
        combined = "\n".join(
            path.read_text(encoding="utf-8")
            for path in HERE.glob("*.py")
            if path.name != Path(__file__).name
        )
        self.assertNotIn("set_joint_clear_err", combined)
        private_home = "/" + "Users" + "/" + "jacky"
        self.assertNotIn(private_home, combined)
        self.assertIn('report["stop_command_count"] = 1', combined)


if __name__ == "__main__":
    unittest.main(verbosity=2)
