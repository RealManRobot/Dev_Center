#!/usr/bin/env python3
"""RealMan controller and IK adapter used by the customer gateway."""

from __future__ import annotations

import json
import socket
import time
from typing import Any, Mapping, Sequence

from gateway_core import Pose, quaternion_normalize


ARM_MODEL = {
    "left": "RM_MODEL_RXL75_E",
    "right": "RM_MODEL_RXR75_E",
}


def encode(command: Mapping[str, Any]) -> bytes:
    return json.dumps(command, separators=(",", ":")).encode("ascii") + b"\r\n"


class Controller:
    def __init__(self, ip: str, port: int = 8080, timeout: float = 2.0) -> None:
        self.ip = ip
        self.port = port
        self.timeout = timeout

    def request(self, command: Mapping[str, Any]) -> dict[str, Any]:
        expected = command["command"]
        with socket.create_connection(
            (self.ip, self.port), timeout=self.timeout
        ) as connection:
            connection.settimeout(self.timeout)
            connection.sendall(encode(command))
            buffer = bytearray()
            deadline = time.monotonic() + self.timeout
            while time.monotonic() < deadline:
                while b"\r\n" in buffer:
                    line, _, remainder = buffer.partition(b"\r\n")
                    buffer[:] = remainder
                    parsed = json.loads(line.decode("utf-8"))
                    if isinstance(parsed, dict) and parsed.get("command") == expected:
                        return parsed
                chunk = connection.recv(65536)
                if not chunk:
                    break
                buffer.extend(chunk)
        raise RuntimeError(f"no valid {expected} response")

    def current_state(self) -> dict[str, list[int]]:
        response = self.request({"command": "get_current_arm_state"})
        state = response.get("arm_state")
        if not isinstance(state, dict):
            raise RuntimeError("arm_state is missing")
        joint = state.get("joint")
        pose = state.get("pose")
        error = state.get("err")
        if not isinstance(joint, list) or len(joint) != 7:
            raise RuntimeError("current joint state is invalid")
        if not isinstance(pose, list) or len(pose) != 6:
            raise RuntimeError("current pose is invalid")
        if error != [0]:
            raise RuntimeError(f"arm error is not clear: {error!r}")
        return {
            "joint": [int(value) for value in joint],
            "pose": [int(value) for value in pose],
        }

    def preflight(self) -> dict[str, Any]:
        state = self.current_state()
        joint_error = self.request({"command": "get_joint_err_flag"})
        enable = self.request({"command": "get_joint_en_state"})
        trajectory = self.request({"command": "get_arm_current_trajectory"})
        collision = self.request({"command": "get_collision_stage"})
        work_frame = self.request({"command": "get_current_work_frame"})
        tool_frame = self.request({"command": "get_current_tool_frame"})
        if joint_error.get("err_flag") != [0] * 7:
            raise RuntimeError(f"joint errors are not clear: {joint_error!r}")
        if joint_error.get("brake_state") != [0] * 7:
            raise RuntimeError(f"unexpected brake state: {joint_error!r}")
        if enable.get("en_state") != [1] * 7:
            raise RuntimeError(f"one or more joints are disabled: {enable!r}")
        if trajectory.get("type") != "none":
            raise RuntimeError(f"controller is not idle: {trajectory!r}")
        if work_frame.get("frame_name") != "World":
            raise RuntimeError(f"unexpected work frame: {work_frame!r}")
        if tool_frame.get("tool_name") != "Arm_Tip":
            raise RuntimeError(f"unexpected tool frame: {tool_frame!r}")
        return {
            "state": state,
            "joint_error": joint_error,
            "enable": enable,
            "trajectory": trajectory,
            "collision_stage": int(collision["collision_stage"]),
            "work_frame": work_frame,
            "tool_frame": tool_frame,
        }

    def set_collision_stage(self, stage: int) -> None:
        response = self.request(
            {"command": "set_collision_stage", "collision_stage": stage}
        )
        if response.get("collision_state") is not True:
            raise RuntimeError(f"failed to set collision stage {stage}: {response!r}")
        verified = self.request({"command": "get_collision_stage"})
        if verified.get("collision_stage") != stage:
            raise RuntimeError(f"collision stage readback mismatch: {verified!r}")

    def stop(self) -> dict[str, Any]:
        return self.request({"command": "set_arm_stop"})

    def open_motion_connection(self) -> socket.socket:
        connection = socket.create_connection(
            (self.ip, self.port), timeout=self.timeout
        )
        connection.settimeout(self.timeout)
        return connection


class RealManIK:
    def __init__(self, arm: str) -> None:
        try:
            from Robotic_Arm import rm_robot_interface as rm
        except ImportError as exc:
            raise RuntimeError(
                "RealMan API2 is unavailable; run on the robot with the "
                "vendor Python environment that provides Robotic_Arm"
            ) from exc
        model = getattr(rm.rm_robot_arm_model_e, ARM_MODEL[arm])
        self._rm = rm
        self._algo = rm.Algo(model, rm.rm_force_type_e.RM_MODEL_RM_ISF_E, 7)
        self._algo.rm_algo_set_angle(0.0, -90.0, 0.0)
        self._algo.rm_algo_set_redundant_parameter_traversal_mode(False)

    def forward(self, joint_deg: Sequence[float]) -> Pose:
        values = self._algo.rm_algo_forward_kinematics(list(joint_deg), 0)
        if not isinstance(values, list) or len(values) != 7:
            raise RuntimeError(f"forward kinematics returned invalid data: {values!r}")
        return Pose(
            position_m=tuple(float(value) for value in values[:3]),  # type: ignore[arg-type]
            quaternion_wxyz=quaternion_normalize(values[3:]),
        )

    def inverse(
        self, seed_joint_deg: Sequence[float], target: Pose
    ) -> tuple[int, list[float]]:
        params = self._rm.rm_inverse_kinematics_params_t(
            list(seed_joint_deg),
            [*target.position_m, *target.quaternion_wxyz],
            0,
        )
        code, joint = self._algo.rm_algo_inverse_kinematics(params)
        return int(code), [float(value) for value in joint]


def send_movej_follow(connection: socket.socket, joint_deg: Sequence[float]) -> None:
    joint_raw = [round(value * 1000.0) for value in joint_deg]
    connection.sendall(encode({"command": "movej_follow", "joint": joint_raw}))

