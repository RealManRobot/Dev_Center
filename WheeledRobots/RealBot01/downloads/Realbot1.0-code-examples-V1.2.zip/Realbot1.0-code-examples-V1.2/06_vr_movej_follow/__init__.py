"""Customer-facing low-rate movej_follow compatibility example."""

