#!/usr/bin/env python3
"""Send a bounded OpenXR-like stream without requiring a Pico headset."""

from __future__ import annotations

import argparse
import json
import socket
import time


def septic_scurve(progress: float) -> float:
    value = min(1.0, max(0.0, progress))
    return 35 * value**4 - 84 * value**5 + 70 * value**6 - 20 * value**7


def out_and_back(elapsed: float, duration: float, distance_m: float, axis: str) -> list[float]:
    half = duration / 2.0
    progress = elapsed / half if elapsed <= half else (duration - elapsed) / half
    position = [0.0, 0.0, 0.0]
    position[{"x": 0, "y": 1, "z": 2}[axis]] = distance_m * septic_scurve(progress)
    return position


def main() -> int:
    parser = argparse.ArgumentParser(description="Bounded virtual VR UDP sender")
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, default=10086)
    parser.add_argument("--rate-hz", type=float, default=90.0)
    parser.add_argument("--lead-seconds", type=float, default=2.0)
    parser.add_argument("--motion-seconds", type=float, default=16.0)
    parser.add_argument("--settle-seconds", type=float, default=3.0)
    parser.add_argument("--distance-mm", type=float, default=0.0)
    parser.add_argument("--axis", choices=("x", "y", "z"), default="z")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("port must be in [1, 65535]")
    if not 1 <= args.rate_hz <= 120:
        parser.error("rate-hz must be in [1, 120]")
    if not 0 <= args.distance_mm <= 2.0:
        parser.error("distance-mm must be in [0, 2]")
    if min(args.lead_seconds, args.motion_seconds, args.settle_seconds) < 0:
        parser.error("time values must be non-negative")
    if args.motion_seconds <= 0:
        parser.error("motion-seconds must be positive")

    sequence = 0
    started = time.monotonic()
    total = args.lead_seconds + args.motion_seconds + args.settle_seconds
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sender:
        while True:
            now = time.monotonic()
            elapsed = now - started
            if elapsed > total:
                break
            if elapsed < args.lead_seconds or elapsed >= args.lead_seconds + args.motion_seconds:
                position = [0.0, 0.0, 0.0]
            else:
                position = out_and_back(
                    elapsed - args.lead_seconds,
                    args.motion_seconds,
                    args.distance_mm / 1000.0,
                    args.axis,
                )
            payload = {
                "sequence": sequence,
                "timestamp": time.time(),
                "position_m": position,
                "quaternion_xyzw": [0.0, 0.0, 0.0, 1.0],
                "trigger": True,
            }
            sender.sendto(
                json.dumps(payload, separators=(",", ":")).encode("utf-8"),
                (args.host, args.port),
            )
            sequence += 1
            deadline = started + sequence / args.rate_hz
            time.sleep(max(0.0, deadline - time.monotonic()))
    print(json.dumps({"event": "virtual_vr_complete", "frames": sequence}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
