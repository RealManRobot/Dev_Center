#!/usr/bin/env python3
"""Customer-safe virtual-VR to low-rate movej_follow compatibility gateway.

Without ``--execute`` this program only validates the JSON configuration.  Live
motion requires every confirmation flag printed by ``--help``.  The program
never clears controller errors automatically.
"""

from __future__ import annotations

import argparse
import json
import math
import select
import socket
import threading
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

from gateway_core import (
    MAX_PACKET_BYTES,
    LatestVRBuffer,
    Pose,
    VRPacket,
    VRMapper,
    goal_action,
    joint_distance_deg,
    stream_action,
    tracking_action,
    validate_config,
    validate_joint_target,
)
from realman_backend import Controller, RealManIK, send_movej_follow


STARTUP_TIMEOUT_SECONDS = 10.0
MAX_IK_POSITION_ERROR_M = 0.0001
IMMEDIATE_POST_STOP_DELAY_SECONDS = 0.5


class SourceClockEstimator:
    """Estimate source-to-robot clock offset from the lowest observed transit."""

    def __init__(self) -> None:
        self.minimum_offset_seconds: float | None = None

    def age_seconds(self, now_wall: float, source_timestamp: float) -> float:
        observed_offset = now_wall - source_timestamp
        if (
            self.minimum_offset_seconds is None
            or observed_offset < self.minimum_offset_seconds
        ):
            self.minimum_offset_seconds = observed_offset
        return max(0.0, observed_offset - self.minimum_offset_seconds)
CONFIRMATIONS = (
    "confirm_site_clear",
    "confirm_control_exclusive",
    "confirm_two_mm_envelope",
    "confirm_low_rate_follow",
    "confirm_collision_stage_4",
    "confirm_single_stop",
    "confirm_return_to_origin",
)


class ArmStateMonitor:
    """Poll feedback away from the command-sending hot path."""

    def __init__(self, controller: Controller, poll_rate_hz: float) -> None:
        self.controller = controller
        self.period_seconds = 1.0 / poll_rate_hz
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._ready = threading.Event()
        self._thread: threading.Thread | None = None
        self._snapshot: dict[str, Any] | None = None
        self._error: BaseException | None = None

    def start(self) -> None:
        if self._thread is not None:
            raise RuntimeError("arm state monitor already started")
        self._thread = threading.Thread(
            target=self._run,
            name="realman-arm-state-monitor",
            daemon=True,
        )
        self._thread.start()

    def _run(self) -> None:
        while not self._stop.is_set():
            cycle_started = time.monotonic()
            try:
                joint_error = self.controller.request(
                    {"command": "get_joint_err_flag"}
                )
                state = self.controller.current_state()
                if joint_error.get("err_flag") != [0] * 7:
                    raise RuntimeError(f"joint error in monitor: {joint_error!r}")
                if joint_error.get("brake_state") != [0] * 7:
                    raise RuntimeError(f"unexpected brake state: {joint_error!r}")
                with self._lock:
                    self._snapshot = {
                        "sampled_monotonic": time.monotonic(),
                        "joint_error": joint_error,
                        "state": state,
                    }
                    self._error = None
                self._ready.set()
            except BaseException as exc:
                with self._lock:
                    self._error = exc
                self._ready.set()
                return
            elapsed = time.monotonic() - cycle_started
            self._stop.wait(max(0.0, self.period_seconds - elapsed))

    def wait_ready(self, timeout_seconds: float) -> None:
        if not self._ready.wait(timeout_seconds):
            raise RuntimeError("arm state monitor did not produce a sample")
        self.latest(float("inf"))

    def latest(self, max_age_seconds: float) -> dict[str, Any]:
        with self._lock:
            error = self._error
            snapshot = dict(self._snapshot) if self._snapshot is not None else None
        if error is not None:
            raise RuntimeError(f"arm state monitor failed: {error}") from error
        if snapshot is None:
            raise RuntimeError("arm state monitor has no sample")
        age = time.monotonic() - float(snapshot["sampled_monotonic"])
        if age > max_age_seconds:
            raise RuntimeError(
                f"arm state sample age {age * 1000.0:.3f} ms exceeds watchdog"
            )
        snapshot["age_seconds"] = age
        return snapshot

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=max(1.0, self.period_seconds * 4.0))
            if self._thread.is_alive():
                raise RuntimeError("arm state monitor did not stop")
            self._thread = None


def percentile(values: Sequence[float], fraction: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def pose_position_error(left: Pose, right: Pose) -> float:
    return math.sqrt(
        sum((a - b) ** 2 for a, b in zip(left.position_m, right.position_m))
    )


def load_config(path: Path) -> dict[str, Any]:
    parsed = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(parsed, dict):
        raise ValueError("configuration must be a JSON object")
    validate_config(parsed)
    return parsed


def write_report(path: Path | None, report: Mapping[str, Any]) -> None:
    contents = json.dumps(report, ensure_ascii=False, indent=2)
    print(contents, flush=True)
    if path is not None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(contents + "\n", encoding="utf-8")


def effective_target_age_seconds(
    buffer: LatestVRBuffer,
    now_monotonic: float,
    now_wall: float,
    source_clock: SourceClockEstimator,
) -> tuple[float, float, float]:
    """Return arrival, source-timestamp, and conservative effective ages."""
    arrival_age = buffer.age(now_monotonic)
    latest = buffer.latest
    source_age = (
        source_clock.age_seconds(now_wall, latest.packet.timestamp)
        if latest is not None
        else math.inf
    )
    return arrival_age, source_age, max(arrival_age, source_age)


def drain_udp(
    receiver: socket.socket,
    buffer: LatestVRBuffer,
    source_ip: str | None,
) -> tuple[VRPacket | None, bool]:
    """Drain UDP without advancing the motion filter or trajectory state.

    Every valid datagram may update the one-slot buffer, but a burst must not
    make the robot-side filter run multiple times.  Recenter is returned as an
    event and is applied in the output loop after reading the current joints.
    """
    recenter_packet = None
    deadman_released = False
    while True:
        try:
            payload, address = receiver.recvfrom(MAX_PACKET_BYTES + 1)
        except BlockingIOError:
            break
        if source_ip is not None and address[0] != source_ip:
            continue
        accepted = buffer.ingest(payload, time.monotonic())
        if accepted is None:
            continue
        if accepted.packet.recenter:
            recenter_packet = accepted.packet
            if not accepted.packet.trigger:
                deadman_released = True
            continue
        if not accepted.packet.trigger:
            deadman_released = True
    return recenter_packet, deadman_released


def observe_postflight(
    controller: Controller, seconds: float, initial_joint_raw: Sequence[int]
) -> dict[str, Any]:
    started = time.monotonic()
    samples: list[dict[str, Any]] = []
    while True:
        health = controller.preflight()
        return_error = joint_distance_deg(
            [value / 1000.0 for value in health["state"]["joint"]],
            [value / 1000.0 for value in initial_joint_raw],
        )
        samples.append(
            {
                "elapsed_seconds": time.monotonic() - started,
                "return_error_deg": return_error,
                "joint_error": health["joint_error"]["err_flag"],
                "brake_state": health["joint_error"]["brake_state"],
                "enable_state": health["enable"]["en_state"],
            }
        )
        remaining = seconds - (time.monotonic() - started)
        if remaining <= 0:
            break
        time.sleep(min(1.0, remaining))
    unhealthy_samples = [
        sample
        for sample in samples
        if sample["joint_error"] != [0] * 7
        or sample["brake_state"] != [0] * 7
        or sample["enable_state"] != [1] * 7
    ]
    return {
        "duration_seconds": time.monotonic() - started,
        "sample_count": len(samples),
        "max_return_error_deg": max(
            (sample["return_error_deg"] for sample in samples), default=0.0
        ),
        "samples": samples,
        "unhealthy_sample_count": len(unhealthy_samples),
        "result": "PASS" if not unhealthy_samples else "FAIL",
    }


def run_live(config: Mapping[str, Any]) -> tuple[int, dict[str, Any]]:
    controller = Controller(
        str(config["controller_ip"]), int(config["controller_port"])
    )
    before = controller.preflight()
    initial_joint_raw = list(before["state"]["joint"])
    initial_joint_deg = [value / 1000.0 for value in initial_joint_raw]
    solver = RealManIK(str(config["arm"]))
    origin_pose = solver.forward(initial_joint_deg)
    mapper = VRMapper(origin_pose, config)
    buffer = LatestVRBuffer()
    source_clock = SourceClockEstimator()
    original_collision = int(before["collision_stage"])
    report: dict[str, Any] = {
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "program": "vr_movej_follow_gateway",
        "result": "RUNNING",
        "live_motion": True,
        "arm": config["arm"],
        "controller_ip": config["controller_ip"],
        "backend": "movej_follow",
        "mode": "controller_planned_latest_target",
        "configured": dict(config),
        "before": before,
        "origin_pose": {
            "position_m": origin_pose.position_m,
            "quaternion_wxyz": origin_pose.quaternion_wxyz,
        },
        "stop_command_count": 0,
        "clear_error_commands": 0,
    }
    receiver: socket.socket | None = None
    motion_connection: socket.socket | None = None
    state_monitor: ArmStateMonitor | None = None
    collision_changed = False
    motion_sent = False
    stop_attempted = False
    return_code = 2
    stop_reason = "unknown"
    output_times: list[float] = []
    control_cycle_times: list[float] = []
    input_ages_ms: list[float] = []
    source_timestamp_ages_ms: list[float] = []
    effective_target_ages_ms: list[float] = []
    samples: list[dict[str, Any]] = []
    previous_target = list(initial_joint_deg)
    last_sent_pose = origin_pose
    pending_recenter = None
    last_output_vr_sequence = -1
    recenter_applied = 0
    recenter_hold_commands = 0
    mapping_updates = 0
    clips = {"translation": 0, "rotation": 0}
    stale_holds = 0
    deadband_holds = 0
    tracking_warning_cycles = 0
    stale_events: list[dict[str, Any]] = []
    skipped_deadlines = 0
    max_target_jump = 0.0
    max_position_goal_delta_mm = 0.0
    max_rotation_goal_delta_deg = 0.0
    max_excursion = 0.0
    max_tracking = 0.0
    max_ik_error = 0.0
    max_state_age_ms = 0.0
    output_period = 1.0 / float(config["output_rate_hz"])

    try:
        controller.set_collision_stage(int(config["collision_stage_during_motion"]))
        collision_changed = True
        receiver = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        receiver.bind((str(config["bind_host"]), int(config["udp_port"])))
        receiver.setblocking(False)
        state_monitor = ArmStateMonitor(
            Controller(str(config["controller_ip"]), int(config["controller_port"])),
            float(config["state_poll_rate_hz"]),
        )
        state_monitor.start()
        state_monitor.wait_ready(float(config["state_watchdog_ms"]) / 1000.0)
        print(
            json.dumps(
                {
                    "event": "udp_ready",
                    "bind": config["bind_host"],
                    "port": config["udp_port"],
                }
            ),
            flush=True,
        )
        startup_deadline = time.monotonic() + STARTUP_TIMEOUT_SECONDS
        while buffer.latest is None:
            remaining = startup_deadline - time.monotonic()
            if remaining <= 0:
                raise RuntimeError("no first VR packet within 10 seconds")
            ready, _, _ = select.select([receiver], [], [], min(0.05, remaining))
            if not ready:
                continue
            recenter_packet, released = drain_udp(
                receiver, buffer, config["vr_source_ip"]
            )
            if released:
                raise RuntimeError("stop_deadman_released")
            if recenter_packet is not None:
                pending_recenter = recenter_packet

        motion_connection = controller.open_motion_connection()
        started = time.monotonic()
        next_output = started
        while True:
            now = time.monotonic()
            if now - started >= float(config["duration_seconds"]):
                stop_reason = "duration_complete"
                break
            timeout = min(0.01, max(0.0, next_output - now))
            ready, _, _ = select.select([receiver], [], [], timeout)
            if ready:
                recenter_packet, released = drain_udp(
                    receiver, buffer, config["vr_source_ip"]
                )
                if recenter_packet is not None:
                    pending_recenter = recenter_packet
                if released:
                    stop_reason = "stop_deadman_released"
                    raise RuntimeError(stop_reason)

            now = time.monotonic()
            if now - started >= float(config["duration_seconds"]):
                stop_reason = "duration_complete"
                break
            # Drain the socket before evaluating freshness.  A new packet may
            # already be waiting while the one-slot user-space buffer looks
            # stale.  This watchdog runs every receive-loop turn (<=10 ms),
            # independently from the 2/3/5/10/20 Hz command period.
            latest = buffer.latest
            _, _, effective_age = effective_target_age_seconds(
                buffer, now, time.time(), source_clock
            )
            action = stream_action(
                effective_age, latest.packet.trigger if latest else True, config
            )
            if action.startswith("stop_"):
                stop_reason = action
                raise RuntimeError(action)
            if now < next_output:
                continue
            if now - next_output >= output_period:
                missed = int((now - next_output) // output_period)
                skipped_deadlines += missed
                next_output += missed * output_period
            control_cycle_times.append(now)

            latest = buffer.latest
            age, source_age, effective_age = effective_target_age_seconds(
                buffer, now, time.time(), source_clock
            )
            action = stream_action(
                effective_age, latest.packet.trigger if latest else True, config
            )
            if action.startswith("stop_"):
                stop_reason = action
                raise RuntimeError(action)
            if action == "hold_stale" or latest is None:
                stale_holds += 1
                stale_events.append(
                    {
                        "elapsed_seconds": now - started,
                        "vr_sequence": latest.packet.sequence if latest else None,
                        "arrival_age_ms": age * 1000.0,
                        "source_timestamp_age_ms": source_age * 1000.0,
                        "effective_target_age_ms": effective_age * 1000.0,
                    }
                )
                next_output += output_period
                continue

            monitored = state_monitor.latest(
                float(config["state_watchdog_ms"]) / 1000.0
            )
            health = monitored["joint_error"]
            state = monitored["state"]
            max_state_age_ms = max(
                max_state_age_ms, float(monitored["age_seconds"]) * 1000.0
            )
            measured = [value / 1000.0 for value in state["joint"]]
            current_pose = solver.forward(measured)
            if pending_recenter is not None:
                # If the controller is still following an older goal, replace
                # it with the measured joint state before moving the VR anchor.
                # This uses movej_follow's latest-goal semantics and avoids a
                # snap back to either the startup pose or the old target.
                # Recenter is rare and must use a fresh measured pose. A
                # synchronous read here is intentional; ordinary command
                # cycles remain independent from feedback query latency.
                recenter_state = controller.current_state()
                measured = [value / 1000.0 for value in recenter_state["joint"]]
                current_pose = solver.forward(measured)
                if motion_sent:
                    send_movej_follow(motion_connection, measured)
                    sent_at = time.monotonic()
                    output_times.append(sent_at)
                    recenter_hold_commands += 1
                    previous_target = list(measured)
                    last_sent_pose = current_pose
                mapper.recenter(pending_recenter, current_pose)
                last_output_vr_sequence = pending_recenter.sequence
                pending_recenter = None
                recenter_applied += 1
                next_output += output_period
                continue
            if mapper.vr_origin is None:
                # Backward-compatible startup for senders that omit an explicit
                # recenter packet.  This anchors to the measured pose, not the
                # process-start pose.
                mapper.recenter(latest.packet, current_pose)
                previous_target = list(measured)
                last_sent_pose = current_pose
                last_output_vr_sequence = latest.packet.sequence
                recenter_applied += 1
                next_output += output_period
                continue
            if latest.packet.recenter or latest.packet.sequence == last_output_vr_sequence:
                next_output += output_period
                continue

            tracking_status, tracking_metrics = tracking_action(
                measured, previous_target, initial_joint_deg, config
            )
            tracking = tracking_metrics["tracking_error_deg"]
            max_tracking = max(max_tracking, tracking)
            if tracking_status == "stop_measured_excursion":
                stop_reason = tracking_status
                raise RuntimeError(
                    "measured joint excursion "
                    f"{tracking_metrics['measured_excursion_deg']:.6f} deg "
                    "exceeds authorized monitored limit "
                    f"{tracking_metrics['measured_excursion_limit_deg']:.6f} deg"
                )
            if tracking_status == "warn_tracking_lag":
                tracking_warning_cycles += 1

            latest_target_pose, packet_clips = mapper.map(
                latest.packet, output_period
            )
            mapping_updates += 1
            for name, clipped in packet_clips.items():
                if clipped:
                    clips[name] += 1

            target_action, goal_metrics = goal_action(
                latest_target_pose, last_sent_pose, config
            )
            max_position_goal_delta_mm = max(
                max_position_goal_delta_mm,
                goal_metrics["position_delta_mm"],
            )
            max_rotation_goal_delta_deg = max(
                max_rotation_goal_delta_deg,
                goal_metrics["rotation_delta_deg"],
            )
            if target_action == "hold_deadband":
                deadband_holds += 1
                last_output_vr_sequence = latest.packet.sequence
                next_output += output_period
                continue
            if target_action.startswith("stop_"):
                stop_reason = target_action
                raise RuntimeError(
                    f"{target_action}: position_delta_mm="
                    f"{goal_metrics['position_delta_mm']:.6f}, "
                    f"rotation_delta_deg={goal_metrics['rotation_delta_deg']:.6f}"
                )

            code, target = solver.inverse(initial_joint_deg, latest_target_pose)
            if code != 0:
                raise RuntimeError(f"IK failed with code {code}")
            target_metrics = validate_joint_target(
                target, previous_target, initial_joint_deg, config
            )
            solved_pose = solver.forward(target)
            ik_error = pose_position_error(solved_pose, latest_target_pose)
            if ik_error > MAX_IK_POSITION_ERROR_M:
                raise RuntimeError(
                    f"IK position error {ik_error:.9f} m exceeds 0.000100 m"
                )
            send_movej_follow(motion_connection, target)
            motion_sent = True
            sent_at = time.monotonic()
            output_times.append(sent_at)
            input_ages_ms.append(age * 1000.0)
            source_timestamp_ages_ms.append(source_age * 1000.0)
            effective_target_ages_ms.append(effective_age * 1000.0)
            max_target_jump = max(
                max_target_jump, target_metrics["target_jump_deg"]
            )
            max_excursion = max(max_excursion, target_metrics["excursion_deg"])
            max_ik_error = max(max_ik_error, ik_error)
            samples.append(
                {
                    "output_index": len(output_times) - 1,
                    "elapsed_seconds": sent_at - started,
                    "vr_sequence": latest.packet.sequence,
                    "vr_age_ms": age * 1000.0,
                    "source_timestamp_age_ms": source_age * 1000.0,
                    "effective_target_age_ms": effective_age * 1000.0,
                    "joint_target_jump_deg": target_metrics["target_jump_deg"],
                    "position_goal_delta_mm": goal_metrics["position_delta_mm"],
                    "rotation_goal_delta_deg": goal_metrics["rotation_delta_deg"],
                    "joint_excursion_deg": target_metrics["excursion_deg"],
                    "tracking_error_deg": tracking,
                    "ik_position_error_m": ik_error,
                    "joint_error": list(health.get("err_flag", [])),
                    "brake_state": list(health.get("brake_state", [])),
                    "target_joint_raw": [round(value * 1000.0) for value in target],
                }
            )
            previous_target = list(target)
            last_sent_pose = latest_target_pose
            last_output_vr_sequence = latest.packet.sequence
            next_output += output_period

        motion_connection.close()
        motion_connection = None
        if motion_sent:
            stop_attempted = True
            report["stop_command_count"] = 1
            stop_response = controller.stop()
            report["stop_response"] = stop_response
            if stop_response.get("arm_stop") is not True:
                raise RuntimeError(f"set_arm_stop failed: {stop_response!r}")
        if state_monitor is not None:
            state_monitor.stop()
            state_monitor = None
        if collision_changed:
            controller.set_collision_stage(original_collision)
            collision_changed = False
            report["collision_stage_restored"] = original_collision

        time.sleep(IMMEDIATE_POST_STOP_DELAY_SECONDS)
        immediate = controller.preflight()
        report["immediate_after"] = immediate
        return_error = joint_distance_deg(
            [value / 1000.0 for value in immediate["state"]["joint"]],
            initial_joint_deg,
        )
        report["return_joint_error_deg"] = return_error
        if return_error > float(config["max_return_error_deg"]):
            raise RuntimeError(
                f"return error {return_error:.6f} deg exceeds configured limit"
            )
        delayed = observe_postflight(
            controller,
            float(config["postflight_observe_seconds"]),
            initial_joint_raw,
        )
        report["postflight_observation"] = delayed
        if delayed["result"] != "PASS":
            raise RuntimeError("postflight observation detected an unhealthy joint state")
        if delayed["max_return_error_deg"] > float(config["max_return_error_deg"]):
            raise RuntimeError(
                "postflight return error "
                f"{delayed['max_return_error_deg']:.6f} deg exceeds configured limit"
            )
        report["result"] = "PASS"
        return_code = 0
    except BaseException as exc:
        if stop_reason == "unknown":
            stop_reason = f"exception:{type(exc).__name__}"
        report["result"] = "FAIL"
        report["error"] = f"{type(exc).__name__}: {exc}"
        if motion_sent and not stop_attempted:
            stop_attempted = True
            report["stop_command_count"] = 1
            try:
                report["failure_stop_response"] = controller.stop()
            except BaseException as stop_exc:
                report["failure_stop_error"] = f"{type(stop_exc).__name__}: {stop_exc}"
        if state_monitor is not None:
            try:
                state_monitor.stop()
                state_monitor = None
            except BaseException as monitor_exc:
                report["state_monitor_stop_error"] = (
                    f"{type(monitor_exc).__name__}: {monitor_exc}"
                )
        if collision_changed:
            try:
                controller.set_collision_stage(original_collision)
                report["collision_stage_restored"] = original_collision
            except BaseException as restore_exc:
                report["collision_restore_error"] = (
                    f"{type(restore_exc).__name__}: {restore_exc}"
                )
        try:
            time.sleep(IMMEDIATE_POST_STOP_DELAY_SECONDS)
            report["failure_after"] = controller.preflight()
        except BaseException as health_exc:
            report["failure_after_error"] = (
                f"{type(health_exc).__name__}: {health_exc}"
            )
        if motion_sent and "postflight_observation" not in report:
            try:
                report["failure_postflight_observation"] = observe_postflight(
                    controller,
                    float(config["postflight_observe_seconds"]),
                    initial_joint_raw,
                )
            except BaseException as observe_exc:
                report["failure_postflight_observation_error"] = (
                    f"{type(observe_exc).__name__}: {observe_exc}"
                )
    finally:
        if motion_connection is not None:
            motion_connection.close()
        if receiver is not None:
            receiver.close()
        if state_monitor is not None:
            state_monitor.stop()
        intervals_ms = [
            (right - left) * 1000.0
            for left, right in zip(output_times, output_times[1:])
        ]
        control_intervals_ms = [
            (right - left) * 1000.0
            for left, right in zip(control_cycle_times, control_cycle_times[1:])
        ]
        report["stop_reason"] = stop_reason
        report["stream"] = {
            "input_frames_accepted": buffer.accepted,
            "input_frames_invalid": buffer.invalid,
            "input_frames_out_of_order": buffer.out_of_order,
            "input_frames_duplicate": buffer.duplicates,
            "recenter_commands_accepted": buffer.recenter_accepted,
            "recenter_commands_applied": recenter_applied,
            "recenter_hold_commands": recenter_hold_commands,
            "mapping_updates": mapping_updates,
            "estimated_source_clock_offset_seconds": (
                source_clock.minimum_offset_seconds
            ),
            "output_command_count": len(output_times),
            "coalesced_input_frames": max(0, buffer.accepted - len(output_times)),
            "stale_output_holds": stale_holds,
            "deadband_output_holds": deadband_holds,
            "tracking_warning_cycles": tracking_warning_cycles,
            "stale_events": stale_events,
            "skipped_output_deadlines": skipped_deadlines,
            "clip_counts": clips,
            "max_joint_target_jump_deg": max_target_jump,
            "max_position_goal_delta_mm": max_position_goal_delta_mm,
            "max_rotation_goal_delta_deg": max_rotation_goal_delta_deg,
            "max_joint_excursion_deg": max_excursion,
            "max_tracking_error_deg": max_tracking,
            "max_ik_position_error_m": max_ik_error,
            "max_state_sample_age_ms": max_state_age_ms,
            "input_age_at_output_ms": {
                "p50": percentile(input_ages_ms, 0.50),
                "p99": percentile(input_ages_ms, 0.99),
                "max": max(input_ages_ms, default=0.0),
            },
            "source_timestamp_age_at_output_ms": {
                "p50": percentile(source_timestamp_ages_ms, 0.50),
                "p99": percentile(source_timestamp_ages_ms, 0.99),
                "max": max(source_timestamp_ages_ms, default=0.0),
            },
            "effective_target_age_at_output_ms": {
                "p50": percentile(effective_target_ages_ms, 0.50),
                "p99": percentile(effective_target_ages_ms, 0.99),
                "max": max(effective_target_ages_ms, default=0.0),
            },
            "output_interval_ms": {
                "p50": percentile(intervals_ms, 0.50),
                "p99": percentile(intervals_ms, 0.99),
                "max": max(intervals_ms, default=0.0),
            },
            "control_cycle_interval_ms": {
                "p50": percentile(control_intervals_ms, 0.50),
                "p99": percentile(control_intervals_ms, 0.99),
                "max": max(control_intervals_ms, default=0.0),
            },
            "samples": samples,
        }
    return return_code, report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Validate or run the low-rate movej_follow VR gateway"
    )
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--confirm-site-clear", action="store_true")
    parser.add_argument("--confirm-control-exclusive", action="store_true")
    parser.add_argument("--confirm-two-mm-envelope", action="store_true")
    parser.add_argument("--confirm-low-rate-follow", action="store_true")
    parser.add_argument("--confirm-collision-stage-4", action="store_true")
    parser.add_argument("--confirm-single-stop", action="store_true")
    parser.add_argument("--confirm-return-to-origin", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        config = load_config(args.config)
        if args.execute and not all(getattr(args, name) for name in CONFIRMATIONS):
            raise ValueError("--execute requires all seven confirmation flags")
        if not args.execute:
            write_report(
                args.report,
                {
                    "program": "vr_movej_follow_gateway",
                    "result": "CONFIG_PASS",
                    "live_motion": False,
                    "config_path": str(args.config),
                    "configured": config,
                },
            )
            return 0
        return_code, report = run_live(config)
        write_report(args.report, report)
        return return_code
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        write_report(
            args.report,
            {
                "program": "vr_movej_follow_gateway",
                "result": "CONFIG_FAIL" if not args.execute else "FAIL",
                "live_motion": bool(args.execute),
                "error": f"{type(exc).__name__}: {exc}",
            },
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
