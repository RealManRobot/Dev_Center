#!/usr/bin/env python3
"""Inspect one VR gateway config and evaluate one proposed tuning change.

The assistant is plan-only: it never opens UDP/TCP sockets, never edits the input
configuration, and never sends a robot command. A valid proposal is not treated
as an accepted motion profile; every changed parameter requires staged re-test.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from gateway_core import validate_config


TUNABLE_KEYS = {
    "duration_seconds",
    "output_rate_hz",
    "fresh_target_ms",
    "filter_alpha",
    "max_translation_mm",
    "max_rotation_deg",
    "position_deadband_mm",
    "rotation_deadband_deg",
}

LOCKED_SAFETY_KEYS = {
    "arm",
    "controller_ip",
    "controller_port",
    "bind_host",
    "udp_port",
    "vr_source_ip",
    "watchdog_ms",
    "state_poll_rate_hz",
    "state_watchdog_ms",
    "max_target_jump_mm",
    "max_target_jump_deg",
    "max_joint_target_jump_deg",
    "max_joint_excursion_deg",
    "max_tracking_error_deg",
    "max_return_error_deg",
    "collision_stage_during_motion",
    "postflight_observe_seconds",
}


def load_config(path: Path) -> dict[str, Any]:
    parsed = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(parsed, dict):
        raise ValueError("configuration root must be an object")
    validate_config(parsed)
    if parsed["arm"] != "left":
        raise ValueError("customer VR tuning currently supports the left arm only")
    return parsed


def parse_change(expression: str, config: dict[str, Any]) -> tuple[str, Any]:
    if expression.count("=") != 1:
        raise ValueError("--set must use KEY=VALUE")
    key, raw = expression.split("=", 1)
    key = key.strip()
    raw = raw.strip()
    if key in LOCKED_SAFETY_KEYS:
        raise ValueError(f"{key} is a locked safety/identity parameter")
    if key not in TUNABLE_KEYS:
        raise ValueError(f"unsupported tuning key: {key}")
    if key not in config:
        raise ValueError(f"configuration does not contain {key}")
    try:
        value = float(raw)
    except ValueError as exc:
        raise ValueError(f"{key} must be numeric") from exc
    return key, value


def parameter_groups(config: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {
        "input_and_identity": {
            key: config[key]
            for key in ("arm", "controller_ip", "controller_port", "bind_host", "udp_port", "vr_source_ip")
        },
        "response": {
            key: config[key]
            for key in (
                "output_rate_hz",
                "filter_alpha",
                "position_deadband_mm",
                "rotation_deadband_deg",
            )
        },
        "workspace_envelope": {
            key: config[key] for key in ("max_translation_mm", "max_rotation_deg")
        },
        "freshness_and_stop": {
            key: config[key]
            for key in (
                "fresh_target_ms",
                "watchdog_ms",
                "state_poll_rate_hz",
                "state_watchdog_ms",
                "postflight_observe_seconds",
            )
        },
        "joint_and_tracking_limits": {
            key: config[key]
            for key in (
                "max_target_jump_mm",
                "max_target_jump_deg",
                "max_joint_target_jump_deg",
                "max_joint_excursion_deg",
                "max_tracking_error_deg",
                "max_return_error_deg",
                "collision_stage_during_motion",
            )
        },
    }


def tuning_effect(key: str, old: Any, new: Any) -> str:
    if old == new:
        return "no change"
    direction = "increase" if float(new) > float(old) else "decrease"
    effects = {
        "output_rate_hz": "higher is more responsive but increases command and controller load",
        "filter_alpha": (
            "legacy 90 Hz filter pole; the gateway converts it to the robot-output "
            "period, so input packet rate and UDP bursts do not change response"
        ),
        "max_translation_mm": "changes the Cartesian translation envelope",
        "max_rotation_deg": "changes the orientation envelope",
        "position_deadband_mm": "changes how much position jitter is coalesced before a new goal is sent",
        "rotation_deadband_deg": "changes how much orientation jitter is coalesced before a new goal is sent",
        "fresh_target_ms": "changes when a target is held as stale; watchdog remains fixed at 250 ms",
        "duration_seconds": "changes only the planned run duration",
    }
    return f"{direction}: {effects[key]}"


def required_retest(key: str) -> list[str]:
    common = [
        "2 Hz origin hold with trigger/recenter/one-stop checks",
        "three short runs with fresh target age and joint error review",
        "60 second post-stop observation",
    ]
    if key in {
        "output_rate_hz",
        "filter_alpha",
        "position_deadband_mm",
        "rotation_deadband_deg",
    }:
        common.insert(1, "review output interval P50/P99/max and reject burst catch-up")
    if key in {"max_translation_mm", "max_rotation_deg"}:
        common.insert(1, "repeat single-axis motion before any combined trajectory")
    if key == "fresh_target_ms":
        common.insert(1, "repeat delay/jitter/reorder/dropout and trigger-release tests")
    return common


def build_report(config: dict[str, Any], change: tuple[str, Any] | None) -> dict[str, Any]:
    report: dict[str, Any] = {
        "program": "vr_tuning_assistant",
        "result": "CONFIG_PASS",
        "live_motion": False,
        "released_scope": {
            "arm": "left",
            "output_rate_hz": [2, 3, 5],
            "candidate_output_rate_hz": [10, 20],
            "max_translation_mm": 2.0,
            "max_rotation_deg": 0.25,
            "watchdog_ms": 250.0,
        },
        "parameter_groups": parameter_groups(config),
        "control_semantics": {
            "trigger_true": "allow fresh pose tracking",
            "trigger_false": "send one stop and do not auto-resume",
            "recenter": "set the current controller pose as the neutral VR anchor",
            "old_or_out_of_order_packet": "reject; never queue for later playback",
            "mapping_update": "filter the newest pose once per output cycle; controller plans the motion",
        },
        "latency_boundary": {
            "2_hz_period_ms": 500.0,
            "3_hz_period_ms": 333.333,
            "5_hz_period_ms": 200.0,
            "10_hz_period_ms": 100.0,
            "20_hz_period_ms": 50.0,
            "meaning": (
                "movej_follow is a controller-planned latest-target interface, not "
                "joint pass-through; 10/20 Hz remain unvalidated candidates"
            ),
        },
    }
    if change is None:
        report["proposal"] = None
        report["next_step"] = "inspect only; change one parameter per candidate run"
        return report

    key, value = change
    proposed = dict(config)
    old = proposed[key]
    proposed[key] = value
    validate_config(proposed)
    report["proposal"] = {
        "key": key,
        "old": old,
        "new": value,
        "effect": tuning_effect(key, old, value),
        "configuration_valid": True,
        "released": old == value,
        "requires_revalidation": old != value,
        "required_retest": required_retest(key) if old != value else [],
    }
    report["proposed_config"] = proposed
    report["next_step"] = (
        "save as a new candidate file and execute the staged retest; do not overwrite the last passing config"
        if old != value
        else "no effective change"
    )
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Plan-only VR gateway tuning assistant")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument(
        "--set",
        dest="change",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="evaluate exactly one proposed parameter change",
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--execute", action="store_true", help="intentionally unsupported")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.execute:
        print("REFUSED: tuning assistant is PLAN-ONLY", file=sys.stderr)
        return 2
    try:
        if len(args.change) > 1:
            raise ValueError("change exactly one parameter per candidate")
        config = load_config(args.config)
        change = parse_change(args.change[0], config) if args.change else None
        report = build_report(config, change)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
