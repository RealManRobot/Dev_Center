#!/usr/bin/env python3
"""Pure logic for the customer movej_follow compatibility gateway."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from typing import Any, Mapping, Sequence


MAX_PACKET_BYTES = 4096
PICO_UDP_SCHEMA = "realbot.pico.udp.v1"
OPENXR_TO_ROBOT = (
    (0.0, 0.0, -1.0),
    (-1.0, 0.0, 0.0),
    (0.0, 1.0, 0.0),
)
EXPECTED_CONTROLLER_IP = {
    "left": "192.168.127.18",
    "right": "192.168.127.19",
}
FILTER_REFERENCE_HZ = 90.0


@dataclass(frozen=True)
class Pose:
    position_m: tuple[float, float, float]
    quaternion_wxyz: tuple[float, float, float, float]


@dataclass(frozen=True)
class VRPacket:
    sequence: int
    position_m: tuple[float, float, float]
    quaternion_wxyz: tuple[float, float, float, float]
    timestamp: float
    trigger: bool
    recenter: bool


@dataclass(frozen=True)
class BufferedPacket:
    packet: VRPacket
    received_monotonic: float


def finite_number(value: object, name: str) -> float:
    if type(value) not in (int, float):
        raise ValueError(f"{name} must be a number")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def numeric_tuple(value: object, length: int, name: str) -> tuple[float, ...]:
    if not isinstance(value, list) or len(value) != length:
        raise ValueError(f"{name} must contain {length} numbers")
    return tuple(
        finite_number(item, f"{name}[{index}]")
        for index, item in enumerate(value)
    )


def quaternion_normalize(
    quaternion: Sequence[float],
) -> tuple[float, float, float, float]:
    if len(quaternion) != 4:
        raise ValueError("quaternion must contain four values")
    values = tuple(finite_number(item, "quaternion") for item in quaternion)
    norm = math.sqrt(sum(item * item for item in values))
    if norm < 1e-9:
        raise ValueError("quaternion norm is zero")
    return tuple(item / norm for item in values)  # type: ignore[return-value]


def quaternion_conjugate(
    quaternion: Sequence[float],
) -> tuple[float, float, float, float]:
    return (
        quaternion[0],
        -quaternion[1],
        -quaternion[2],
        -quaternion[3],
    )


def quaternion_multiply(
    left: Sequence[float], right: Sequence[float]
) -> tuple[float, float, float, float]:
    lw, lx, ly, lz = left
    rw, rx, ry, rz = right
    return quaternion_normalize(
        (
            lw * rw - lx * rx - ly * ry - lz * rz,
            lw * rx + lx * rw + ly * rz - lz * ry,
            lw * ry - lx * rz + ly * rw + lz * rx,
            lw * rz + lx * ry - ly * rx + lz * rw,
        )
    )


def quaternion_to_matrix(
    quaternion: Sequence[float],
) -> tuple[tuple[float, float, float], ...]:
    w, x, y, z = quaternion_normalize(quaternion)
    return (
        (1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)),
        (2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)),
        (2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)),
    )


def matrix_to_quaternion(
    matrix: Sequence[Sequence[float]],
) -> tuple[float, float, float, float]:
    trace = matrix[0][0] + matrix[1][1] + matrix[2][2]
    if trace > 0:
        scale = math.sqrt(trace + 1.0) * 2
        result = (
            0.25 * scale,
            (matrix[2][1] - matrix[1][2]) / scale,
            (matrix[0][2] - matrix[2][0]) / scale,
            (matrix[1][0] - matrix[0][1]) / scale,
        )
    elif matrix[0][0] > matrix[1][1] and matrix[0][0] > matrix[2][2]:
        scale = math.sqrt(1 + matrix[0][0] - matrix[1][1] - matrix[2][2]) * 2
        result = (
            (matrix[2][1] - matrix[1][2]) / scale,
            0.25 * scale,
            (matrix[0][1] + matrix[1][0]) / scale,
            (matrix[0][2] + matrix[2][0]) / scale,
        )
    elif matrix[1][1] > matrix[2][2]:
        scale = math.sqrt(1 + matrix[1][1] - matrix[0][0] - matrix[2][2]) * 2
        result = (
            (matrix[0][2] - matrix[2][0]) / scale,
            (matrix[0][1] + matrix[1][0]) / scale,
            0.25 * scale,
            (matrix[1][2] + matrix[2][1]) / scale,
        )
    else:
        scale = math.sqrt(1 + matrix[2][2] - matrix[0][0] - matrix[1][1]) * 2
        result = (
            (matrix[1][0] - matrix[0][1]) / scale,
            (matrix[0][2] + matrix[2][0]) / scale,
            (matrix[1][2] + matrix[2][1]) / scale,
            0.25 * scale,
        )
    return quaternion_normalize(result)


def matrix_multiply(
    left: Sequence[Sequence[float]], right: Sequence[Sequence[float]]
) -> tuple[tuple[float, float, float], ...]:
    return tuple(
        tuple(
            sum(left[row][index] * right[index][column] for index in range(3))
            for column in range(3)
        )
        for row in range(3)
    )


def matrix_transpose(
    matrix: Sequence[Sequence[float]],
) -> tuple[tuple[float, float, float], ...]:
    return tuple(tuple(matrix[column][row] for column in range(3)) for row in range(3))


def map_openxr_vector(vector: Sequence[float]) -> tuple[float, float, float]:
    return tuple(
        sum(OPENXR_TO_ROBOT[row][column] * vector[column] for column in range(3))
        for row in range(3)
    )  # type: ignore[return-value]


def map_openxr_rotation(
    quaternion: Sequence[float],
) -> tuple[float, float, float, float]:
    rotation = quaternion_to_matrix(quaternion)
    mapped = matrix_multiply(
        matrix_multiply(OPENXR_TO_ROBOT, rotation),
        matrix_transpose(OPENXR_TO_ROBOT),
    )
    return matrix_to_quaternion(mapped)


def quaternion_angle_deg(quaternion: Sequence[float]) -> float:
    normalized = quaternion_normalize(quaternion)
    return math.degrees(2 * math.acos(min(1.0, abs(normalized[0]))))


def quaternion_nlerp(
    start: Sequence[float], end: Sequence[float], fraction: float
) -> tuple[float, float, float, float]:
    target = tuple(end)
    if sum(a * b for a, b in zip(start, target)) < 0:
        target = tuple(-item for item in target)
    return quaternion_normalize(
        tuple(a + (b - a) * fraction for a, b in zip(start, target))
    )


def time_adjusted_alpha(
    reference_alpha: float,
    dt_seconds: float,
    reference_hz: float = FILTER_REFERENCE_HZ,
) -> float:
    """Convert the legacy 90 Hz alpha into a rate-independent cycle alpha.

    The original gateway applied ``filter_alpha`` once for every received VR
    packet, so both the headset rate and network burst shape changed the
    response.  The corrected gateway maps only once per robot output cycle.
    This conversion preserves the same continuous-time pole that the legacy
    alpha represented at 90 Hz.
    """
    alpha = finite_number(reference_alpha, "reference_alpha")
    dt = finite_number(dt_seconds, "dt_seconds")
    hz = finite_number(reference_hz, "reference_hz")
    if not 0.0 < alpha <= 1.0:
        raise ValueError("reference_alpha must be in (0, 1]")
    if dt < 0.0:
        raise ValueError("dt_seconds must be non-negative")
    if hz <= 0.0:
        raise ValueError("reference_hz must be positive")
    if dt == 0.0:
        return 0.0
    if alpha == 1.0:
        return 1.0
    return 1.0 - (1.0 - alpha) ** (dt * hz)


def clamp_vector_norm(
    vector: Sequence[float], maximum: float
) -> tuple[tuple[float, ...], bool]:
    norm = math.sqrt(sum(value * value for value in vector))
    if norm <= maximum or norm < 1e-12:
        return tuple(vector), False
    scale = maximum / norm
    return tuple(value * scale for value in vector), True


def clamp_quaternion_angle(
    quaternion: Sequence[float], maximum_deg: float
) -> tuple[tuple[float, float, float, float], bool]:
    angle = quaternion_angle_deg(quaternion)
    if angle <= maximum_deg:
        return quaternion_normalize(quaternion), False
    return quaternion_nlerp(
        (1.0, 0.0, 0.0, 0.0), quaternion, maximum_deg / angle
    ), True


def parse_vr_packet(payload: bytes) -> VRPacket:
    if len(payload) > MAX_PACKET_BYTES:
        raise ValueError("VR packet is too large")
    try:
        parsed = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("VR packet is not valid UTF-8 JSON") from exc
    if not isinstance(parsed, dict):
        raise ValueError("VR packet must be a JSON object")
    schema = parsed.get("schema")
    if schema is not None and schema != PICO_UDP_SCHEMA:
        raise ValueError(f"schema must be {PICO_UDP_SCHEMA}")
    command = parsed.get("command", "pose")
    if command not in ("pose", "recenter"):
        raise ValueError("command must be pose or recenter")
    sequence = parsed.get("sequence")
    if type(sequence) is not int or sequence < 0:
        raise ValueError("sequence must be a non-negative integer")
    position = numeric_tuple(parsed.get("position_m"), 3, "position_m")
    xyzw = numeric_tuple(parsed.get("quaternion_xyzw"), 4, "quaternion_xyzw")
    timestamp = finite_number(parsed.get("timestamp"), "timestamp")
    trigger = parsed.get("trigger")
    if type(trigger) is not bool:
        raise ValueError("trigger must be true or false")
    recenter = parsed.get("recenter", command == "recenter")
    if type(recenter) is not bool:
        raise ValueError("recenter must be true or false")
    if recenter != (command == "recenter") and "command" in parsed:
        raise ValueError("command and recenter disagree")
    return VRPacket(
        sequence=sequence,
        position_m=position,  # type: ignore[arg-type]
        quaternion_wxyz=quaternion_normalize((xyzw[3], xyzw[0], xyzw[1], xyzw[2])),
        timestamp=timestamp,
        trigger=trigger,
        recenter=recenter,
    )


class LatestVRBuffer:
    """A one-slot, monotonic-sequence buffer. Old targets are never queued."""

    def __init__(self) -> None:
        self.latest: BufferedPacket | None = None
        self.last_sequence = -1
        self.accepted = 0
        self.invalid = 0
        self.out_of_order = 0
        self.duplicates = 0
        self.recenter_accepted = 0

    def ingest(self, payload: bytes, now: float) -> BufferedPacket | None:
        try:
            packet = parse_vr_packet(payload)
        except ValueError:
            self.invalid += 1
            return None
        if packet.sequence == self.last_sequence:
            self.duplicates += 1
            return None
        if packet.sequence < self.last_sequence:
            self.out_of_order += 1
            return None
        self.last_sequence = packet.sequence
        self.latest = BufferedPacket(packet=packet, received_monotonic=now)
        self.accepted += 1
        if packet.recenter:
            self.recenter_accepted += 1
        return self.latest

    def age(self, now: float) -> float:
        if self.latest is None:
            return math.inf
        return max(0.0, now - self.latest.received_monotonic)


class VRMapper:
    def __init__(self, robot_origin: Pose, config: Mapping[str, Any]) -> None:
        self.robot_origin = robot_origin
        self.filter_alpha = float(config["filter_alpha"])
        self.max_translation_m = float(config["max_translation_mm"]) / 1000.0
        self.max_rotation_deg = float(config["max_rotation_deg"])
        self.vr_origin: VRPacket | None = None
        self.last_target = robot_origin

    def recenter(self, packet: VRPacket, robot_origin: Pose | None = None) -> Pose:
        """Anchor the VR neutral pose to the robot pose measured *now*.

        ``robot_origin`` is optional only for the initial startup anchor.  A
        runtime recenter must pass the controller's current FK pose so the arm
        does not snap back to the process-start pose.
        """
        if robot_origin is not None:
            self.robot_origin = robot_origin
        self.vr_origin = packet
        self.last_target = self.robot_origin
        return self.robot_origin

    def map(
        self, packet: VRPacket, dt_seconds: float
    ) -> tuple[Pose, dict[str, bool]]:
        """Map one latest VR sample for one robot output cycle.

        Callers must not invoke this once per UDP packet.  The input-noise
        filter advances exactly once for each command opportunity.  This mapper
        deliberately does not create an external step-by-step trajectory:
        ``movej_follow`` owns trajectory planning to the latest target.
        """
        if not math.isfinite(dt_seconds) or dt_seconds <= 0.0:
            raise ValueError("dt_seconds must be positive and finite")
        if self.vr_origin is None:
            self.vr_origin = packet
            self.last_target = self.robot_origin
            return self.robot_origin, {
                "translation": False,
                "rotation": False,
            }
        delta = tuple(
            current - origin
            for current, origin in zip(packet.position_m, self.vr_origin.position_m)
        )
        mapped_delta, translation_clipped = clamp_vector_norm(
            map_openxr_vector(delta), self.max_translation_m
        )
        relative = quaternion_multiply(
            quaternion_conjugate(self.vr_origin.quaternion_wxyz),
            packet.quaternion_wxyz,
        )
        mapped_rotation, rotation_clipped = clamp_quaternion_angle(
            map_openxr_rotation(relative), self.max_rotation_deg
        )
        candidate = Pose(
            position_m=tuple(
                origin + offset
                for origin, offset in zip(self.robot_origin.position_m, mapped_delta)
            ),  # type: ignore[arg-type]
            quaternion_wxyz=quaternion_multiply(
                self.robot_origin.quaternion_wxyz, mapped_rotation
            ),
        )
        cycle_alpha = time_adjusted_alpha(self.filter_alpha, dt_seconds)
        filtered_position = tuple(
            previous + cycle_alpha * (target - previous)
            for previous, target in zip(
                self.last_target.position_m, candidate.position_m
            )
        )
        filtered_rotation = quaternion_nlerp(
            self.last_target.quaternion_wxyz,
            candidate.quaternion_wxyz,
            cycle_alpha,
        )
        self.last_target = Pose(
            position_m=filtered_position,  # type: ignore[arg-type]
            quaternion_wxyz=filtered_rotation,
        )
        return self.last_target, {
            "translation": translation_clipped,
            "rotation": rotation_clipped,
        }


def stream_action(age_seconds: float, trigger: bool, config: Mapping[str, Any]) -> str:
    if not trigger:
        return "stop_deadman_released"
    if age_seconds > float(config["watchdog_ms"]) / 1000.0:
        return "stop_vr_watchdog"
    if age_seconds > float(config["fresh_target_ms"]) / 1000.0:
        return "hold_stale"
    return "send_fresh"


def joint_distance_deg(left: Sequence[float], right: Sequence[float]) -> float:
    if len(left) != 7 or len(right) != 7:
        raise ValueError("expected seven joints")
    return max(abs(a - b) for a, b in zip(left, right))


def tracking_action(
    measured: Sequence[float],
    last_sent_target: Sequence[float],
    initial_joint: Sequence[float],
    config: Mapping[str, Any],
) -> tuple[str, dict[str, float]]:
    """Observe controller following without blocking latest-goal updates.

    ``movej_follow`` is asynchronous: a non-zero difference between the
    measured joints and the last target is normal while the controller is
    planning and moving.  The gateway therefore reports ordinary lag but does
    not wait for the arm to catch the previous target before replacing it.
    Only an actual measured-joint excursion outside the authorized envelope is
    a stop condition here; controller joint/brake errors are checked separately.
    """
    tracking_error = joint_distance_deg(measured, last_sent_target)
    measured_excursion = joint_distance_deg(measured, initial_joint)
    measured_limit = float(config["max_joint_excursion_deg"]) + float(
        config["max_return_error_deg"]
    )
    metrics = {
        "tracking_error_deg": tracking_error,
        "measured_excursion_deg": measured_excursion,
        "measured_excursion_limit_deg": measured_limit,
    }
    if measured_excursion > measured_limit:
        return "stop_measured_excursion", metrics
    if tracking_error > float(config["max_tracking_error_deg"]):
        return "warn_tracking_lag", metrics
    return "tracking_ok", metrics


def pose_goal_metrics(target: Pose, last_sent: Pose) -> dict[str, float]:
    position_delta_mm = 1000.0 * math.sqrt(
        sum(
            (target_value - last_value) ** 2
            for target_value, last_value in zip(
                target.position_m, last_sent.position_m
            )
        )
    )
    rotation_delta_deg = quaternion_angle_deg(
        quaternion_multiply(
            quaternion_conjugate(last_sent.quaternion_wxyz),
            target.quaternion_wxyz,
        )
    )
    return {
        "position_delta_mm": position_delta_mm,
        "rotation_delta_deg": rotation_delta_deg,
    }


def goal_action(
    target: Pose, last_sent: Pose, config: Mapping[str, Any]
) -> tuple[str, dict[str, float]]:
    """Gate a latest goal without constructing a trajectory outside the arm.

    Small changes are coalesced so headset jitter does not repeatedly restart
    the controller planner.  Discontinuous changes are rejected rather than
    clipped into a delayed queue of intermediate waypoints.
    """
    metrics = pose_goal_metrics(target, last_sent)
    if metrics["position_delta_mm"] > float(config["max_target_jump_mm"]):
        return "stop_position_jump", metrics
    if metrics["rotation_delta_deg"] > float(config["max_target_jump_deg"]):
        return "stop_rotation_jump", metrics
    if (
        metrics["position_delta_mm"]
        <= float(config["position_deadband_mm"])
        and metrics["rotation_delta_deg"]
        <= float(config["rotation_deadband_deg"])
    ):
        return "hold_deadband", metrics
    return "send_latest", metrics


def validate_joint_target(
    target: Sequence[float],
    previous_target: Sequence[float],
    initial_joint: Sequence[float],
    config: Mapping[str, Any],
) -> dict[str, float]:
    if len(target) != 7 or not all(math.isfinite(value) for value in target):
        raise RuntimeError("IK target is not a finite seven-joint vector")
    step = joint_distance_deg(target, previous_target)
    excursion = joint_distance_deg(target, initial_joint)
    if step > float(config["max_joint_target_jump_deg"]):
        raise RuntimeError(
            f"joint target jump {step:.6f} deg exceeds configured limit"
        )
    if excursion > float(config["max_joint_excursion_deg"]):
        raise RuntimeError(
            f"joint excursion {excursion:.6f} deg exceeds configured limit"
        )
    return {"target_jump_deg": step, "excursion_deg": excursion}


def validate_config(config: Mapping[str, Any]) -> None:
    required = {
        "arm",
        "controller_ip",
        "controller_port",
        "bind_host",
        "udp_port",
        "vr_source_ip",
        "duration_seconds",
        "output_rate_hz",
        "state_poll_rate_hz",
        "state_watchdog_ms",
        "fresh_target_ms",
        "watchdog_ms",
        "filter_alpha",
        "max_translation_mm",
        "max_rotation_deg",
        "position_deadband_mm",
        "rotation_deadband_deg",
        "max_target_jump_mm",
        "max_target_jump_deg",
        "max_joint_target_jump_deg",
        "max_joint_excursion_deg",
        "max_tracking_error_deg",
        "max_return_error_deg",
        "collision_stage_during_motion",
        "postflight_observe_seconds",
    }
    missing = sorted(required - set(config))
    if missing:
        raise ValueError(f"missing config keys: {', '.join(missing)}")
    arm = config["arm"]
    if arm not in EXPECTED_CONTROLLER_IP:
        raise ValueError("arm must be left or right")
    if config["controller_ip"] != EXPECTED_CONTROLLER_IP[arm]:
        raise ValueError("controller_ip does not match the selected arm")
    if type(config["controller_port"]) is not int or config["controller_port"] != 8080:
        raise ValueError("controller_port must be 8080")
    if type(config["udp_port"]) is not int or not 1 <= config["udp_port"] <= 65535:
        raise ValueError("udp_port must be in [1, 65535]")
    if config["vr_source_ip"] is not None and not isinstance(config["vr_source_ip"], str):
        raise ValueError("vr_source_ip must be a string or null")
    numeric_rules = {
        "duration_seconds": (0.01, 3600.0),
        "state_poll_rate_hz": (5.0, 20.0),
        "state_watchdog_ms": (100.0, 500.0),
        "fresh_target_ms": (1.0, 100.0),
        "watchdog_ms": (250.0, 250.0),
        "filter_alpha": (0.01, 1.0),
        "max_translation_mm": (0.0, 2.0),
        "max_rotation_deg": (0.0, 0.5),
        "position_deadband_mm": (0.0, 0.5),
        "rotation_deadband_deg": (0.0, 0.1),
        "max_target_jump_mm": (0.1, 2.0),
        "max_target_jump_deg": (0.05, 0.5),
        "max_joint_target_jump_deg": (0.05, 1.0),
        "max_joint_excursion_deg": (0.01, 1.0),
        "max_tracking_error_deg": (0.01, 0.5),
        "max_return_error_deg": (0.01, 0.3),
        "postflight_observe_seconds": (60.0, 3600.0),
    }
    for key, (minimum, maximum) in numeric_rules.items():
        value = finite_number(config[key], key)
        if not minimum <= value <= maximum:
            raise ValueError(f"{key} must be in [{minimum}, {maximum}]")
    output_rate = finite_number(config["output_rate_hz"], "output_rate_hz")
    if output_rate not in (2.0, 3.0, 5.0, 10.0, 20.0):
        raise ValueError("output_rate_hz must be one of 2, 3, 5, 10, or 20")
    collision = config["collision_stage_during_motion"]
    if type(collision) is not int or collision != 4:
        raise ValueError("collision_stage_during_motion must be 4")
