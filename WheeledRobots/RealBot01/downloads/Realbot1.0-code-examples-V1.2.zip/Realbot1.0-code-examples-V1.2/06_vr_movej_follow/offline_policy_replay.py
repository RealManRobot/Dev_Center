#!/usr/bin/env python3
"""Offline replay for the controller-planned latest-target policy.

This program opens no socket and sends no robot command.  It verifies that the
gateway filters only the newest VR sample, coalesces numerical jitter, rejects
discontinuous goals, and gives trajectory planning to ``movej_follow``.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any, Mapping

from gateway_core import (
    Pose,
    VRMapper,
    VRPacket,
    goal_action,
    pose_goal_metrics,
    validate_config,
)
from virtual_pico_testbench import trajectory_sample


TRANSLATION_TRAJECTORIES = ("x", "y", "z", "xy", "circle")
ROTATION_TRAJECTORIES = ("rotation-x", "rotation-y", "rotation-z")


def replay(
    config: Mapping[str, Any],
    trajectory: str,
    *,
    input_rate_hz: float = 90.0,
    lead_seconds: float = 2.0,
    motion_seconds: float = 16.0,
    settle_seconds: float = 2.0,
    distance_mm: float = 2.0,
    rotation_deg: float = 0.25,
) -> dict[str, Any]:
    validate_config(config)
    if trajectory not in TRANSLATION_TRAJECTORIES + ROTATION_TRAJECTORIES:
        raise ValueError(f"unsupported trajectory: {trajectory}")
    if input_rate_hz <= 0.0:
        raise ValueError("input_rate_hz must be positive")

    origin = Pose((0.0, 0.0, 0.0), (1.0, 0.0, 0.0, 0.0))
    origin_packet = VRPacket(
        0, (0.0, 0.0, 0.0), (1.0, 0.0, 0.0, 0.0), 0.0, True, True
    )
    mapper = VRMapper(origin, config)
    mapper.recenter(origin_packet, origin)
    last_sent = origin
    output_rate_hz = float(config["output_rate_hz"])
    output_period = 1.0 / output_rate_hz
    total_seconds = lead_seconds + motion_seconds + settle_seconds
    cycles = round(total_seconds * output_rate_hz)
    counters = {"send_latest": 0, "hold_deadband": 0, "stop": 0}
    max_position_delta_mm = 0.0
    max_rotation_delta_deg = 0.0

    for sequence in range(1, cycles + 1):
        output_time = sequence * output_period
        capture_time = math.floor(output_time * input_rate_hz + 1e-9) / input_rate_hz
        if (
            capture_time < lead_seconds
            or capture_time >= lead_seconds + motion_seconds
        ):
            sample = trajectory_sample("origin", 0.0, 1.0, 0.0, 0.0)
        else:
            sample = trajectory_sample(
                trajectory,
                capture_time - lead_seconds,
                motion_seconds,
                distance_mm / 1000.0,
                rotation_deg,
            )
        packet = VRPacket(
            sequence,
            sample.position_m,
            (
                sample.quaternion_xyzw[3],
                sample.quaternion_xyzw[0],
                sample.quaternion_xyzw[1],
                sample.quaternion_xyzw[2],
            ),
            capture_time,
            True,
            False,
        )
        target, _ = mapper.map(packet, output_period)
        action, metrics = goal_action(target, last_sent, config)
        max_position_delta_mm = max(
            max_position_delta_mm, metrics["position_delta_mm"]
        )
        max_rotation_delta_deg = max(
            max_rotation_delta_deg, metrics["rotation_delta_deg"]
        )
        if action == "send_latest":
            counters[action] += 1
            last_sent = target
        elif action == "hold_deadband":
            counters[action] += 1
        else:
            counters["stop"] += 1

    return_error = pose_goal_metrics(last_sent, origin)
    return {
        "trajectory": trajectory,
        "input_rate_hz": input_rate_hz,
        "output_rate_hz": output_rate_hz,
        "control_cycles": cycles,
        "commands": counters["send_latest"],
        "deadband_holds": counters["hold_deadband"],
        "jump_stops": counters["stop"],
        "max_position_goal_delta_mm": max_position_delta_mm,
        "max_rotation_goal_delta_deg": max_rotation_delta_deg,
        "return_error_mm": return_error["position_delta_mm"],
        "return_error_deg": return_error["rotation_delta_deg"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument(
        "--trajectory",
        choices=TRANSLATION_TRAJECTORIES + ROTATION_TRAJECTORIES,
        action="append",
    )
    parser.add_argument("--input-rate-hz", type=float, default=90.0)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    config = json.loads(args.config.read_text(encoding="utf-8"))
    trajectories = args.trajectory or list(TRANSLATION_TRAJECTORIES)
    results = [
        replay(config, name, input_rate_hz=args.input_rate_hz)
        for name in trajectories
    ]
    report = {
        "program": "offline_policy_replay",
        "result": "PASS" if all(item["jump_stops"] == 0 for item in results) else "FAIL",
        "live_motion": False,
        "controller_policy": "movej_follow_plans_latest_target",
        "results": results,
    }
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    print(rendered, end="")
    if args.report is not None:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(rendered, encoding="utf-8")
    return 0 if report["result"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
