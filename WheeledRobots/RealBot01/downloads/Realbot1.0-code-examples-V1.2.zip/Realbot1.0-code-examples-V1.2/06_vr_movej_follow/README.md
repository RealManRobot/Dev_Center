# 06 Pico VR 调整与 `movej_follow` 控制

本示例先用开发电脑生成与 Pico 输入适配器相同的 UDP 数据，在不依赖头显的情况下验证位姿、扳机、序号、时间戳、回中、逆解、最新目标合并和断流停止。真实 Pico 接入时只替换输入适配器，机器人端网关不变。

> `movej_follow` 是控制器在线规划并追踪最新关节目标的接口，不是逐点关节透传。90 Hz 输入不等于 90 Hz 机械臂输出；机器人输出使用独立固定周期。
>
> 2026-08-18 控制链审查修正了四项实现：UDP 突发不再逐包推进滤波；删除外部笛卡尔步进轨迹；不再等待上一目标到位才更新；状态回读移出命令发送热路径。运行中回中会先用当前实测关节覆盖旧目标，再建立新锚点。修正版已通过离线回归，尚待按“原位 → 2 mm → 长稳”重新完成实机验证，因此当前修正版属于候选，不继承 2026-08-06 的实机 PASS。

## 控制链路

```text
Pico/OpenXR 手柄位姿 + 扳机 + 回中
        ↓  UDP realbot.pico.udp.v1
最新目标缓存（拒绝重复、乱序和过期包）
        ↓  每个机器人输出周期只映射一次
坐标映射、工作空间限幅和按时间修正的低通
厂商逆解（启动关节作为固定种子）
        ↓  最新关节目标；控制器负责在线规划
左臂 movej_follow（2/3/5 Hz 已有旧基线，10/20 Hz 为候选）
        ↕  独立 10 Hz 状态监控
单次停止 → 60 秒观察
```

当前客户正式结论仍只覆盖变更前左臂 2/3/5 Hz 专项基线；修正版 10/20 Hz 属于候选。Pico 输入可以高频采样，但机器人端只在固定输出周期取最新有效目标，不积压、不补发历史轨迹。

## 手柄控制语义

| 输入 | 机器人端行为 |
|---|---|
| `trigger=true` | 仅当目标新鲜且全部状态门禁通过时跟随 |
| `trigger=false` | 发送一次停止并结束本轮，不自动恢复 |
| `command=recenter`、`recenter=true` | 将当前手柄位姿设为 VR 中心，将当前机械臂位姿设为机器人中心 |
| 重复或乱序 `sequence` | 拒绝，不进入待执行队列 |
| 目标年龄 100～250 ms | 保持，不发送旧目标 |
| 目标年龄超过 250 ms | 发送一次停止并结束本轮 |

每次佩戴位置改变、操作者更换、追踪空间重建或机器人起始姿态变化后，都要重新回中。建议把
回中绑定到独立按钮，把扳机作为持续按住才允许运动的“使能保持”按钮，不使用单击切换模式。

## 坐标方向与回中检查

当前 OpenXR 到机器人基坐标的平移映射为：

```text
机器人 +X（前） = VR -Z（前）
机器人 +Y（左） = VR -X（左）
机器人 +Z（上） = VR +Y（上）
```

即 `robot_delta=[-vr_z,-vr_x,vr_y]`；旋转使用同一坐标变换。真实 Pico 首次接入时先保持
`max_translation_mm=0`、`max_rotation_deg=0` 完成回中，再分别做 X、Y、Z 正方向确认。
任一方向相反都停止，不通过扩大位移来“看清方向”。当前代码不开放在线修改坐标轴矩阵；如客户
应用的坐标系不是标准 OpenXR，应在 Pico 输入适配器中明确转换并重新执行方向验收。

## 调整参数

| 参数 | 当前基线 | 调整影响 | 代码包规则 |
|---|---:|---|---|
| `output_rate_hz` | 已有旧基线 2 / 3 / 5；候选 10 / 20 | 越高越灵敏，也增加控制器与通信负载 | 修正版按 5→10→20 重新分级，不跨级发布 |
| `state_poll_rate_hz` / `state_watchdog_ms` | 10 Hz / 250 ms | 独立回读关节状态；超过状态年龄看门狗即停 | 锁定；不得把同步状态查询放回发送热路径 |
| `filter_alpha` | 0.25 | 以 90 Hz 为参考的历史滤波系数；程序按机器人输出周期换算，增大更跟手，减小更平滑 | 不再按 UDP 包逐次生效；一次只改一个参数，修改后重验 |
| `max_translation_mm` | ≤2 | 平移工作包络 | 首次 0，再单轴 2 mm；禁止超过 2 mm |
| `max_rotation_deg` | 默认 0，专项 0.25 | 姿态工作包络 | 平移与旋转分开首测；禁止超过 0.5°，发布结果仅到 0.25° |
| `position_deadband_mm` / `rotation_deadband_deg` | 0.01 mm / 0.005° | 合并数值抖动，避免重复重置控制器规划 | 只做死区，不生成外部中间路点 |
| `max_target_jump_mm` / `max_target_jump_deg` | 2 mm / 0.25° | 拒绝输入或坐标系突变 | 超限直接停止，不硬裁剪成延迟轨迹 |
| `fresh_target_ms` | 100 | 超过后保持旧姿态、不再发送 | 不得大于 100 ms |
| `watchdog_ms` | 250 | 超过后单次停止 | 固定 250 ms，不作为客户调参项 |
| 关节目标跳变/目标偏移/跟踪告警/回原阈值 | 1° / 1° / 0.5° / 0.3° | 机械臂安全门禁与观测 | 跟踪落后只记录告警，不阻断最新目标；实测关节越界、控制器错误仍立即停止 |
| `collision_stage_during_motion` | 4 | 碰撞等级 | 固定 4，结束后恢复原值 |

先用只读调整助手查看参数分组：

```bash
python3 vr_tuning_assistant.py --config config.5hz.json
```

评估一个候选改动时，每次只能给一个 `--set`。工具只判断配置是否合法并列出必须重验的项目，
不会改原文件，也不会连接机器人：

```bash
python3 vr_tuning_assistant.py \
  --config config.3hz.json \
  --set output_rate_hz=5 \
  --output tuning-plan.json
```

输出 `configuration_valid=true` 不表示新参数已经发布；只要数值发生变化，结果都会标记
`requires_revalidation=true`。新参数另存为候选文件，保留最后一份 PASS 配置用于回退。

## 响应速度边界

2、3、5、10、20 Hz 的目标更新周期分别是 500、约 333、200、100、50 ms。这里的周期是“向控制器提交最新目标”的周期，不是外部路点的完成周期；控制器会在相邻更新之间连续规划。因此：

- 这条链适合验证坐标、逆解、安全保护和低速小范围演示；
- 旧版 5 Hz 链会有明显输入等待；10/20 Hz 候选用于降低目标年龄，但未取得新实机发布结论；
- 当前机器人 Aloha 源码中的 `MODE_FOLLOW` 以 10 ms 命令定时器直接转发 `movej_follow`，证明接口设计上支持连续最新目标；该证据不等于本独立网关已通过 100 Hz 实机验收；
- 正式 VR 伺服要在候选频率逐级实机通过后发布；若后续改用原生遥操会话、QP 或关节透传，必须另做接口和故障闭环；
- 在高频接口尚未发布前，不通过放宽 2 mm 包络、关节阈值或看门狗来掩盖延迟。

## 已冻结的安全边界

- UDP 输入可为 90 Hz，但缓冲区只保留最后一个有效目标；重复、乱序和过期目标不进入队列。
- 2/3/5 Hz 仅有变更前实机基线；10/20 Hz 是修正版候选。任何一档都只取最新目标，不追补历史目标。
- 目标有效年龄取“到达后年龄”与“源时间戳相对年龄”的较大值；100～250 ms 保持，超过 250 ms 停止。
- 源时间戳使用最小观测传输时延在线估计时钟偏移，不要求 Pico 与机器人绝对时钟完全相同。
- `trigger=false` 或超过 250 ms 断流时只发送一次停止命令，程序不自动清错、不自动恢复运动。
- 平移上限为 2 mm；默认旋转为 0°，专用配置仅开放 0.25° 原位轻微旋转。
- 每轮逆解始终使用启动时关节角作种子；关节目标单次跳变和相对启动姿态均不超过 1°。
- 10 Hz 独立状态线程读取关节错误、制动状态和实际关节角，状态年龄超过 250 ms 即停；普通跟踪落后只记录告警，不等待上一目标到位。逆解正解回代位置误差上限 0.1 mm。
- 正常结束和安全中止后均恢复原碰撞等级，并观察不少于 60 秒。

## Pico UDP 数据合同

Schema 版本为 `realbot.pico.udp.v1`。每个数据报必须包含以下字段：

```json
{
  "schema": "realbot.pico.udp.v1",
  "command": "pose",
  "sequence": 123,
  "timestamp": 1785984000.125,
  "position_m": [0.012, -0.034, 1.056],
  "quaternion_xyzw": [0.0, 0.0, 0.0, 1.0],
  "trigger": true,
  "recenter": false
}
```

回中包将 `command` 设为 `recenter`，并将 `recenter` 设为 `true`。`sequence` 是非负且单调递增的整数；`timestamp` 是源端采集时间，不是发送完成时间；位置单位是米，四元数顺序是 `x,y,z,w`。

## 1. 离线检查

```bash
python3 -m unittest test_gateway_core.py -v
python3 vr_movej_follow_gateway.py --config config.example.json
```

当前合并回归集包含 30 项测试，包括输入突发单周期合并、异常网络只保留最新目标、按时间修正滤波、运行中回中锚点、非阻塞跟踪监控和异步状态线程。第二条命令只应输出 `CONFIG_PASS`，不会连接机械臂。

## 2. 实机网关

根据验证阶段选择配置：

| 配置 | 用途 |
|---|---|
| `config.example.json` | 2 Hz 默认基线 |
| `config.3hz.json` | 3 Hz 阶梯 |
| `config.5hz.json` | 5 Hz 阶梯、2 mm 轨迹和网络异常 |
| `config.5hz.rotation.json` | 5 Hz、0 mm 平移、0.25° 原位旋转 |
| `config.5hz.long30m.json` | 5 Hz、30 分钟长稳 |
| `config.10hz.candidate.json` | 修正版 10 Hz 候选；未发布 |
| `config.20hz.candidate.json` | 修正版 20 Hz 候选；未发布 |

先在现场确认机器人周围无人、控制权唯一、左臂无报错并处于静止，再显式执行：

```bash
python3 vr_movej_follow_gateway.py \
  --config config.5hz.json \
  --execute \
  --confirm-site-clear \
  --confirm-control-exclusive \
  --confirm-two-mm-envelope \
  --confirm-low-rate-follow \
  --confirm-collision-stage-4 \
  --confirm-single-stop \
  --confirm-return-to-origin \
  --report run-report.json
```

看到 `udp_ready` 后才启动开发电脑的发送器。首次必须原位保持：

```bash
python3 virtual_pico_testbench.py \
  --host 192.168.127.10 \
  --trajectory origin \
  --distance-mm 0 \
  --report virtual-pico-origin.json
```

原位通过后，才使用 `--trajectory x|y|z|xy|circle --distance-mm 2`。本版不允许平移超过 2 mm。

## 3. 异常网络注入

可恢复复合工况示例：

```bash
python3 virtual_pico_testbench.py \
  --host 192.168.127.10 \
  --trajectory z --distance-mm 2 \
  --delay-ms 30 --jitter-ms 15 \
  --drop-every 19 --duplicate-every 17 --reorder-every 23 \
  --dropout-at 8 --dropout-ms 150 \
  --report virtual-pico-network.json
```

超过 250 ms 断流测试可使用 `--dropout-at 8 --dropout-ms 400`；预期网关报告整体为 `FAIL`，但 `stop_reason` 必须是 `stop_vr_watchdog`、`stop_command_count` 必须是 1，异常后 60 秒观察必须为 `PASS`。扳机释放测试使用 `--trigger-release-at 8`，期望原因为 `stop_deadman_released`。

## 4. 30 分钟长稳

```bash
python3 virtual_pico_testbench.py \
  --host 192.168.127.10 \
  --rate-hz 90 \
  --lead-seconds 4 \
  --motion-seconds 1792 \
  --settle-seconds 6 \
  --cycle-seconds 16 \
  --trajectory circle \
  --distance-mm 2 \
  --report virtual-pico-long30m.json
```

调度落后一个采集周期时，测试台会跳过错过的截止点，不会突发补发历史帧。最终报告必须检查输入帧、覆盖帧、输出数、有效目标年龄、跟踪误差、IK 残差、关节错误、单次停止和 60 秒观察。

## 5. 2026-08-06 变更前实机基线

- 3 Hz 和 5 Hz 原位门禁通过；3 Hz/5 Hz 的 2 mm Z 往返各 3 轮通过。
- X、Y、Z、XY、2 mm 小圆和 0.25° 原位旋转均通过。
- 复合网络异常中，79 个重复包和 408 个乱序包被拒绝，机器人输出序号严格递增。
- 400 ms 断流和扳机释放均只停止一次，未自动清错，异常后 60 秒健康观察通过。
- 修正版 30 分钟小圆长稳通过：161,993 个有效输入、9,000 条输出、0 个关节/制动异常样本；P99/最大输出周期 202.543/210.958 ms，最短输出间隔 187.036 ms，低于 150 ms 的突发间隔为 0。
- 发送器跳过 7 个错过的采集截止点，待发队列为 0；网关陈旧保持和陈旧事件均为 0，输出序号严格递增，没有补发旧目标。停止 1 次、清错 0 次，60.035 秒观察通过。

上述结论仅适用于 2026-08-06 当时的专项基线左臂，不能作为 2026-08-18 修正版的实机验收证据。修正版需要重新执行 5 Hz 原位与 2 mm，再按 10 Hz、20 Hz 逐级验证，最后重做异常网络和 30 分钟长稳。真实 Pico 仍需单独完成坐标标定、无线网络和手柄交互验收；右臂、超过 20 Hz、超过 2 mm 和更大旋转不继承本结论。J7 `0xF000` 的硬件/固件因素仍是独立未闭环项。
