# 01 十分钟只读快速开始

`quick_readonly.sh` 只验证本地开发电脑到机器人的网络和已实机验证的 REST 版本查询；该脚本不执行 SSH 登录、ROS2 命令、运动、配置修改或数据写入。本目录还提供登录机器人后使用的 ROS2 只读命令和健康快照脚本。

## 在本地开发电脑执行

风险等级：只读。本地开发电脑需安装 `bash`、`ping`、`curl` 和 `python3`，并已接入机器人路由器 LAN 口。`python3` 只从标准输入解析 REST JSON，不创建文件。

```bash
export ROBOT_IP=192.168.127.10
bash examples/01_quick_start/quick_readonly.sh
```

上述命令默认终端当前目录是解压后的交付包根目录，不需要先进入脚本子目录。

成功时脚本输出 ping 结果、版本 JSON 和 `PASS: local read-only checks completed`，退出码为 `0`。失败退出码：

| 退出码 | 含义 | 处理 |
|---:|---|---|
| 64 | 未设置 `ROBOT_IP` | 执行上述 `export` 后重试 |
| 69 | 本地开发电脑缺少 `ping`、`curl` 或 `python3` | 安装缺失命令后重试 |
| 10 | ping 失败 | 检查网线、LAN 口和本机网段 |
| 20 | REST 请求超时或 HTTP 失败 | 确认 9091 端口仅在受信任机器人网络内可达 |
| 21 | 响应不是有效 JSON，或不满足严格的成功版本结果结构 | 脚本已向标准输出保留原始响应；复制该响应并联系技术支持 |

## 登录机器人后继续

SSH 用户为 `realman`。以下命令仅在登录机器人后执行，不要在 macOS、Windows 或未配置 ROS2 Humble 的本地开发电脑直接执行。

```bash
source /opt/ros/humble/setup.bash
source /home/realman/workspace/rm_robot_ws/install/setup.bash
ros2 topic list | wc -l
timeout 10s ros2 topic echo --once /robot_driver/battery_state
timeout 10s ros2 topic echo --once --full-length /robot_slave/states
```

- Topic 数量应大于 `0`，且列表中应存在上述两个 Topic。数量会随软件版本、硬件配置和当前节点状态变化，不用固定数值作为通用验收门槛。
- 电量 Topic 类型为 `rm_robot_interfaces/msg/RobotPower`；关节状态 Topic 类型为 `std_msgs/msg/String`，输出 JSON。
- `timeout` 退出码 `124` 表示 10 秒内没有收到数据。此时不要切换模式或重启服务，先检查 Topic 是否存在并记录软硬件版本。

本目录的所有步骤都不改变机器人运行状态：不包含运动、停止服务、配置修改或明文凭据自动化。健康快照默认不写文件；只有显式指定 `--report-dir` 时才会在所选目录创建支持报告。

## 生成整机只读健康快照

`robot_health_snapshot.sh` 在机器人端运行，用于现场验收和向技术支持提供可复核摘要。它仅执行系统信息读取、ROS 图发现和 Topic 订阅；不发布 Topic、不调用 ROS Service、不修改参数、不控制执行器、不重启业务进程、不录制数据。首次运行 ROS2 CLI 时，ROS2 可能自动启动临时 daemon 或产生框架日志，但不会改变机器人业务配置或执行器状态。

推荐从客户开发电脑的交付包根目录通过 SSH 标准输入执行，不需要先把整个交付包复制到机器人：

```bash
export ROBOT_IP=192.168.127.10
ssh "realman@${ROBOT_IP}" 'bash -s' \
  < examples/01_quick_start/robot_health_snapshot.sh
```

默认只向终端输出。如需生成支持报告，必须显式指定目录：

```bash
ssh "realman@${ROBOT_IP}" \
  'bash -s -- --report-dir "$HOME/realbot-health-reports"' \
  < examples/01_quick_start/robot_health_snapshot.sh
```

显式使用 `--report-dir` 时，脚本只会排他新建该目录下的 `robot-health-{UTC}-{unique}.txt` 支持文件，其中 `unique` 是自动生成的唯一后缀；文件权限设为 `0600`，同秒重复运行不会覆盖已有报告，也不会向录制 SSD 写数据。日志摘要限定为最近 15 分钟、80 行，并对密码、token、secret、API key、Bearer 凭据和 URL 用户信息的常见形式进行脱敏。交付前仍需人工复核报告，不应将未知格式的凭据写入日志。

快照顺序检查：

1. Ubuntu/内核与 ROS 2 环境，按 ROS 2 underlay、机器人工作空间、数据采集工作空间的顺序加载。
2. `realman.service` 和已失败的 systemd Service。
3. ROS 节点、Topic、Service 数量；Service 只列出，不发送请求。
4. 电池、`/diagnostics`、`/fault/aggregated` 的单次限时订阅。
5. 四路宽视 H.264、麦克风心跳、`/odom` 和 `/scan` 的正频率观察。
6. 默认用 `findmnt`、块设备检查和 `df` 确认 `/home/realman/ssd` 是独立块设备挂载，并查看文件系统和剩余空间；不递归扫描录制盘。
7. CPU 负载、内存、温度、高 CPU 进程和脱敏 journal 摘要。

结果与退出码：

| 结果 | 退出码 | 含义 |
|---|---:|---|
| `PASS` | 0 | 本次快照未发现告警或失败 |
| `WARN` | 1 | 已完成快照，但存在缺少工具、Topic 缺失、限时内无数据或资源阈值告警，需人工复核 |
| `FAIL` | 2 | ROS 2 不可用、无节点/Topic、主服务非 active、SSD 未挂载或资源达到严重阈值 |
| 参数错误 | 64 | 命令行参数无效或报告目录无法创建 |

当且仅当唯一警告是已知 `/scan` 无正频率，且当次任务与必需 Topic 不依赖 `/scan` 时，可登记限制后继续录制验收。任何 `FAIL` 或其他未解释的 `WARN` 都必须停止后续写盘步骤。

任一 Topic 存在但限时内没有观察到正频率时，结论都是 `WARN`，不会因此自动重启节点、转动雷达或修改 QoS。也不能仅以 `/fault/aggregated` 无故障、心跳正常或 Topic 有发布者判定端到端能力正常。

只有确认机器人没有正在录制、上传或执行关键实时任务时，才可显式增加 `--include-directory-usage`。该选项会对录制盘执行最长 10 秒的 `du -sh`，可能带来额外 I/O；默认关闭。
