#!/usr/bin/env bash
set -euo pipefail

if [[ -z "${ROBOT_IP:-}" ]]; then
  printf '%s\n' 'ERROR: ROBOT_IP is required. Run: export ROBOT_IP=192.168.127.10' >&2
  exit 64
fi

if ! command -v ping >/dev/null 2>&1; then
  printf '%s\n' 'ERROR: ping is not installed or not in PATH.' >&2
  exit 69
fi
if ! command -v curl >/dev/null 2>&1; then
  printf '%s\n' 'ERROR: curl is not installed or not in PATH.' >&2
  exit 69
fi
if ! command -v python3 >/dev/null 2>&1; then
  printf '%s\n' 'ERROR: python3 is not installed or not in PATH.' >&2
  exit 69
fi

printf '[1/2] Checking network reachability: %s\n' "$ROBOT_IP"
if ! ping -c 2 "$ROBOT_IP"; then
  printf '%s\n' 'ERROR: robot did not answer ping; check cable, LAN port, and local subnet.' >&2
  exit 10
fi

printf '[2/2] Reading robot version through verified REST endpoint\n'
if ! response="$(
  curl --silent --show-error --fail-with-body \
    --connect-timeout 3 --max-time 10 \
    -X POST "http://${ROBOT_IP}:9091/robot/version" \
    -H 'Content-Type: application/json' \
    -d '{}'
)"; then
  printf '%s\n' 'ERROR: REST version query failed; check port 9091 and endpoint readiness.' >&2
  exit 20
fi

printf '%s\n' "$response"
if ! printf '%s' "$response" | python3 -c '
import json
import sys

try:
    outer = json.load(sys.stdin)
    if not isinstance(outer, dict) or type(outer.get("code")) is not int:
        raise ValueError
    if outer["code"] != 200:
        raise ValueError
    data = outer.get("data")
    if isinstance(data, str):
        data = json.loads(data)
    if not isinstance(data, dict):
        raise ValueError
    product_version = data.get("product_version")
    if not isinstance(product_version, str) or not product_version.strip():
        raise ValueError
except (json.JSONDecodeError, TypeError, ValueError):
    raise SystemExit(1)
'; then
  printf '%s\n' 'ERROR: REST response is not a successful version response.' >&2
  exit 21
fi

printf '%s\n' 'PASS: local read-only checks completed. Continue with the robot-side ROS2 steps in README.md.'
