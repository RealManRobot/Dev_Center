#!/usr/bin/env bash
# Realbot1.0 robot-side, read-only health snapshot.
# The only intentional persistent output is the explicitly requested report file.
set -uo pipefail

readonly DEFAULT_ROS_SETUP="/opt/ros/humble/setup.bash"
readonly DEFAULT_ROBOT_WS_SETUP="/home/realman/workspace/rm_robot_ws/install/setup.bash"
readonly DEFAULT_DATA_WS_SETUP="/home/realman/workspace/rm_data_collect/install/setup.bash"
readonly DEFAULT_SSD_PATH="/home/realman/ssd"
readonly DEFAULT_SERVICE="realman.service"

REPORT_DIR=""
SAMPLE_TIMEOUT=4
SSD_PATH="${REALBOT_SSD_PATH:-$DEFAULT_SSD_PATH}"
ROBOT_SERVICE="${REALBOT_SERVICE:-$DEFAULT_SERVICE}"
ROS_SETUP="${REALBOT_ROS_SETUP:-$DEFAULT_ROS_SETUP}"
ROBOT_WS_SETUP="${REALBOT_ROBOT_WS_SETUP:-$DEFAULT_ROBOT_WS_SETUP}"
DATA_WS_SETUP="${REALBOT_DATA_WS_SETUP:-$DEFAULT_DATA_WS_SETUP}"
REPORT_FILE=""
INCLUDE_DIRECTORY_USAGE=0

PASS_COUNT=0
WARN_COUNT=0
FAIL_COUNT=0

usage() {
  cat <<'EOF'
Usage: robot_health_snapshot.sh [options]

Read-only health snapshot for execution after SSH login on the robot.

Options:
  --report-dir DIR       Also save the terminal report in DIR (mode 0600).
  --include-directory-usage
                         Run a bounded du scan; use only while recording and critical tasks are idle.
  --sample-timeout SEC   Per-topic observation window, 1-30 seconds (default: 4).
  --ssd-path PATH        Expected recording SSD mount path.
  --service UNIT         Robot systemd service to inspect (default: realman.service).
  -h, --help             Show this help.

Exit codes:
  0  PASS: no warnings or failures
  1  WARN: checks completed, but at least one item needs review
  2  FAIL: a critical prerequisite or health check failed
 64  Invalid arguments

The script never publishes a Topic, calls a ROS Service, changes a parameter,
controls an actuator, restarts a process, records a bag, or changes robot config.
EOF
}

die_usage() {
  printf 'ERROR: %s\n' "$1" >&2
  usage >&2
  exit 64
}

while (($#)); do
  case "$1" in
    --report-dir)
      (($# >= 2)) || die_usage "--report-dir requires a directory"
      REPORT_DIR=$2
      shift 2
      ;;
    --sample-timeout)
      (($# >= 2)) || die_usage "--sample-timeout requires seconds"
      SAMPLE_TIMEOUT=$2
      shift 2
      ;;
    --include-directory-usage)
      INCLUDE_DIRECTORY_USAGE=1
      shift
      ;;
    --ssd-path)
      (($# >= 2)) || die_usage "--ssd-path requires a path"
      SSD_PATH=$2
      shift 2
      ;;
    --service)
      (($# >= 2)) || die_usage "--service requires a unit name"
      ROBOT_SERVICE=$2
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die_usage "unknown option: $1"
      ;;
  esac
done

[[ "$SAMPLE_TIMEOUT" =~ ^[0-9]+$ ]] || die_usage "sample timeout must be an integer"
((SAMPLE_TIMEOUT >= 1 && SAMPLE_TIMEOUT <= 30)) || die_usage "sample timeout must be 1-30 seconds"
[[ -n "$SSD_PATH" ]] || die_usage "SSD path must not be empty"
[[ -n "$ROBOT_SERVICE" ]] || die_usage "service name must not be empty"
[[ "$SSD_PATH" != -* ]] || die_usage "SSD path must not start with '-' (use ./-name for a relative path)"
[[ "$ROBOT_SERVICE" != -* ]] || die_usage "service name must not start with '-'"

umask 077
if [[ -n "$REPORT_DIR" ]]; then
  if ! mkdir -p -- "$REPORT_DIR"; then
    printf 'ERROR: cannot create report directory: %s\n' "$REPORT_DIR" >&2
    exit 64
  fi
  timestamp_for_file=$(date -u '+%Y%m%dT%H%M%SZ' 2>/dev/null || printf 'unknown-time')
  report_created=0
  for report_attempt in {1..20}; do
    report_candidate="${REPORT_DIR%/}/robot-health-${timestamp_for_file}-$$-${RANDOM}-${report_attempt}.txt"
    if (set -o noclobber; : >"$report_candidate") 2>/dev/null; then
      REPORT_FILE=$report_candidate
      report_created=1
      break
    fi
  done
  if ((report_created == 0)); then
    printf 'ERROR: cannot create an exclusive report file in: %s\n' "$REPORT_DIR" >&2
    exit 64
  fi
  chmod 600 "$REPORT_FILE" 2>/dev/null || true
  exec > >(tee -a "$REPORT_FILE") 2>&1
fi

section() {
  printf '\n== %s ==\n' "$1"
}

result() {
  local status=$1
  local title=$2
  local detail=${3:-}
  case "$status" in
    PASS) PASS_COUNT=$((PASS_COUNT + 1)) ;;
    WARN) WARN_COUNT=$((WARN_COUNT + 1)) ;;
    FAIL) FAIL_COUNT=$((FAIL_COUNT + 1)) ;;
    *) printf 'INTERNAL ERROR: invalid result status %s\n' "$status" >&2; exit 70 ;;
  esac
  printf '[%-4s] %s' "$status" "$title"
  [[ -z "$detail" ]] || printf ' - %s' "$detail"
  printf '\n'
}

info() {
  printf '[INFO] %s\n' "$1"
}

have() {
  command -v "$1" >/dev/null 2>&1
}

print_bounded() {
  local max_lines=$1
  local value=$2
  if [[ -z "$value" ]]; then
    printf '  (no output)\n'
    return
  fi
  printf '%s\n' "$value" | sed -n "1,${max_lines}p" | sed 's/^/  /'
  local lines
  lines=$(printf '%s\n' "$value" | awk 'END {print NR}')
  if [[ "$lines" =~ ^[0-9]+$ ]] && ((lines > max_lines)); then
    printf '  ... (%d additional lines omitted)\n' "$((lines - max_lines))"
  fi
}

redact_logs() {
  sed -E \
    -e 's#(https?://)[^/@[:space:]]+:[^/@[:space:]]+@#\1<redacted>@#g' \
    -e 's#([Pp][Aa][Ss][Ss]([Ww][Oo][Rr][Dd])?|[Pp][Aa][Ss][Ss][Ww][Dd]|[Tt][Oo][Kk][Ee][Nn]|[Ss][Ee][Cc][Rr][Ee][Tt]|[Aa][Pp][Ii][_-]?[Kk][Ee][Yy])("?[[:space:]]*[=:][[:space:]]*"?)[^",;[:space:]]+#\1\3<redacted>#g' \
    -e 's#([Bb][Ee][Aa][Rr][Ee][Rr][[:space:]]+)[A-Za-z0-9._~+/-]+=*#\1<redacted>#g' \
    -e 's#AKIA[A-Z0-9]{16}#<redacted-access-key>#g'
}

source_overlay() {
  local label=$1
  local path=$2
  if [[ ! -r "$path" ]]; then
    result WARN "$label" "setup file is not readable: $path"
    return
  fi
  # ROS setup files may inspect optional variables, so nounset is relaxed only
  # while the trusted setup file is sourced into this process.
  set +u
  # shellcheck disable=SC1090
  source "$path" >/dev/null 2>&1
  local source_rc=$?
  set -u
  if ((source_rc == 0)); then
    result PASS "$label" "$path"
  else
    result WARN "$label" "source failed: $path"
  fi
}

sample_h264_header() {
  local label=$1
  local topic=$2
  local output rc
  if ! topic_exists "$topic"; then
    result WARN "$label" "Topic absent: $topic"
    return
  fi
  if ! have timeout; then
    result WARN "$label" "timeout command unavailable; skipped bounded subscription to $topic"
    return
  fi
  output=$(PYTHONUNBUFFERED=1 timeout "${SAMPLE_TIMEOUT}s" \
    ros2 topic echo "$topic" --once --field header \
    --qos-reliability best_effort 2>&1)
  rc=$?
  if ((rc == 0)); then
    result PASS "$label" "received a new message header from $topic"
    print_bounded 12 "$output"
  elif ((rc == 124)); then
    result WARN "$label" "no message within ${SAMPLE_TIMEOUT}s: $topic"
  else
    result WARN "$label" "subscription failed (exit $rc): $topic"
    print_bounded 12 "$output"
  fi
}

topic_exists() {
  local topic=$1
  printf '%s\n' "$ROS_TOPICS" | grep -Fqx -- "$topic"
}

sample_topic_once() {
  local label=$1
  local topic=$2
  local output rc
  if ! topic_exists "$topic"; then
    result WARN "$label" "Topic absent: $topic"
    return
  fi
  if ! have timeout; then
    result WARN "$label" "timeout command unavailable; skipped bounded subscription to $topic"
    return
  fi
  output=$(PYTHONUNBUFFERED=1 timeout "${SAMPLE_TIMEOUT}s" ros2 topic echo "$topic" --once 2>&1)
  rc=$?
  if ((rc == 0)); then
    result PASS "$label" "received one message from $topic"
    print_bounded 36 "$output"
  elif ((rc == 124)); then
    result WARN "$label" "no message within ${SAMPLE_TIMEOUT}s: $topic"
  else
    result WARN "$label" "subscription failed (exit $rc): $topic"
    print_bounded 12 "$output"
  fi
}

sample_topic_rate() {
  local label=$1
  local topic=$2
  local output rc
  if ! topic_exists "$topic"; then
    result WARN "$label" "Topic absent: $topic"
    return
  fi
  if ! have timeout; then
    result WARN "$label" "timeout command unavailable; skipped bounded rate check for $topic"
    return
  fi
  output=$(PYTHONUNBUFFERED=1 timeout "${SAMPLE_TIMEOUT}s" ros2 topic hz "$topic" 2>&1)
  rc=$?
  if printf '%s\n' "$output" | grep -Eq 'average rate:|avg rate:'; then
    result PASS "$label" "positive message rate observed on $topic"
    print_bounded 8 "$output"
  elif ((rc == 124)); then
    result WARN "$label" "no positive rate within ${SAMPLE_TIMEOUT}s: $topic"
  else
    result WARN "$label" "rate probe failed (exit $rc): $topic"
    print_bounded 12 "$output"
  fi
}

started_at=$(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || printf 'unknown')
printf 'Realbot1.0 read-only health snapshot\n'
printf 'Started (UTC): %s\n' "$started_at"
printf 'Observation timeout per Topic: %ss\n' "$SAMPLE_TIMEOUT"
printf 'Safety boundary: discovery, subscription and local inspection only.\n'

section "System and ROS environment"
if have hostname; then
  info "hostname: $(hostname 2>/dev/null || printf unknown)"
else
  result WARN "hostname" "command unavailable"
fi
if have uname; then
  info "kernel: $(uname -srm 2>/dev/null || printf unknown)"
else
  result WARN "kernel" "uname command unavailable"
fi
if [[ -r /etc/os-release ]]; then
  os_name=$(awk -F= '$1 == "PRETTY_NAME" {gsub(/^"|"$/, "", $2); print $2}' /etc/os-release)
  info "OS: ${os_name:-unknown}"
else
  result WARN "OS release" "/etc/os-release is not readable"
fi

source_overlay "ROS underlay" "$ROS_SETUP"
source_overlay "robot workspace overlay" "$ROBOT_WS_SETUP"
source_overlay "data-collection overlay" "$DATA_WS_SETUP"

info "ROS_DISTRO=${ROS_DISTRO:-<unset>}"
info "ROS_DOMAIN_ID=${ROS_DOMAIN_ID:-<default>}"
info "ROS_LOCALHOST_ONLY=${ROS_LOCALHOST_ONLY:-<default>}"
info "RMW_IMPLEMENTATION=${RMW_IMPLEMENTATION:-<default>}"

section "systemd state"
if have systemctl; then
  service_state=$(systemctl is-active "$ROBOT_SERVICE" 2>&1)
  service_rc=$?
  if ((service_rc == 0)) && [[ "$service_state" == "active" ]]; then
    result PASS "robot service" "$ROBOT_SERVICE is active"
  elif [[ "$service_state" == "unknown" ]] || printf '%s' "$service_state" | grep -qi 'not found'; then
    result WARN "robot service" "$ROBOT_SERVICE not found"
  else
    result FAIL "robot service" "$ROBOT_SERVICE state: ${service_state:-unknown}"
  fi

  failed_units=$(systemctl list-units --type=service --state=failed --no-legend --no-pager 2>&1)
  failed_rc=$?
  if ((failed_rc != 0)); then
    result WARN "failed systemd units" "query unavailable"
    print_bounded 8 "$failed_units"
  elif [[ -z "$(printf '%s' "$failed_units" | tr -d '[:space:]')" ]]; then
    result PASS "failed systemd units" "none"
  else
    result WARN "failed systemd units" "one or more services are failed"
    print_bounded 20 "$failed_units"
  fi
else
  result WARN "systemd state" "systemctl command unavailable"
fi

section "ROS graph"
ROS_TOPICS=""
if ! have ros2; then
  result FAIL "ROS 2 CLI" "ros2 command unavailable after loading overlays"
else
  ROS_NODES=$(ros2 node list 2>/dev/null)
  nodes_rc=$?
  ROS_TOPICS=$(ros2 topic list 2>/dev/null)
  topics_rc=$?
  ROS_SERVICES=$(ros2 service list 2>/dev/null)
  services_rc=$?

  node_count=$(printf '%s\n' "$ROS_NODES" | awk '/^\// {n++} END {print n+0}')
  topic_count=$(printf '%s\n' "$ROS_TOPICS" | awk '/^\// {n++} END {print n+0}')
  service_count=$(printf '%s\n' "$ROS_SERVICES" | awk '/^\// {n++} END {print n+0}')

  if ((nodes_rc == 0 && node_count > 0)); then
    result PASS "ROS nodes" "$node_count discovered"
  else
    result FAIL "ROS nodes" "none discovered or graph query failed"
  fi
  if ((topics_rc == 0 && topic_count > 0)); then
    result PASS "ROS Topics" "$topic_count discovered"
  else
    result FAIL "ROS Topics" "none discovered or graph query failed"
  fi
  if ((services_rc == 0)); then
    result PASS "ROS Services" "$service_count discovered (listed only; none called)"
  else
    result WARN "ROS Services" "discovery query failed"
  fi

  section "State, diagnostics and faults"
  sample_topic_once "battery telemetry" "/robot_driver/battery_state"
  sample_topic_once "ROS diagnostics" "/diagnostics"
  sample_topic_once "aggregated faults" "/fault/aggregated"

  section "Sensor streams"
  h264_found=0
  for h264_topic in \
    /left_head_wide_cam/color/image_raw/h264 \
    /right_head_wide_cam/color/image_raw/h264 \
    /left_arm_wide_cam/color/image_raw/h264 \
    /right_arm_wide_cam/color/image_raw/h264; do
    if topic_exists "$h264_topic"; then
      h264_found=$((h264_found + 1))
      sample_h264_header "H.264 stream" "$h264_topic"
    fi
  done
  if ((h264_found == 0)); then
    result WARN "H.264 camera matrix" "none of the four expected wide-camera Topics exists"
  elif ((h264_found < 4)); then
    result WARN "H.264 camera matrix" "$h264_found/4 expected wide-camera Topics exist"
  else
    result PASS "H.264 camera matrix" "4/4 expected wide-camera Topics exist"
  fi

  sample_topic_once "microphone heartbeat" "/wheeltec_mic/heartbeat"
  sample_topic_rate "odometry" "/odom"
  sample_topic_rate "LiDAR scan" "/scan"
fi

section "Recording SSD preflight"
if [[ ! -d "$SSD_PATH" ]]; then
  result FAIL "SSD path" "directory absent: $SSD_PATH"
else
  result PASS "SSD path" "$SSD_PATH exists"
  if have findmnt; then
    mount_info=$(findmnt -n -T "$SSD_PATH" -o TARGET,SOURCE,FSTYPE,OPTIONS 2>&1)
    mount_target=$(findmnt -n -T "$SSD_PATH" -o TARGET 2>/dev/null | head -n 1)
    mount_source=$(findmnt -n -T "$SSD_PATH" -o SOURCE 2>/dev/null | head -n 1)
    normalized_ssd=${SSD_PATH%/}
    normalized_target=${mount_target%/}
    if [[ -n "$mount_info" && "$normalized_target" == "$normalized_ssd" && "$mount_source" == /dev/* && -b "$mount_source" ]]; then
      result PASS "SSD mount" "$mount_info"
    elif [[ -n "$mount_info" && "$normalized_target" == "$normalized_ssd" ]]; then
      result FAIL "SSD mount" "$SSD_PATH source is not a block device: ${mount_source:-unknown}"
      print_bounded 4 "$mount_info"
    elif [[ -n "$mount_info" ]]; then
      result FAIL "SSD mount" "$SSD_PATH is backed by $mount_target, not a dedicated mount at the expected path"
      print_bounded 4 "$mount_info"
    else
      result FAIL "SSD mount" "findmnt found no backing mount for $SSD_PATH"
    fi
  else
    result WARN "SSD mount" "findmnt command unavailable"
  fi

  if have df; then
    df_output=$(df -hP "$SSD_PATH" 2>&1)
    df_rc=$?
    if ((df_rc == 0)); then
      used_percent=$(df -P "$SSD_PATH" 2>/dev/null | awk 'NR == 2 {gsub(/%/, "", $5); print $5}')
      if [[ "$used_percent" =~ ^[0-9]+$ ]] && ((used_percent >= 95)); then
        result FAIL "SSD free space" "${used_percent}% used"
      elif [[ "$used_percent" =~ ^[0-9]+$ ]] && ((used_percent >= 85)); then
        result WARN "SSD free space" "${used_percent}% used"
      else
        result PASS "SSD free space" "${used_percent:-unknown}% used"
      fi
      print_bounded 4 "$df_output"
    else
      result WARN "SSD free space" "df query failed"
    fi
  else
    result WARN "SSD free space" "df command unavailable"
  fi

  if ((INCLUDE_DIRECTORY_USAGE == 0)); then
    printf 'INFO: recursive SSD directory usage skipped by default; use --include-directory-usage only while recording and critical tasks are idle.\n'
  elif have du; then
    if have timeout; then
      du_output=$(timeout 10s du -sh -- "$SSD_PATH" 2>&1)
      du_rc=$?
    else
      du_output=""
      du_rc=127
    fi
    if ((du_rc == 0)); then
      result PASS "SSD directory usage" "$du_output"
    elif ((du_rc == 124)); then
      result WARN "SSD directory usage" "du exceeded 10 seconds"
    else
      result WARN "SSD directory usage" "bounded du unavailable or failed"
    fi
  else
    result WARN "SSD directory usage" "du command unavailable"
  fi
fi

section "CPU, memory and temperature"
if [[ -r /proc/loadavg ]]; then
  load_one=$(awk '{print $1}' /proc/loadavg)
  cpu_count=$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf '0')
  if [[ "$cpu_count" =~ ^[0-9]+$ ]] && ((cpu_count > 0)); then
    overloaded=$(awk -v load="$load_one" -v cpus="$cpu_count" 'BEGIN {print (load > cpus * 2) ? 1 : 0}')
    if ((overloaded)); then
      result WARN "CPU load" "load1=$load_one across $cpu_count CPUs"
    else
      result PASS "CPU load" "load1=$load_one across $cpu_count CPUs"
    fi
  else
    result WARN "CPU load" "load1=$load_one; CPU count unavailable"
  fi
else
  result WARN "CPU load" "/proc/loadavg unavailable"
fi

if have free; then
  memory_line=$(free -m 2>/dev/null | awk '$1 == "Mem:" {print $2, $7}')
  read -r memory_total memory_available <<<"$memory_line"
  if [[ "${memory_total:-}" =~ ^[0-9]+$ ]] && ((memory_total > 0)) && [[ "${memory_available:-}" =~ ^[0-9]+$ ]]; then
    memory_used_pct=$((100 * (memory_total - memory_available) / memory_total))
    if ((memory_used_pct >= 95)); then
      result FAIL "memory availability" "${memory_used_pct}% used"
    elif ((memory_used_pct >= 85)); then
      result WARN "memory availability" "${memory_used_pct}% used"
    else
      result PASS "memory availability" "${memory_used_pct}% used"
    fi
    print_bounded 4 "$(free -h 2>/dev/null)"
  else
    result WARN "memory availability" "could not parse free output"
  fi
else
  result WARN "memory availability" "free command unavailable"
fi

thermal_values=""
for thermal_file in /sys/class/thermal/thermal_zone*/temp; do
  [[ -r "$thermal_file" ]] || continue
  thermal_value=$(cat "$thermal_file" 2>/dev/null || true)
  [[ "$thermal_value" =~ ^[0-9]+$ ]] || continue
  thermal_values="${thermal_values}${thermal_value}\n"
done
if [[ -n "$thermal_values" ]]; then
  max_temp_milli=$(printf '%b' "$thermal_values" | sort -nr | head -n 1)
  max_temp_c=$(awk -v value="$max_temp_milli" 'BEGIN {printf "%.1f", value / 1000}')
  if ((max_temp_milli >= 95000)); then
    result FAIL "thermal zones" "maximum ${max_temp_c} C"
  elif ((max_temp_milli >= 85000)); then
    result WARN "thermal zones" "maximum ${max_temp_c} C"
  else
    result PASS "thermal zones" "maximum ${max_temp_c} C"
  fi
else
  result WARN "thermal zones" "readable thermal zone data unavailable"
fi

if have ps; then
  process_output=$(ps -eo pid,ppid,etime,%cpu,%mem,comm --sort=-%cpu 2>&1)
  process_rc=$?
  if ((process_rc == 0)); then
    result PASS "high-usage process snapshot" "captured top CPU consumers"
    print_bounded 11 "$process_output"
  else
    result WARN "high-usage process snapshot" "ps query failed"
    print_bounded 8 "$process_output"
  fi
else
  result WARN "high-usage process snapshot" "ps command unavailable"
fi

section "Redacted support logs"
if have journalctl; then
  log_output=$(journalctl -u "$ROBOT_SERVICE" --since '-15 minutes' -n 80 --no-pager 2>&1)
  log_rc=$?
  redacted_output=$(printf '%s\n' "$log_output" | redact_logs)
  if ((log_rc == 0)); then
    result PASS "journal excerpt" "last 15 minutes, maximum 80 lines, sensitive patterns redacted"
    print_bounded 80 "$redacted_output"
  else
    result WARN "journal excerpt" "journal query unavailable; no privilege escalation attempted"
    print_bounded 8 "$redacted_output"
  fi
else
  result WARN "journal excerpt" "journalctl command unavailable"
fi

section "Summary"
overall=PASS
exit_code=0
if ((FAIL_COUNT > 0)); then
  overall=FAIL
  exit_code=2
elif ((WARN_COUNT > 0)); then
  overall=WARN
  exit_code=1
fi
printf 'PASS=%d WARN=%d FAIL=%d\n' "$PASS_COUNT" "$WARN_COUNT" "$FAIL_COUNT"
printf 'OVERALL: %s\n' "$overall"
if [[ -n "$REPORT_FILE" ]]; then
  printf 'REPORT_FILE: %s\n' "$REPORT_FILE"
fi
printf 'Interpretation: Topic presence, a heartbeat, or an aggregate health value alone is not proof of end-to-end availability.\n'
printf 'No recovery action was attempted. Preserve this report and investigate WARN/FAIL items under a separately authorized procedure.\n'
exit "$exit_code"
