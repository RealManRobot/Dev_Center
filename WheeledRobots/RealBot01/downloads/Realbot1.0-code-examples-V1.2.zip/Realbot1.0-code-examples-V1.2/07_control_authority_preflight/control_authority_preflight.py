#!/usr/bin/env python3
"""Realbot1.0 read-only control-authority and motion preflight.

This program inspects the ROS graph and one robot state snapshot. It never
publishes a topic, calls a service, changes a parameter, or controls hardware.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence


CONTROL_TOPICS = (
    "/robot_master/cmd",
    "/robot_master/states",
    "/teleop_cmd_vel",
    "/cmd_vel",
)
SINGLE_OWNER_TOPICS = (
    "/robot_master/cmd",
    "/robot_master/states",
    "/teleop_cmd_vel",
)
CONTROL_NODE_HINTS = {
    "aloha_exo_node": "aloha_exo_node",
    "aloha_slave_node": "aloha_slave_node",
    "rs485_node": "rs485_node",
    "web_server": "web_server",
    "webrtc_sender": "webrtc_sender",
}
REQUIRED_SERVICES = ("/robot/command",)


@dataclass
class CommandResult:
    argv: list[str]
    returncode: int
    stdout: str
    stderr: str
    timed_out: bool = False


@dataclass
class Check:
    status: str
    name: str
    detail: str


def run_bounded(argv: Sequence[str], timeout_sec: float) -> CommandResult:
    """Run a read-only command and terminate its whole process group on timeout."""
    process = subprocess.Popen(
        list(argv),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )
    try:
        stdout, stderr = process.communicate(timeout=timeout_sec)
        return CommandResult(list(argv), process.returncode, stdout, stderr)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            stdout, stderr = process.communicate(timeout=1.0)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate()
        return CommandResult(list(argv), 124, stdout, stderr, timed_out=True)


def parse_topic_info(text: str) -> dict[str, Any]:
    publishers: list[str] = []
    subscribers: list[str] = []
    declared_publishers: int | None = None
    declared_subscribers: int | None = None
    section: str | None = None
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if line.startswith("Publisher count:"):
            declared_publishers = int(line.split(":", 1)[1].strip())
            section = "publisher"
        elif line.startswith("Subscription count:"):
            declared_subscribers = int(line.split(":", 1)[1].strip())
            section = "subscriber"
        elif line.startswith("Node name:"):
            name = line.split(":", 1)[1].strip().lstrip("/")
            if section == "publisher":
                publishers.append(name)
            elif section == "subscriber":
                subscribers.append(name)
    return {
        "publisher_count": declared_publishers,
        "publishers": publishers,
        "subscription_count": declared_subscribers,
        "subscribers": subscribers,
    }


def parse_state_payload(text: str) -> dict[str, Any]:
    """Extract the String.data JSON even when Fast DDS logs precede it.

    Some deployed Fast DDS builds write RTPS shared-memory diagnostics to
    stdout.  ``ros2 topic echo --field data`` then contains those diagnostics,
    the one-line JSON payload, and the YAML ``---`` separator.  Selecting the
    first independently valid JSON object keeps the preflight read-only while
    avoiding a false motion block caused by transport logging.
    """
    for raw_line in text.splitlines():
        candidate = raw_line.strip()
        if candidate.startswith("data:"):
            candidate = candidate.split(":", 1)[1].strip()
        if not (candidate.startswith("{") and candidate.endswith("}")):
            continue
        try:
            payload = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            return payload
    raise ValueError("state payload does not contain a valid JSON object")


def evaluate_state(state: dict[str, Any]) -> list[Check]:
    checks: list[Check] = []
    for component in ("arm_left", "arm_right", "body", "head"):
        value = state.get(component)
        if not isinstance(value, dict):
            checks.append(Check("FAIL", f"{component} state", "component missing"))
            continue
        joint_err = value.get("joint_err")
        sys_err = value.get("sys_err")
        joint_en = value.get("joint_en")
        errors_clear = (
            isinstance(joint_err, list)
            and all(item == 0 for item in joint_err)
            and sys_err == 0
        )
        enabled = isinstance(joint_en, list) and bool(joint_en) and all(item == 1 for item in joint_en)
        checks.append(
            Check(
                "PASS" if errors_clear else "FAIL",
                f"{component} errors",
                f"sys_err={sys_err}, joint_err={joint_err}",
            )
        )
        checks.append(
            Check(
                "PASS" if enabled else "FAIL",
                f"{component} enable",
                f"joint_en={joint_en}",
            )
        )

    for component in ("hand_left", "hand_right"):
        value = state.get(component)
        sys_state = value.get("sys_state") if isinstance(value, dict) else None
        checks.append(
            Check(
                "PASS" if sys_state == 0 else "FAIL",
                f"{component} state",
                f"sys_state={sys_state}",
            )
        )

    chassis = state.get("chassis")
    try:
        linear_x = float(chassis["linear"]["x"])
        angular_z = float(chassis["angular"]["z"])
        stopped = abs(linear_x) <= 1e-4 and abs(angular_z) <= 1e-4
        detail = f"linear.x={linear_x}, angular.z={angular_z}"
    except (KeyError, TypeError, ValueError):
        stopped = False
        detail = "velocity fields missing or invalid"
    checks.append(Check("PASS" if stopped else "FAIL", "chassis stopped", detail))

    try:
        aloha_state = state["system"]["aloha"]["state"]
        aloha_mode = state["system"]["aloha"]["mode"]
    except (KeyError, TypeError):
        aloha_state = None
        aloha_mode = None
    checks.append(
        Check(
            "PASS" if aloha_state == 0 else "FAIL",
            "teleoperation idle",
            f"aloha.state={aloha_state}, aloha.mode={aloha_mode}",
        )
    )
    return checks


def node_process_provenance(node_counts: Counter[str], process_text: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for node, token in CONTROL_NODE_HINTS.items():
        graph_count = node_counts.get(node, 0)
        local_process_count = sum(token in line for line in process_text.splitlines())
        if graph_count == 0:
            classification = "absent"
        elif local_process_count == graph_count:
            classification = "local_process_count_matches_graph"
        elif local_process_count == 0:
            classification = "remote_or_unresolved_dds_participant"
        else:
            classification = "mixed_local_and_remote_or_duplicate"
        result[node] = {
            "graph_count": graph_count,
            "local_process_count": local_process_count,
            "classification": classification,
        }
    return result


def add(checks: list[Check], status: str, name: str, detail: str) -> None:
    checks.append(Check(status, name, detail))


def collect(observe_seconds: int) -> tuple[dict[str, Any], list[Check]]:
    checks: list[Check] = []
    evidence: dict[str, Any] = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "observe_seconds": observe_seconds,
        "safety_contract": "read-only; no publish, service call, parameter change, or actuator command",
    }

    node_result = run_bounded(("ros2", "node", "list"), 8)
    if node_result.returncode != 0:
        add(checks, "FAIL", "ROS node graph", node_result.stderr.strip() or "ros2 node list failed")
        node_names: list[str] = []
    else:
        node_names = [line.strip().lstrip("/") for line in node_result.stdout.splitlines() if line.strip()]
        add(checks, "PASS", "ROS node graph", f"{len(node_names)} node entries")
    node_counts = Counter(node_names)
    duplicates = sorted(name for name, count in node_counts.items() if count > 1)
    critical_duplicates = sorted(set(duplicates) & set(CONTROL_NODE_HINTS))
    if critical_duplicates:
        add(checks, "FAIL", "unique control node names", f"duplicates={critical_duplicates}")
    elif duplicates:
        add(checks, "WARN", "unique control node names", f"non-control duplicates={duplicates}")
    else:
        add(checks, "PASS", "unique control node names", "no duplicate node names")
    evidence["node_duplicates"] = duplicates

    process_result = run_bounded(("ps", "-eo", "args"), 5)
    process_text = process_result.stdout if process_result.returncode == 0 else ""
    evidence["process_provenance"] = node_process_provenance(node_counts, process_text)

    service_result = run_bounded(("ros2", "service", "list"), 8)
    services = set(service_result.stdout.split()) if service_result.returncode == 0 else set()
    for service in REQUIRED_SERVICES:
        add(
            checks,
            "PASS" if service in services else "FAIL",
            f"required service {service}",
            "present" if service in services else "missing",
        )
    add(
        checks,
        "WARN",
        "direct service ownership",
        "/robot/command exposes no observable lease or caller identity; coordinate it externally",
    )

    topic_evidence: dict[str, Any] = {}
    for topic in CONTROL_TOPICS:
        info_result = run_bounded(("ros2", "topic", "info", "-v", topic), 8)
        if info_result.returncode != 0:
            add(checks, "FAIL", f"graph {topic}", info_result.stderr.strip() or "topic info failed")
            parsed = {
                "publisher_count": None,
                "publishers": [],
                "subscription_count": None,
                "subscribers": [],
            }
        else:
            parsed = parse_topic_info(info_result.stdout)
            count = parsed["publisher_count"]
            publishers = parsed["publishers"]
            if topic in SINGLE_OWNER_TOPICS and isinstance(count, int) and count > 1:
                add(checks, "FAIL", f"single owner {topic}", f"{count} publishers: {publishers}")
            else:
                add(checks, "PASS", f"single owner {topic}", f"{count} publishers: {publishers}")

        activity_result = run_bounded(
            ("ros2", "topic", "echo", topic, "--once"),
            observe_seconds,
        )
        active = activity_result.returncode == 0 and bool(activity_result.stdout.strip())
        parsed["message_observed"] = active
        parsed["observation_timed_out"] = activity_result.timed_out
        if active:
            add(checks, "FAIL", f"idle observation {topic}", "message observed during preflight")
        elif activity_result.timed_out:
            add(checks, "PASS", f"idle observation {topic}", f"no message in {observe_seconds}s")
        else:
            add(
                checks,
                "WARN",
                f"idle observation {topic}",
                activity_result.stderr.strip() or f"probe exited {activity_result.returncode}",
            )
        topic_evidence[topic] = parsed
    evidence["control_topics"] = topic_evidence

    state_result = run_bounded(
        (
            "ros2",
            "topic",
            "echo",
            "/robot_slave/states",
            "std_msgs/msg/String",
            "--once",
            "--field",
            "data",
        ),
        8,
    )
    if state_result.returncode != 0:
        add(checks, "FAIL", "robot state snapshot", state_result.stderr.strip() or "state timeout")
        evidence["state"] = None
    else:
        try:
            state = parse_state_payload(state_result.stdout)
        except (json.JSONDecodeError, ValueError) as exc:
            add(checks, "FAIL", "robot state snapshot", f"invalid JSON: {exc}")
            evidence["state"] = None
        else:
            add(checks, "PASS", "robot state snapshot", "received one structured sample")
            checks.extend(evaluate_state(state))
            evidence["state"] = state

    version_path = Path("/home/realman/workspace/rm_robot_ws/version.txt")
    evidence["robot_software_version"] = (
        version_path.read_text(encoding="utf-8", errors="replace").strip()
        if version_path.is_file()
        else None
    )
    return evidence, checks


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Read-only Realbot1.0 control-authority and motion preflight."
    )
    parser.add_argument(
        "--observe-seconds",
        type=int,
        default=4,
        help="per-control-topic idle observation window, 1-15 seconds (default: 4)",
    )
    parser.add_argument(
        "--json-output",
        type=Path,
        help="optionally create one new private JSON report; existing files are not overwritten",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if not 1 <= args.observe_seconds <= 15:
        print("ERROR: --observe-seconds must be 1-15", file=sys.stderr)
        return 64
    if shutil.which("ros2") is None:
        print("ERROR: ros2 is not on PATH; source ROS 2 and the robot workspace first", file=sys.stderr)
        return 2

    evidence, checks = collect(args.observe_seconds)
    fail_count = sum(check.status == "FAIL" for check in checks)
    warn_count = sum(check.status == "WARN" for check in checks)
    ready = fail_count == 0
    report = {
        "motion_ready": ready,
        "summary": {"fail": fail_count, "warn": warn_count, "total": len(checks)},
        "checks": [asdict(check) for check in checks],
        "evidence": evidence,
    }

    print("Realbot1.0 read-only control-authority preflight")
    print(f"Generated (UTC): {evidence['generated_at_utc']}")
    for check in checks:
        print(f"[{check.status:<4}] {check.name} - {check.detail}")
    print(f"MOTION_READY={'true' if ready else 'false'}")
    print(f"SUMMARY fail={fail_count} warn={warn_count} total={len(checks)}")
    print("No motion or recovery action was attempted.")

    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        try:
            with args.json_output.open("x", encoding="utf-8") as stream:
                json.dump(report, stream, ensure_ascii=False, indent=2)
                stream.write("\n")
            args.json_output.chmod(0o600)
        except FileExistsError:
            print(f"ERROR: report already exists: {args.json_output}", file=sys.stderr)
            return 64
        print(f"JSON_REPORT={args.json_output}")

    return 0 if ready else 2


if __name__ == "__main__":
    raise SystemExit(main())
