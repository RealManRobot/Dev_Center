# 运动前控制权检查（只读）

这个工具用于回答两个不同的问题：当前机器人是否处于静止、无错误状态；ROS2
控制图是否只有一个明确的运动指令入口。它不会发布 Topic、调用 Service、修改参数、
清错、使能或控制机器人。

## 为什么健康正常仍可能禁止运动

关节错误为 0、底盘速度为 0，只能证明采样时刻的状态。若
`/robot_master/cmd`、`/robot_master/states` 或 `/teleop_cmd_vel` 同时登记多个发布者，
旧遥操、外骨骼、网页控制或其他计算单元仍可能在随后取得输出权。没有控制权仲裁器时，
不能把“观察窗口内没有消息”当作独占控制权。

## 在机器人上运行

```bash
source /opt/ros/humble/setup.bash
source /home/realman/workspace/rm_robot_ws/install/setup.bash
python3 examples/07_control_authority_preflight/control_authority_preflight.py \
  --observe-seconds 4
```

需要保存报告时，必须给一个尚不存在的路径：

```bash
python3 examples/07_control_authority_preflight/control_authority_preflight.py \
  --observe-seconds 4 \
  --json-output ./control-authority-preflight.json
```

报告文件使用 0600 权限，工具不会覆盖已有文件。

## 判定规则

- `MOTION_READY=true`：所有硬门禁通过；仍需人工完成清场、急停可达、真实限位、
  初始姿态和回原路径确认。
- `MOTION_READY=false`：禁止发送运动命令。先消除报告里的 `FAIL`，重新运行检查。
- `WARN`：需要人工解释。尤其 `/robot/command` 是直接控制 Service，ROS 图不能证明
  调用者身份或租约，必须由上层系统保证机器人级唯一控制权。

工具把“ROS 图节点数量”和“本机进程数量”分别记录。`remote_or_unresolved_dds_participant`
只说明节点来自其他 DDS 参与者或无法映射到本机进程，不能仅凭此字段断言具体 IP。

## 边界

检查结果是一次性快照，不是持续互斥锁，也不是实机运动许可。正式产品应在所有运动入口
之前增加统一控制权仲裁、命令时效和序号校验、最新目标覆盖、部位精确停止和错误联锁。
