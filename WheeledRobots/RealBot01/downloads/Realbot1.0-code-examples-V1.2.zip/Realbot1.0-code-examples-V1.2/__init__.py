"""Importable support code for the Realbot1.0 customer examples."""
