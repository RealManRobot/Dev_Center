# Realbot1.0 配套示例代码

本代码包按使用流程组织。建议先从 `00_customer_acceptance` 完成只读验收，
再根据实际开发任务进入后续目录。

| 目录 | 用途 | 默认行为 | 风险 |
|---|---|---|---|
| `00_customer_acceptance` | 从连接到 10 秒录制交付 | 只读检查优先 | 只读/可控 |
| `01_quick_start` | 网络、版本和整机健康快照 | 只读 | 只读 |
| `02_state_reading` | Python/C++ 读取状态 | 只读 | 只读 |
| `03_motion_control` | 整机控制总览、分部 ROS2/REST 与底盘受控示例 | plan-only / dry-run | 可控/高风险 |
| `04_data_recording` | 录制、拉取和 MCAP 验收 | dry-run | 可控 |
| `05_platform_integration` | 无 ROS 平台桥 | loopback | 高风险部署 |
| `06_vr_movej_follow` | 虚拟 Pico 最新目标兼容网关 | 配置校验 | 可控风险 |
| `07_control_authority_preflight` | 运动前控制权与状态门禁 | 只读 | 只读 |

## 统一运行规则

1. 先阅读对应目录的 `README.md`。
2. 先运行测试或 `--help`，再运行默认 dry-run/配置检查。
3. 涉及运动时必须确认唯一控制权、清场、急停、当前错误位和回原路径。
4. 示例不自动清错、不自动扩大运动范围、不保存密码或 token。
5. 任何超时、方向异常或关节错误都先停止并读取状态，不盲目重发。

实验脚本、故障现场和性能研究位于内部维护区，不属于客户示例入口。
