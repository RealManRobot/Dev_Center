#!/usr/bin/env python3
"""Run one bounded recording and print only that run's completed directory.

This script runs on the robot after sourcing ROS2 and the robot workspace.  It
never deletes data.  The caller must have exclusive ownership of the recorder.
"""

from __future__ import annotations

import argparse
import contextlib
import fcntl
import json
import math
import os
import signal
import shutil
import stat
import subprocess
import sys
import time
import uuid
from collections.abc import Callable
from pathlib import Path

# Direct execution sets sys.path to this file's directory, not the package root.
# Add only the path derived from this reviewed script so the documented command
# works without requiring a caller-controlled PYTHONPATH.
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from examples.platform_bridge.bridge_core import (
    validate_meta,
    validate_recorder_response,
)


RECORDED_DIR = Path("/home/realman/ssd/mcap_recorded")
SSD_MOUNT = Path("/home/realman/ssd")
ACTIVE_RECORDING_DIR = Path("/home/realman/ssd/mcap_recording")
DEMO_LOCK_PATH = Path(
    "/home/realman/.cache/realbot-recording-demo/recording-delivery.lock"
)
MINIMUM_FREE_BYTES = 5 * 1024**3
MAX_DURATION_SECONDS = 3600.0


def new_run_id() -> str:
    return uuid.uuid4().hex[:16]


def validate_duration(value: object) -> float:
    try:
        duration = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("duration must be numeric") from exc
    if not math.isfinite(duration) or not 0 < duration <= MAX_DURATION_SECONDS:
        raise ValueError("duration must be greater than 0 and at most 3600 seconds")
    return duration


def validate_recording_root(root: Path) -> Path:
    """Permit writes only to the reviewed completed-recording directory."""
    candidate = Path(root)
    if candidate != RECORDED_DIR or candidate.parent != SSD_MOUNT:
        raise RuntimeError(
            f"recording root must be exactly {RECORDED_DIR}; got {candidate}"
        )
    return candidate


def _require_real_directory(path: Path, label: str) -> None:
    try:
        mode = path.lstat().st_mode
    except OSError as exc:
        raise RuntimeError(f"{label} is unavailable: {path}: {exc}") from exc
    if not stat.S_ISDIR(mode):
        raise RuntimeError(f"{label} must be a real directory, not a link or file: {path}")


def _active_recording_entries() -> list[Path]:
    return list(ACTIVE_RECORDING_DIR.iterdir())


def validate_recording_write_preconditions(
    root: Path,
    *,
    minimum_free_bytes: int = MINIMUM_FREE_BYTES,
) -> dict[str, object]:
    """Fail closed before contacting the recorder service.

    The checks intentionally use the fixed robot paths.  They do not create,
    delete, stop, or repair any recording state.
    """
    root = validate_recording_root(root)
    if isinstance(minimum_free_bytes, bool) or not isinstance(minimum_free_bytes, int):
        raise ValueError("minimum_free_bytes must be a positive integer")
    if minimum_free_bytes <= 0:
        raise ValueError("minimum_free_bytes must be a positive integer")

    _require_real_directory(SSD_MOUNT, "SSD mount path")
    _require_real_directory(root, "completed-recording root")
    _require_real_directory(ACTIVE_RECORDING_DIR, "active-recording directory")

    try:
        mount = subprocess.run(
            [
                "findmnt",
                "--noheadings",
                "--target",
                os.fspath(SSD_MOUNT),
                "--output",
                "TARGET,SOURCE",
            ],
            check=True,
            text=True,
            capture_output=True,
            timeout=10,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise RuntimeError("cannot verify the dedicated SSD mount with findmnt") from exc
    mount_rows = [line.split() for line in mount.stdout.splitlines() if line.strip()]
    if len(mount_rows) != 1 or len(mount_rows[0]) != 2:
        raise RuntimeError("findmnt did not return one unambiguous TARGET/SOURCE row")
    mount_target, mount_source = mount_rows[0]
    if mount_target != os.fspath(SSD_MOUNT):
        raise RuntimeError(
            f"{SSD_MOUNT} is not the mount target itself; findmnt returned {mount_target}"
        )
    try:
        source_mode = os.stat(mount_source).st_mode
    except OSError as exc:
        raise RuntimeError(f"SSD mount source is unavailable: {mount_source}") from exc
    if not stat.S_ISBLK(source_mode):
        raise RuntimeError(f"SSD mount source is not a real block device: {mount_source}")

    try:
        free_bytes = shutil.disk_usage(SSD_MOUNT).free
    except OSError as exc:
        raise RuntimeError("cannot determine SSD free space") from exc
    if free_bytes < minimum_free_bytes:
        raise RuntimeError(
            "insufficient SSD free space: "
            f"{free_bytes} bytes available, {minimum_free_bytes} required"
        )

    try:
        active_entries = _active_recording_entries()
    except OSError as exc:
        raise RuntimeError("cannot inspect the active-recording directory") from exc
    if active_entries:
        names = ", ".join(sorted(item.name for item in active_entries)[:5])
        raise RuntimeError(
            "active-recording directory is not empty; recorder state is not idle; "
            f"preserve data and inspect manually: {names}"
        )
    return {
        "recording_root": os.fspath(root),
        "ssd_mount": os.fspath(SSD_MOUNT),
        "mount_source": mount_source,
        "free_bytes": free_bytes,
        "minimum_free_bytes": minimum_free_bytes,
        "active_recording_entries": 0,
    }


@contextlib.contextmanager
def acquire_demo_lock(lock_path: Path = DEMO_LOCK_PATH):
    """Acquire the one non-blocking cross-process lock used by this Demo."""
    lock_path = Path(lock_path)
    lock_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    flags = os.O_CREAT | os.O_RDWR
    if hasattr(os, "O_CLOEXEC"):
        flags |= os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(lock_path, flags, 0o600)
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError(
                "another recording-delivery Demo process holds the robot-side lock; "
                "do not contact the recorder service"
            ) from exc
        try:
            yield
        finally:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
    finally:
        os.close(descriptor)


def build_record_meta(
    scene: str,
    task: str,
    operator: str,
    device: str,
    run_id: str,
) -> dict[str, str]:
    if not isinstance(run_id, str) or len(run_id) != 16:
        raise ValueError("run_id must be 16 lowercase hexadecimal characters")
    try:
        int(run_id, 16)
    except ValueError as exc:
        raise ValueError("run_id must be 16 lowercase hexadecimal characters") from exc
    if run_id != run_id.lower():
        raise ValueError("run_id must be 16 lowercase hexadecimal characters")
    return validate_meta(
        {
            "scene": scene,
            "task": f"{task}-r-{run_id}",
            "operator": operator,
            "device": device,
        }
    )


def _regular_directories(root: Path) -> set[str]:
    try:
        entries = list(root.iterdir())
    except (FileNotFoundError, NotADirectoryError):
        return set()
    names: set[str] = set()
    for entry in entries:
        try:
            if stat.S_ISDIR(entry.lstat().st_mode):
                names.add(entry.name)
        except FileNotFoundError:
            continue
    return names


def find_recorded_run(
    root: Path,
    before: set[str],
    run_id: str,
    scene: str,
    task: str,
) -> Path:
    """Return the one new regular directory matching this exact run marker."""
    if f"-r-{run_id}" not in task:
        raise ValueError("task does not contain the run marker")
    prefix = f"{scene}_{task}_"
    candidates = sorted(
        name
        for name in (_regular_directories(root) - set(before))
        if name.startswith(prefix)
    )
    if len(candidates) != 1:
        raise RuntimeError(
            f"expected exactly one completed directory for run {run_id}; "
            f"found {len(candidates)}"
        )
    return root / candidates[0]


def wait_for_recorded_run(
    root: Path,
    before: set[str],
    run_id: str,
    scene: str,
    task: str,
    timeout_seconds: float = 20.0,
) -> Path:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        try:
            return find_recorded_run(root, before, run_id, scene, task)
        except RuntimeError:
            time.sleep(0.25)
    return find_recorded_run(root, before, run_id, scene, task)


def _call_recorder(node, client, service_type, operate: int, meta: dict[str, str]) -> dict:
    import rclpy

    request = service_type.Request()
    request.data = json.dumps(
        {
            "operate": operate,
            "command": "capture",
            "sence_id": meta["scene"],
            "task_id": meta["task"],
            "operator_id": meta["operator"],
            "device_id": meta["device"],
        },
        separators=(",", ":"),
    )
    future = client.call_async(request)
    rclpy.spin_until_future_complete(node, future, timeout_sec=10.0)
    response = future.result() if future.done() else None
    if response is None:
        raise RuntimeError("recorder service timed out; verify recorder state manually")
    try:
        decoded = json.loads(response.data)
    except (TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError("recorder returned invalid JSON") from exc
    return validate_recorder_response(decoded)


def run_bounded_recording(
    start: Callable[[], None],
    stop: Callable[[], None],
    duration: float,
) -> None:
    """Run one cycle; a failed start response is still an uncertain start."""
    guarded_signals = [signal.SIGINT, signal.SIGTERM]
    if hasattr(signal, "SIGHUP"):
        guarded_signals.append(signal.SIGHUP)
    previous_handlers = {
        signum: signal.getsignal(signum) for signum in guarded_signals
    }

    def unwind_for_stop(signum: int, _frame: object) -> None:
        raise KeyboardInterrupt(f"recording interrupted by signal {signum}")

    for signum in previous_handlers:
        signal.signal(signum, unwind_for_stop)
    try:
        try:
            start()
            time.sleep(duration)
        except BaseException:
            try:
                stop()
            except BaseException as stop_error:
                print(
                    "CRITICAL: recording stop failed after an uncertain start; "
                    f"inspect recorder state immediately; stop error={stop_error}",
                    file=sys.stderr,
                )
            raise
        try:
            stop()
        except BaseException as stop_error:
            # Do not retry automatically: the response timeout does not prove that
            # the stop request failed.  Preserve the exact metadata for one guarded
            # manual inspection/stop attempt.
            print(
                "CRITICAL: recording stop response failed after a confirmed start; "
                "inspect recorder state and use the same metadata for one guarded stop; "
                f"stop error={stop_error}",
                file=sys.stderr,
            )
            raise
    finally:
        for signum, handler in previous_handlers.items():
            signal.signal(signum, handler)


def record_once(meta: dict[str, str], duration: float, root: Path = RECORDED_DIR) -> Path:
    clean = validate_meta(meta)
    duration = validate_duration(duration)
    root = validate_recording_root(root)
    run_id = clean["task"].rsplit("-r-", 1)[-1]
    with acquire_demo_lock():
        # All gates run while the Demo lock is held and before ROS is initialized
        # or the recorder service is discovered/called.
        validate_recording_write_preconditions(root)
        before = _regular_directories(root)
        import rclpy
        from rclpy.node import Node
        from rm_robot_interfaces.srv import StringCmd

        rclpy.init()
        node = Node("realbot_record_once")
        client = node.create_client(StringCmd, "/mcap_recorder_service")
        try:
            if not client.wait_for_service(timeout_sec=5.0):
                raise RuntimeError("recorder service unavailable")
            run_bounded_recording(
                lambda: _call_recorder(node, client, StringCmd, 1, clean),
                lambda: _call_recorder(node, client, StringCmd, 0, clean),
                duration,
            )
        finally:
            node.destroy_node()
            rclpy.shutdown()
        return wait_for_recorded_run(
            root, before, run_id, clean["scene"], clean["task"]
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scene", required=True)
    parser.add_argument("--task", required=True)
    parser.add_argument("--operator", required=True)
    parser.add_argument("--device", required=True)
    parser.add_argument("--duration", required=True, type=float)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    run_id = new_run_id()
    meta = build_record_meta(
        args.scene, args.task, args.operator, args.device, run_id
    )
    print(
        json.dumps(
            {"status": "prepared", "run_id": run_id, "meta": meta},
            separators=(",", ":"),
        ),
        flush=True,
    )
    completed = record_once(meta, args.duration)
    print(json.dumps({"run_id": run_id, "recorded_dir": str(completed)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
