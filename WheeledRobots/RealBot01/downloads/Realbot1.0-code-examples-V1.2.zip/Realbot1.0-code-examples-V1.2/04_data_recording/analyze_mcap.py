#!/usr/bin/env python3
"""Summarize MCAP time bounds, duration, topics, counts and camera FPS.

Camera FPS is the whole-bag average ``count/duration``.  It is not an
instantaneous rate and can hide short drops or bursts.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


def _is_camera_image_topic(topic: str) -> bool:
    return "/image" in topic


def summarize_message_times(
    samples: Iterable[tuple[str, int]],
) -> dict[str, object]:
    counts: Counter[str] = Counter()
    start_ns: int | None = None
    end_ns: int | None = None
    for topic, timestamp_ns in samples:
        if not isinstance(topic, str) or not topic:
            raise ValueError("topic must be a non-empty string")
        if type(timestamp_ns) is not int or timestamp_ns < 0:
            raise ValueError("timestamp must be a non-negative integer")
        counts[topic] += 1
        start_ns = timestamp_ns if start_ns is None else min(start_ns, timestamp_ns)
        end_ns = timestamp_ns if end_ns is None else max(end_ns, timestamp_ns)
    if start_ns is None or end_ns is None:
        raise ValueError("MCAP contains no messages")
    duration = (end_ns - start_ns) / 1_000_000_000
    topics: dict[str, dict[str, object]] = {}
    for topic, count in sorted(counts.items()):
        item: dict[str, object] = {"message_count": count}
        if _is_camera_image_topic(topic):
            item["camera_average_fps"] = count / duration if duration > 0 else None
        topics[topic] = item
    return {
        "start_time_ns": start_ns,
        "end_time_ns": end_ns,
        "start_time_utc": datetime.fromtimestamp(
            start_ns / 1_000_000_000, tz=timezone.utc
        ).isoformat(),
        "end_time_utc": datetime.fromtimestamp(
            end_ns / 1_000_000_000, tz=timezone.utc
        ).isoformat(),
        "duration_seconds": duration,
        "topics": topics,
    }


def analyze_files(paths: list[Path]) -> dict[str, object]:
    try:
        from mcap.reader import make_reader
    except ImportError as exc:
        raise RuntimeError("install the 'mcap' Python package first") from exc

    def samples():
        for path in paths:
            if not path.is_file():
                raise ValueError(f"MCAP file not found: {path}")
            with path.open("rb") as stream:
                reader = make_reader(stream)
                for _schema, channel, message in reader.iter_messages():
                    yield channel.topic, message.log_time

    return summarize_message_times(samples())


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mcap", nargs="+", type=Path)
    args = parser.parse_args()
    print(json.dumps(analyze_files(args.mcap), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
