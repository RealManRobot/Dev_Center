#!/usr/bin/env python3
"""Record, retrieve, and verify one Realbot data delivery.

Customer mode runs on a workstation and uses the system ``ssh`` and ``scp``
clients so authentication remains interactive.  Robot-stage mode is an
internal implementation detail: it calls the reviewed sibling ``record_once``
module, captures ``ros2 bag info``, and writes immutable delivery evidence.

This demo never deletes robot data.  A successful download is not permission
to remove the remote recording or its evidence.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import re
import shlex
import stat
import subprocess
import sys
import uuid
from pathlib import Path, PurePosixPath
from typing import Any, Iterable


DEFAULT_DURATION_SECONDS = 10.0
DEFAULT_HOST = "192.168.127.10"
DEFAULT_USER = "realman"
DEFAULT_REMOTE_ROOT = "/home/realman/ssd/mcap_recorded"
DEFAULT_EVIDENCE_ROOT = "/home/realman/ssd/mcap_delivery_evidence"
DEFAULT_MINIMUM_DURATION_SECONDS = 8.0
DEFAULT_MAXIMUM_DURATION_SECONDS = 12.0
DEFAULT_REQUIRED_TOPICS = frozenset(
    {
        "/mcap/body",
        "/mcap/master_arm_left",
        "/mcap/slave_arm_left",
        "/mcap/master_arm_right",
        "/mcap/slave_arm_right",
    }
)
DEFAULT_MINIMUM_CAMERA_FPS = 29.0
DEFAULT_CAMERA_TOPICS = frozenset(
    {
        "/left_arm_wide_cam/color/image_raw/compressed",
        "/right_arm_wide_cam/color/image_raw/compressed",
        "/left_head_wide_cam/color/image_raw/compressed",
        "/right_head_wide_cam/color/image_raw/compressed",
    }
)
RUN_ID_RE = re.compile(r"\A[0-9a-f]{16}\Z")
HOST_RE = re.compile(r"\A(?:[A-Za-z0-9](?:[A-Za-z0-9.-]{0,251}[A-Za-z0-9])?|[A-Za-z0-9])\Z")
USER_RE = re.compile(r"\A[a-z_][a-z0-9_-]{0,31}\Z")
SAFE_REMOTE_PATH_RE = re.compile(r"\A/[A-Za-z0-9._/-]+\Z")


def new_run_id() -> str:
    """Return a short, customer-readable cryptographically random run marker."""
    return uuid.uuid4().hex[:16]


def _validate_run_id(run_id: str) -> str:
    if not isinstance(run_id, str) or RUN_ID_RE.fullmatch(run_id) is None:
        raise ValueError("run_id must be 16 lowercase hexadecimal characters")
    return run_id


def _validate_transport_identity(user: str, host: str) -> tuple[str, str]:
    if USER_RE.fullmatch(user) is None:
        raise ValueError("invalid SSH user")
    if HOST_RE.fullmatch(host) is None or host.startswith("-"):
        raise ValueError("invalid SSH host")
    return user, host


def _safe_remote_root(remote_root: str) -> PurePosixPath:
    if not isinstance(remote_root, str) or any(ord(char) < 32 for char in remote_root):
        raise ValueError("remote root contains control characters")
    root = PurePosixPath(remote_root)
    if (
        SAFE_REMOTE_PATH_RE.fullmatch(remote_root) is None
        or not root.is_absolute()
        or str(root) != remote_root
        or ".." in root.parts
    ):
        raise ValueError("remote root must be a normalized absolute path")
    return root


def _safe_remote_recorded_dir(
    recorded_dir: str, remote_root: str, run_id: str
) -> PurePosixPath:
    _validate_run_id(run_id)
    root = _safe_remote_root(remote_root)
    if not isinstance(recorded_dir, str) or any(
        ord(char) < 32 for char in recorded_dir
    ):
        raise ValueError("recorded directory contains control characters")
    candidate = PurePosixPath(recorded_dir)
    if (
        not candidate.is_absolute()
        or str(candidate) != recorded_dir
        or ".." in candidate.parts
        or candidate.parent != root
        or not candidate.name
        or f"-r-{run_id}_" not in candidate.name
    ):
        raise ValueError("recorded directory is not the exact run directory")
    return candidate


def parse_record_once_output(
    stdout: str, expected_run_id: str, remote_root: str = DEFAULT_REMOTE_ROOT
) -> dict[str, Any]:
    """Bind record_once's prepared metadata to exactly one completed directory."""
    _validate_run_id(expected_run_id)
    if not isinstance(stdout, str):
        raise ValueError("record_once output must be text")
    objects: list[dict[str, Any]] = []
    for line in stdout.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        try:
            item = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if isinstance(item, dict):
            objects.append(item)

    prepared = [item for item in objects if item.get("status") == "prepared"]
    completed = [
        item
        for item in objects
        if "recorded_dir" in item and item.get("status") != "prepared"
    ]
    if len(prepared) != 1 or len(completed) != 1:
        raise RuntimeError("record_once did not return one prepared and one completed result")
    start, finish = prepared[0], completed[0]
    if start.get("run_id") != expected_run_id or finish.get("run_id") != expected_run_id:
        raise RuntimeError("record_once run ID does not match the requested run")
    meta = start.get("meta")
    if not isinstance(meta, dict) or not isinstance(meta.get("task"), str):
        raise RuntimeError("record_once prepared metadata is missing")
    if f"-r-{expected_run_id}" not in meta["task"]:
        raise RuntimeError("record_once metadata is not bound to the requested run")
    recorded_dir = finish.get("recorded_dir")
    if not isinstance(recorded_dir, str):
        raise RuntimeError("record_once completed directory is missing")
    _safe_remote_recorded_dir(recorded_dir, remote_root, expected_run_id)
    return {
        "run_id": expected_run_id,
        "meta": dict(meta),
        "recorded_dir": recorded_dir,
    }


def parse_ros2_bag_info(text: str) -> dict[str, Any]:
    """Parse the stable fields of ROS 2's human-readable ``bag info`` output."""
    if not isinstance(text, str) or not text.strip():
        raise ValueError("ros2 bag info output is empty")

    def required(pattern: str, label: str, flags: int = re.MULTILINE) -> str:
        match = re.search(pattern, text, flags)
        if match is None:
            raise ValueError(f"ros2 bag info is missing {label}")
        return match.group(1).strip()

    storage_id = required(r"^Storage id:\s*(\S+)\s*$", "storage id")
    duration_text = required(
        r"^Duration:\s*([0-9]+(?:\.[0-9]+)?)s\s*$", "duration"
    )
    message_text = required(r"^Messages:\s*([0-9]+)\s*$", "message count")
    duration = float(duration_text)
    if not math.isfinite(duration) or duration < 0:
        raise ValueError("ros2 bag duration is invalid")

    files: list[str] = []
    files_match = re.search(r"^Files:\s*(\S+)\s*$", text, re.MULTILINE)
    if files_match:
        files.append(files_match.group(1))
    for match in re.finditer(r"^\s+-\s+(\S+)\s*$", text, re.MULTILINE):
        value = match.group(1)
        if value not in files:
            files.append(value)
    if not files:
        raise ValueError("ros2 bag info is missing files")

    topics: dict[str, dict[str, Any]] = {}
    topic_pattern = re.compile(
        r"Topic:\s*(\S+)\s*\|\s*Type:\s*(\S+)\s*\|\s*"
        r"Count:\s*([0-9]+)\s*\|\s*Serialization Format:\s*(\S+)"
    )
    for match in topic_pattern.finditer(text):
        name, message_type, count, serialization = match.groups()
        if name in topics:
            raise ValueError(f"duplicate topic in ros2 bag info: {name}")
        topics[name] = {
            "type": message_type,
            "message_count": int(count),
            "serialization_format": serialization,
        }
    if not topics:
        raise ValueError("ros2 bag info contains no topics")
    return {
        "storage_id": storage_id,
        "duration_seconds": duration,
        "message_count": int(message_text),
        "files": files,
        "topics": topics,
    }


def _sha256_regular_file(path: Path) -> tuple[int, str]:
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError(f"not a direct regular file: {path.name}")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    after = path.lstat()
    stable_fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns")
    if any(getattr(before, field) != getattr(after, field) for field in stable_fields):
        raise RuntimeError(f"file changed while hashing: {path.name}")
    return before.st_size, digest.hexdigest()


def build_delivery_manifest(
    run_id: str,
    recorded_dir: Path,
    remote_recorded_dir: str,
    bag_info: dict[str, Any],
) -> dict[str, Any]:
    """Hash every direct regular file and reject links or nested content."""
    _validate_run_id(run_id)
    recorded_dir = Path(recorded_dir)
    directory_stat = recorded_dir.lstat()
    if not stat.S_ISDIR(directory_stat.st_mode):
        raise ValueError("recorded_dir must be a real directory, not a symlink")
    remote_path = PurePosixPath(remote_recorded_dir)
    if not remote_path.is_absolute() or str(remote_path) != remote_recorded_dir:
        raise ValueError("remote_recorded_dir must be a normalized absolute path")
    if f"-r-{run_id}_" not in remote_path.name:
        raise ValueError("remote_recorded_dir is not bound to run_id")
    if not isinstance(bag_info, dict):
        raise ValueError("bag_info must be an object")
    if bag_info.get("storage_id") != "mcap":
        raise ValueError("ros2 bag storage id must be mcap")

    entries = sorted(recorded_dir.iterdir(), key=lambda item: item.name)
    if not entries:
        raise ValueError("recorded directory is empty")
    files: list[dict[str, Any]] = []
    for entry in entries:
        entry_stat = entry.lstat()
        if not stat.S_ISREG(entry_stat.st_mode):
            raise ValueError(
                "recorded directory must contain only direct regular files; "
                f"rejected {entry.name}"
            )
        size, digest = _sha256_regular_file(entry)
        files.append({"path": entry.name, "size_bytes": size, "sha256": digest})
    file_map = {item["path"]: item for item in files}
    metadata = file_map.get("metadata.yaml")
    mcap_files = [item for item in files if item["path"].endswith(".mcap")]
    if metadata is None or metadata["size_bytes"] <= 0:
        raise ValueError("recorded directory requires a non-empty metadata.yaml")
    if not mcap_files or any(item["size_bytes"] <= 0 for item in mcap_files):
        raise ValueError("recorded directory requires at least one non-empty MCAP file")
    announced_files = bag_info.get("files")
    if not isinstance(announced_files, list) or not announced_files:
        raise ValueError("ros2 bag info must identify at least one MCAP file")
    for announced in announced_files:
        if (
            not isinstance(announced, str)
            or PurePosixPath(announced).name != announced
            or not announced.endswith(".mcap")
            or announced not in file_map
        ):
            raise ValueError("ros2 bag info file set does not match the recording")
    return {
        "schema_version": 1,
        "run_id": run_id,
        "recorded_dir": remote_recorded_dir,
        "remote_data_retained": True,
        "bag": json.loads(json.dumps(bag_info)),
        "files": files,
    }


def build_ssh_argv(user: str, host: str, remote_command: str) -> list[str]:
    user, host = _validate_transport_identity(user, host)
    if not isinstance(remote_command, str) or not remote_command:
        raise ValueError("remote command must be non-empty text")
    return [
        "ssh",
        "-o",
        "StrictHostKeyChecking=yes",
        "-o",
        "ServerAliveInterval=10",
        f"{user}@{host}",
        remote_command,
    ]


def build_scp_argv(
    user: str,
    host: str,
    remote_path: str,
    local_destination: Path,
) -> list[str]:
    user, host = _validate_transport_identity(user, host)
    remote = PurePosixPath(remote_path)
    if (
        SAFE_REMOTE_PATH_RE.fullmatch(remote_path) is None
        or not remote.is_absolute()
        or str(remote) != remote_path
        or ".." in remote.parts
        or any(ord(char) < 32 for char in remote_path)
    ):
        raise ValueError("remote scp path must be a normalized absolute path")
    return [
        "scp",
        "-o",
        "StrictHostKeyChecking=yes",
        "-r",
        f"{user}@{host}:{remote_path}",
        os.fspath(local_destination),
    ]


def _build_scp_upload_argv(
    user: str, host: str, local_paths: Iterable[Path], remote_destination: str
) -> list[str]:
    user, host = _validate_transport_identity(user, host)
    remote = PurePosixPath(remote_destination)
    if (
        SAFE_REMOTE_PATH_RE.fullmatch(remote_destination) is None
        or not remote.is_absolute()
        or str(remote) != remote_destination
        or ".." in remote.parts
    ):
        raise ValueError("remote upload destination must be normalized and absolute")
    selected_paths = [Path(path) for path in local_paths]
    if not selected_paths or any(not path.is_file() for path in selected_paths):
        raise ValueError("remote stage upload requires regular files")
    return [
        "scp",
        "-o",
        "StrictHostKeyChecking=yes",
        *(os.fspath(path) for path in selected_paths),
        f"{user}@{host}:{remote_destination}",
    ]


def _direct_regular_file_names(directory: Path) -> set[str]:
    directory_stat = directory.lstat()
    if not stat.S_ISDIR(directory_stat.st_mode):
        raise ValueError("downloaded recording must be a real directory")
    names: set[str] = set()
    for entry in directory.iterdir():
        if not stat.S_ISREG(entry.lstat().st_mode):
            raise ValueError(f"download contains non-regular entry: {entry.name}")
        names.add(entry.name)
    return names


def verify_download(
    local_recorded_dir: Path,
    manifest: dict[str, Any],
    required_topics: Iterable[str] = DEFAULT_REQUIRED_TOPICS,
    minimum_duration_seconds: float = DEFAULT_MINIMUM_DURATION_SECONDS,
    maximum_duration_seconds: float = DEFAULT_MAXIMUM_DURATION_SECONDS,
    expected_run_id: str | None = None,
    expected_remote_recorded_dir: str | None = None,
    minimum_topic_rates: dict[str, float] | None = None,
) -> dict[str, Any]:
    """Verify files, hashes, required topics, duration, and configured rates."""
    local_recorded_dir = Path(local_recorded_dir)
    if manifest.get("schema_version") != 1:
        raise ValueError("unsupported or missing manifest schema_version")
    manifest_run_id = manifest.get("run_id")
    _validate_run_id(manifest_run_id)
    if expected_run_id is not None and manifest_run_id != _validate_run_id(expected_run_id):
        raise ValueError("manifest run_id does not match the requested run")
    manifest_recorded_dir = manifest.get("recorded_dir")
    if not isinstance(manifest_recorded_dir, str):
        raise ValueError("manifest recorded_dir is missing")
    _safe_remote_recorded_dir(
        manifest_recorded_dir,
        os.fspath(PurePosixPath(manifest_recorded_dir).parent),
        manifest_run_id,
    )
    if (
        expected_remote_recorded_dir is not None
        and manifest_recorded_dir != expected_remote_recorded_dir
    ):
        raise ValueError("manifest recorded_dir does not match the robot-stage result")
    if local_recorded_dir.name != PurePosixPath(manifest_recorded_dir).name:
        raise ValueError("local recording directory is not bound to manifest recorded_dir")
    if manifest.get("remote_data_retained") is not True:
        raise ValueError("manifest must state that remote data is retained")
    expected_entries = manifest.get("files")
    if not isinstance(expected_entries, list):
        raise ValueError("manifest files must be a list")
    expected: dict[str, dict[str, Any]] = {}
    malformed = False
    for item in expected_entries:
        if not isinstance(item, dict) or not isinstance(item.get("path"), str):
            malformed = True
            continue
        name = item["path"]
        if (
            PurePosixPath(name).name != name
            or SAFE_REMOTE_PATH_RE.fullmatch("/" + name) is None
            or name in expected
            or not isinstance(item.get("size_bytes"), int)
            or item.get("size_bytes", -1) < 0
            or not isinstance(item.get("sha256"), str)
            or re.fullmatch(r"[0-9a-f]{64}", item.get("sha256", "")) is None
        ):
            malformed = True
            continue
        expected[name] = item

    metadata_entry = expected.get("metadata.yaml")
    mcap_entries = [item for name, item in expected.items() if name.endswith(".mcap")]
    if metadata_entry is None or metadata_entry.get("size_bytes", 0) <= 0:
        malformed = True
    if not mcap_entries or any(item.get("size_bytes", 0) <= 0 for item in mcap_entries):
        malformed = True

    actual_names: set[str] = set()
    hash_failures: list[str] = []
    try:
        actual_names = _direct_regular_file_names(local_recorded_dir)
    except (OSError, ValueError) as exc:
        hash_failures.append(str(exc))
    missing_files = sorted(set(expected) - actual_names)
    unexpected_files = sorted(actual_names - set(expected))
    for name in sorted(set(expected) & actual_names):
        item = expected[name]
        try:
            size, digest = _sha256_regular_file(local_recorded_dir / name)
            expected_size = item.get("size_bytes")
            expected_hash = item.get("sha256")
            if size != expected_size or digest != expected_hash:
                hash_failures.append(name)
        except (OSError, ValueError, RuntimeError):
            hash_failures.append(name)
    bag = manifest.get("bag") if isinstance(manifest.get("bag"), dict) else {}
    if bag.get("storage_id") != "mcap":
        malformed = True
    if not isinstance(bag.get("message_count"), int) or bag.get("message_count", 0) <= 0:
        malformed = True
    bag_files = bag.get("files")
    expected_mcap_names = {name for name in expected if name.endswith(".mcap")}
    if (
        not isinstance(bag_files, list)
        or any(not isinstance(name, str) for name in bag_files)
        or set(bag_files) != expected_mcap_names
    ):
        malformed = True
    hashes_passed = not (
        malformed or missing_files or unexpected_files or hash_failures
    )

    topic_map = bag.get("topics") if isinstance(bag.get("topics"), dict) else {}
    required = sorted(set(required_topics))
    missing_topics = sorted(set(required) - set(topic_map))
    empty_topics = sorted(
        topic
        for topic in required
        if topic in topic_map
        and (
            not isinstance(topic_map[topic], dict)
            or not isinstance(topic_map[topic].get("message_count"), int)
            or topic_map[topic].get("message_count", 0) <= 0
        )
    )
    topics_passed = not missing_topics and not empty_topics

    try:
        actual_duration = float(bag.get("duration_seconds"))
        minimum_duration = float(minimum_duration_seconds)
        maximum_duration = float(maximum_duration_seconds)
        duration_passed = (
            math.isfinite(actual_duration)
            and math.isfinite(minimum_duration)
            and math.isfinite(maximum_duration)
            and minimum_duration >= 0
            and maximum_duration >= minimum_duration
            and actual_duration >= minimum_duration
            and actual_duration <= maximum_duration
        )
    except (TypeError, ValueError):
        actual_duration = None
        minimum_duration = minimum_duration_seconds
        maximum_duration = maximum_duration_seconds
        duration_passed = False

    rate_requirements = dict(minimum_topic_rates or {})
    rate_results: dict[str, dict[str, Any]] = {}
    invalid_rate_requirements: list[str] = []
    missing_rate_topics: list[str] = []
    below_minimum_topics: list[str] = []
    for topic, minimum_rate in sorted(rate_requirements.items()):
        try:
            minimum_rate_value = float(minimum_rate)
        except (TypeError, ValueError):
            invalid_rate_requirements.append(topic)
            continue
        if not math.isfinite(minimum_rate_value) or minimum_rate_value <= 0:
            invalid_rate_requirements.append(topic)
            continue
        topic_entry = topic_map.get(topic)
        message_count = (
            topic_entry.get("message_count")
            if isinstance(topic_entry, dict)
            else None
        )
        if (
            topic_entry is None
            or not isinstance(message_count, int)
            or message_count < 0
            or actual_duration is None
            or actual_duration <= 0
        ):
            missing_rate_topics.append(topic)
            rate_results[topic] = {
                "message_count": message_count,
                "actual_fps": None,
                "minimum_fps": minimum_rate_value,
                "passed": False,
            }
            continue
        actual_rate = message_count / actual_duration
        passed = actual_rate >= minimum_rate_value
        if not passed:
            below_minimum_topics.append(topic)
        rate_results[topic] = {
            "message_count": message_count,
            "actual_fps": actual_rate,
            "minimum_fps": minimum_rate_value,
            "passed": passed,
        }
    topic_rates_passed = not (
        invalid_rate_requirements or missing_rate_topics or below_minimum_topics
    )

    checks = {
        "hashes": {
            "passed": hashes_passed,
            "files_checked": len(set(expected) & actual_names),
            "missing": missing_files,
            "unexpected": unexpected_files,
            "mismatched": sorted(set(hash_failures)),
        },
        "required_topics": {
            "passed": topics_passed,
            "required": required,
            "missing": missing_topics,
            "empty": empty_topics,
        },
        "duration": {
            "passed": duration_passed,
            "actual_seconds": actual_duration,
            "minimum_seconds": minimum_duration,
            "maximum_seconds": maximum_duration,
        },
        "topic_rates": {
            "passed": topic_rates_passed,
            "results": rate_results,
            "invalid_requirements": invalid_rate_requirements,
            "missing": missing_rate_topics,
            "below_minimum": below_minimum_topics,
        },
    }
    return {
        "schema_version": 1,
        "status": "PASS" if all(item["passed"] for item in checks.values()) else "FAIL",
        "run_id": manifest.get("run_id"),
        "remote_recorded_dir": manifest.get("recorded_dir"),
        "local_recorded_dir": os.fspath(local_recorded_dir),
        "remote_data_retained": True,
        "checks": checks,
    }


def write_reports(output_dir: Path, report: dict[str, Any]) -> tuple[Path, Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "report.json"
    markdown_path = output_dir / "report.md"
    json_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    checks = report.get("checks", {})
    hashes = checks.get("hashes", {})
    topics = checks.get("required_topics", {})
    duration = checks.get("duration", {})
    topic_rates = checks.get("topic_rates", {})
    missing_topics = topics.get("missing", [])
    markdown = f"""# Realbot 录制交付验收报告

| 项目 | 结果 |
|---|---|
| 总结论 | **{report.get('status', 'FAIL')}** |
| Run ID | `{report.get('run_id', '')}` |
| 远端录制目录 | `{report.get('remote_recorded_dir', '')}` |
| 本地录制目录 | `{report.get('local_recorded_dir', '')}` |
| 远端数据保留 | `True` |

## 验收明细

- SHA-256 逐文件校验：`{'PASS' if hashes.get('passed') else 'FAIL'}`，已检查 {hashes.get('files_checked', 0)} 个文件。
- 必需 Topic：`{'PASS' if topics.get('passed') else 'FAIL'}`，缺失：`{', '.join(missing_topics) if missing_topics else '无'}`。
- Bag 时长：`{'PASS' if duration.get('passed') else 'FAIL'}`，实际 {duration.get('actual_seconds')} s，最低要求 {duration.get('minimum_seconds')} s。
- Bag 时长上限：{duration.get('maximum_seconds')} s。
- 相机平均帧率：`{'PASS' if topic_rates.get('passed') else 'FAIL'}`，低于门槛：`{', '.join(topic_rates.get('below_minimum', [])) if topic_rates.get('below_minimum') else '无'}`。

> 本 Demo 不删除机器人端录制或 evidence。即使本地验收 PASS，远端数据仍保留。
"""
    markdown_path.write_text(markdown, encoding="utf-8")
    return json_path, markdown_path


def build_execution_plan(
    host: str,
    user: str,
    run_id: str,
    scene: str,
    task: str,
    operator: str,
    device: str,
    duration: float,
    output_dir: Path,
    remote_root: str = DEFAULT_REMOTE_ROOT,
) -> dict[str, Any]:
    _validate_transport_identity(user, host)
    _validate_run_id(run_id)
    _safe_remote_root(remote_root)
    stage_root = f"/home/{user}/.cache/realbot-recording-demo/{run_id}"
    stage_parent = f"/home/{user}/.cache/realbot-recording-demo"
    stage_script = f"{stage_root}/examples/04_data_recording/recording_delivery_demo.py"
    robot_command = " ".join(
        shlex.quote(value)
        for value in (
            "python3",
            stage_script,
            "--robot-stage",
            "--run-id",
            run_id,
            "--scene",
            scene,
            "--task",
            task,
            "--operator",
            operator,
            "--device",
            device,
            "--duration",
            str(duration),
            "--remote-root",
            remote_root,
            "--confirm-recording-write",
        )
    )
    sourced_command = (
        "source /opt/ros/humble/setup.bash && "
        "source /home/realman/workspace/rm_robot_ws/install/setup.bash && "
        + robot_command
    )
    return {
        "schema_version": 1,
        "mode": "execute",
        "run_id": run_id,
        "duration_seconds": float(duration),
        "remote_data_retained": True,
        "output_dir": os.fspath(output_dir),
        "remote_root": remote_root,
        "steps": [
            {
                "name": "prepare-stage",
                "command": (
                    f"install -d -m 700 -- {stage_parent} && "
                    f"mkdir -m 700 -- {stage_root}"
                ),
            },
            {
                "name": "upload-reviewed-runtime-files",
                "command": (
                    "scp five reviewed Python runtime files into the explicit "
                    f"package paths below {stage_root}/examples/"
                ),
                "files": [
                    "examples/__init__.py",
                    "examples/04_data_recording/recording_delivery_demo.py",
                    "examples/04_data_recording/record_once.py",
                    "examples/platform_bridge/__init__.py",
                    "examples/platform_bridge/bridge_core.py",
                ],
            },
            {
                "name": "record-and-build-evidence",
                "command": sourced_command,
                "uses": ["record_once.py", "ros2 bag info", "delivery_manifest.json"],
                "write_preflight": [
                    "fixed /home/realman/ssd/mcap_recorded root",
                    "dedicated block-device mount at /home/realman/ssd",
                    "at least 5 GiB free",
                    "empty mcap_recording directory",
                    "non-blocking Demo process lock",
                ],
            },
            {
                "name": "download-exact-results",
                "command": "scp <exact-recorded-dir> <exact-evidence-dir>",
            },
            {
                "name": "verify",
                "checks": [
                    "SHA-256",
                    "required Topics > 0",
                    "duration window",
                    f"four camera image Topics >= {DEFAULT_MINIMUM_CAMERA_FPS:.1f} fps",
                ],
            },
        ],
    }


def _load_record_once_module():
    path = Path(__file__).with_name("record_once.py")
    spec = importlib.util.spec_from_file_location("realbot_record_once_for_delivery", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load sibling record_once.py: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _run_robot_stage(args: argparse.Namespace) -> dict[str, Any]:
    run_id = _validate_run_id(args.run_id)
    root = Path(os.fspath(_safe_remote_root(args.remote_root)))
    record_once = _load_record_once_module()
    meta = record_once.build_record_meta(
        args.scene, args.task, args.operator, args.device, run_id
    )
    print(
        json.dumps(
            {"status": "prepared", "run_id": run_id, "meta": meta},
            separators=(",", ":"),
        ),
        flush=True,
    )
    recorded = record_once.record_once(meta, args.duration, root=root)
    remote_recorded = os.fspath(recorded)
    _safe_remote_recorded_dir(remote_recorded, args.remote_root, run_id)
    bag_info_process = subprocess.run(
        ["ros2", "bag", "info", remote_recorded],
        check=True,
        text=True,
        capture_output=True,
        timeout=60,
    )
    bag_info_text = bag_info_process.stdout
    parsed_bag_info = parse_ros2_bag_info(bag_info_text)
    manifest = build_delivery_manifest(run_id, recorded, remote_recorded, parsed_bag_info)

    evidence_dir = Path(DEFAULT_EVIDENCE_ROOT) / run_id
    evidence_dir.mkdir(parents=True, exist_ok=False)
    (evidence_dir / "ros2_bag_info.txt").write_text(bag_info_text, encoding="utf-8")
    (evidence_dir / "delivery_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    completed = {
        "status": "completed",
        "run_id": run_id,
        "recorded_dir": remote_recorded,
        "evidence_dir": os.fspath(evidence_dir),
        "meta": meta,
        "remote_data_retained": True,
    }
    print(json.dumps(completed, separators=(",", ":")), flush=True)
    return completed


def _parse_stage_output(stdout: str, run_id: str, remote_root: str) -> dict[str, Any]:
    record_result = parse_record_once_output(stdout, run_id, remote_root)
    completed_objects: list[dict[str, Any]] = []
    for line in stdout.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(item, dict) and item.get("status") == "completed":
            completed_objects.append(item)
    if len(completed_objects) != 1:
        raise RuntimeError("robot stage did not return one completed result")
    completed = completed_objects[0]
    evidence_dir = completed.get("evidence_dir")
    expected_evidence = f"{DEFAULT_EVIDENCE_ROOT}/{run_id}"
    if evidence_dir != expected_evidence:
        raise RuntimeError("robot stage returned an unexpected evidence directory")
    return {**record_result, "evidence_dir": evidence_dir}


def _run_customer(args: argparse.Namespace, run_id: str) -> dict[str, Any]:
    plan = build_execution_plan(
        args.host,
        args.user,
        run_id,
        args.scene,
        args.task,
        args.operator,
        args.device,
        args.duration,
        args.output,
        args.remote_root,
    )
    stage_root = f"/home/{args.user}/.cache/realbot-recording-demo/{run_id}"
    stage_parent = f"/home/{args.user}/.cache/realbot-recording-demo"
    stage_recording_dir = f"{stage_root}/examples/04_data_recording"
    stage_bridge_dir = f"{stage_root}/examples/platform_bridge"
    prepare = (
        f"install -d -m 700 -- {shlex.quote(stage_parent)} && "
        f"mkdir -m 700 -- {shlex.quote(stage_root)} && "
        f"mkdir -m 700 -- {shlex.quote(stage_root + '/examples')} && "
        f"mkdir -m 700 -- {shlex.quote(stage_recording_dir)} && "
        f"mkdir -m 700 -- {shlex.quote(stage_bridge_dir)}"
    )
    run_output = Path(args.output) / run_id
    # Reserve the local run directory before causing any robot-side write.  A
    # collision or stale partial result therefore cannot be merged silently.
    run_output.mkdir(parents=True, exist_ok=False)
    subprocess.run(
        build_ssh_argv(args.user, args.host, prepare), check=True, timeout=120
    )

    recording_example_root = Path(__file__).resolve().parent
    examples_root = recording_example_root.parent
    bridge_root = examples_root / "platform_bridge"
    subprocess.run(
        _build_scp_upload_argv(
            args.user,
            args.host,
            (
                recording_example_root / "recording_delivery_demo.py",
                recording_example_root / "record_once.py",
            ),
            stage_recording_dir,
        ),
        check=True,
        timeout=300,
    )
    subprocess.run(
        _build_scp_upload_argv(
            args.user,
            args.host,
            (examples_root / "__init__.py",),
            f"{stage_root}/examples",
        ),
        check=True,
        timeout=120,
    )
    subprocess.run(
        _build_scp_upload_argv(
            args.user,
            args.host,
            (bridge_root / "__init__.py", bridge_root / "bridge_core.py"),
            stage_bridge_dir,
        ),
        check=True,
        timeout=120,
    )
    remote_command = next(
        step["command"]
        for step in plan["steps"]
        if step["name"] == "record-and-build-evidence"
    )
    stage_process = subprocess.run(
        build_ssh_argv(
            args.user,
            args.host,
            f"bash -lc {shlex.quote(remote_command)}",
        ),
        check=False,
        text=True,
        capture_output=True,
        timeout=max(180.0, args.duration + 120.0),
    )
    if stage_process.returncode != 0:
        detail = stage_process.stderr.strip() or "remote stage returned no error text"
        raise RuntimeError(
            f"robot stage failed before delivery verification (exit {stage_process.returncode}): "
            f"{detail}"
        )
    stage = _parse_stage_output(stage_process.stdout, run_id, args.remote_root)

    subprocess.run(
        build_scp_argv(
            args.user, args.host, stage["recorded_dir"], run_output
        ),
        check=True,
        timeout=600,
    )
    subprocess.run(
        build_scp_argv(args.user, args.host, stage["evidence_dir"], run_output),
        check=True,
        timeout=120,
    )
    local_recorded = run_output / PurePosixPath(stage["recorded_dir"]).name
    local_evidence = run_output / PurePosixPath(stage["evidence_dir"]).name
    manifest_path = local_evidence / "delivery_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    report = verify_download(
        local_recorded,
        manifest,
        DEFAULT_REQUIRED_TOPICS,
        args.minimum_duration,
        args.maximum_duration,
        expected_run_id=run_id,
        expected_remote_recorded_dir=stage["recorded_dir"],
        minimum_topic_rates={
            topic: args.minimum_camera_fps for topic in DEFAULT_CAMERA_TOPICS
        },
    )
    write_reports(run_output, report)
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scene", required=True)
    parser.add_argument("--task", required=True)
    parser.add_argument("--operator", required=True)
    parser.add_argument("--device", required=True)
    parser.add_argument("--duration", type=float, default=DEFAULT_DURATION_SECONDS)
    parser.add_argument("--minimum-duration", type=float, default=DEFAULT_MINIMUM_DURATION_SECONDS)
    parser.add_argument("--maximum-duration", type=float, default=DEFAULT_MAXIMUM_DURATION_SECONDS)
    parser.add_argument(
        "--minimum-camera-fps",
        type=float,
        default=DEFAULT_MINIMUM_CAMERA_FPS,
        help="fail delivery if any configured wide-camera image Topic averages below this rate",
    )
    parser.add_argument("--host", default=DEFAULT_HOST)
    parser.add_argument("--user", default=DEFAULT_USER)
    parser.add_argument("--output", type=Path, default=Path("recording-deliveries"))
    parser.add_argument("--remote-root", default=DEFAULT_REMOTE_ROOT)
    parser.add_argument("--run-id", help=argparse.SUPPRESS)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--dry-run", action="store_true")
    modes.add_argument("--execute", action="store_true")
    modes.add_argument("--robot-stage", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument(
        "--confirm-recording-write",
        action="store_true",
        help="required with --execute; confirms a bounded robot-side recording write",
    )
    return parser


def _validate_args(args: argparse.Namespace) -> None:
    if not math.isfinite(args.duration) or args.duration <= 0 or args.duration > 3600:
        raise ValueError("duration must be greater than 0 and at most 3600 seconds")
    if (
        not math.isfinite(args.minimum_duration)
        or args.minimum_duration < 0
        or args.minimum_duration > args.duration
    ):
        raise ValueError("minimum duration must be between 0 and requested duration")
    if (
        not math.isfinite(args.maximum_duration)
        or args.maximum_duration < args.minimum_duration
        or args.maximum_duration > args.duration * 1.5
    ):
        raise ValueError(
            "maximum duration must be at least the minimum and no more than 1.5x requested duration"
        )
    if (
        not math.isfinite(args.minimum_camera_fps)
        or args.minimum_camera_fps <= 0
        or args.minimum_camera_fps > 120
    ):
        raise ValueError("minimum camera fps must be greater than 0 and at most 120")
    _safe_remote_root(args.remote_root)
    if args.remote_root != DEFAULT_REMOTE_ROOT:
        raise ValueError("this customer demo only permits the fixed recorded-data root")
    if (args.execute or args.robot_stage) and not args.confirm_recording_write:
        raise ValueError("write modes require --confirm-recording-write")
    if args.dry_run and args.confirm_recording_write:
        raise ValueError("--confirm-recording-write is not valid with --dry-run")
    if args.robot_stage:
        if args.run_id is None:
            raise ValueError("robot stage requires --run-id")
        _validate_run_id(args.run_id)
    elif args.run_id is not None:
        raise ValueError("--run-id is reserved for robot stage")


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    _validate_args(args)
    if args.robot_stage:
        _run_robot_stage(args)
        return 0
    run_id = new_run_id()
    plan = build_execution_plan(
        args.host,
        args.user,
        run_id,
        args.scene,
        args.task,
        args.operator,
        args.device,
        args.duration,
        args.output,
        args.remote_root,
    )
    if args.dry_run:
        plan["mode"] = "dry-run"
        print(json.dumps(plan, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    # Print the run marker before the first network operation.  If the client
    # connection later drops, the operator still has the exact ID needed to
    # locate and inspect the retained robot-side recording and evidence.
    print(
        json.dumps(
            {
                "status": "prepared",
                "run_id": run_id,
                "remote_data_retained": True,
            },
            separators=(",", ":"),
        ),
        flush=True,
    )
    report = _run_customer(args, run_id)
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
