# 录制交付闭环 Demo

> 当前状态：**正式发布**。2026-07-17 已在 `RealBot01_RX75` / 软件 `V1.1.1-dl` / 硬件 `1.2` 按最终代码流程完成 10 秒实机闭环；run ID 为 `e1d9eff2f7194a86`，实际包时长 `9.062810605 s`，哈希、五个必需 Topic 和时长均通过。

本 Demo 从客户工作站发起，完成唯一 run ID、10 秒有界录制、停止落盘、精确目录定位、`ros2 bag info`、机器人端 SHA-256、严格拉取、本地复算哈希，以及 Topic/时长验收。机器人端录制和证据默认保留，脚本没有远端删除选项。

## 前置条件

- 客户工作站可运行 Python 3、系统 `ssh` 和 `scp`，并位于本交付包根目录。
- 机器人为 `192.168.127.10`，SSH 用户为 `realman`；密码只在系统 SSH/SCP 的交互提示中输入。
- 机器人已具备 ROS2 Humble、`/home/realman/workspace/rm_robot_ws` 和 `/mcap_recorder_service`。
- 录制前确认机器人没有其他录制、上传、OTA 或高负载任务。Demo 会自动检查数据盘和简化版录制中目录，但不能代替现场安全确认。

首次连接时，先通过交付清单或独立渠道核对设备 SSH 指纹，再人工接受：

```bash
ssh realman@192.168.127.10
```

禁止使用 `sshpass`、`expect`、密码环境变量、`StrictHostKeyChecking=no`、`accept-new`、`UserKnownHostsFile=/dev/null` 或 `yes | ssh`。Demo 强制 `StrictHostKeyChecking=yes`；主机密钥未登记或发生变化时会停止。

### 自动保护与人工责任边界

真正调用录制 Service 前，机器人端脚本会在同一个跨进程非阻塞锁内逐项检查：

1. 完成目录必须精确为 `/home/realman/ssd/mcap_recorded`，不接受其他根目录或嵌套目录；
2. `/home/realman/ssd` 必须是 `findmnt` 返回的挂载目标本身，且来源经系统判定为真实块设备；tmpfs、NFS、bind 目录和父目录回退挂载均拒绝写入；
3. SSD 可用空间不少于 **5 GiB**；
4. `/home/realman/ssd/mcap_recording` 必须是真实目录且直接内容为空；发现任何目录或文件都按“录制状态未知”停止；
5. 同一 Demo 的第二个进程不会排队，而是立即报错。锁在正常、异常和中断退出时都释放。

任一自动检查失败时，脚本**不调用录制 Service、不发送自动 stop、不删除或移动数据**。操作者仍需人工确认机器人静止、无其他录制/上传/OTA/高负载任务、SSH 指纹可信，并明确授权本次写盘。该锁只协调本 Demo，不代表其他程序已停止。

## 1. 先看执行计划（不联网、不写盘）

在客户工作站、交付包根目录执行：

```bash
python3 examples/04_data_recording/recording_delivery_demo.py \
  --scene demo \
  --task delivery \
  --operator customer01 \
  --device realbot01 \
  --dry-run
```

输出包含本次随机生成的 16 位十六进制 run ID、远端固定目录和完整阶段计划。`--dry-run` 不调用 SSH/SCP，也不录制。

## 2. 执行 10 秒录制并拉取验收

确认机器人静止、录制服务空闲且允许本次写盘后执行：

```bash
python3 examples/04_data_recording/recording_delivery_demo.py \
  --scene demo \
  --task delivery \
  --operator customer01 \
  --device realbot01 \
  --duration 10 \
  --minimum-duration 8 \
  --maximum-duration 12 \
  --minimum-camera-fps 29 \
  --output ./recording-deliveries \
  --execute \
  --confirm-recording-write
```

系统 `ssh`/`scp` 可能多次交互提示密码；脚本不接收、保存或输出密码。执行链依次为：

1. 生成并先输出唯一 run ID；只把录制主脚本、`record_once.py`、元数据校验模块及必需的两个空包入口（共 5 个已审核 Python 文件）上传到机器人用户缓存目录，不上传 `__pycache__` 或其他示例。
2. 机器人端先在 Demo 锁内完成固定根目录、独立块设备挂载、5 GiB 可用空间和空 `mcap_recording` 检查；通过后才复用 `record_once.py` 启停 10 秒录制，只接受 `/home/realman/ssd/mcap_recorded` 下唯一、精确匹配 run ID 的完成目录。
3. 在机器人端执行 `ros2 bag info`，要求 `mcap` 存储、非空 `metadata.yaml` 和至少一个非空 `.mcap`，并生成逐文件 SHA-256 清单。
4. 拉取精确录制目录和 `/home/realman/ssd/mcap_delivery_evidence/<run-id>`。
5. 本地复算文件集合、大小和 SHA-256，验收 8～12 秒有效数据时长、五个必需本体 Topic 的消息数大于 0，并要求四路宽视相机图像 Topic 的整段平均帧率均不低于 29 Hz。
6. 写出 `report.json` 与 `report.md`；全部通过时退出码为 `0`，验收失败时为 `2`，执行异常时为非零。

当前五个必需 Topic：

- `/mcap/body`
- `/mcap/master_arm_left`
- `/mcap/slave_arm_left`
- `/mcap/master_arm_right`
- `/mcap/slave_arm_right`

当前四路相机帧率验收 Topic：

- `/left_arm_wide_cam/color/image_raw/compressed`
- `/right_arm_wide_cam/color/image_raw/compressed`
- `/left_head_wide_cam/color/image_raw/compressed`
- `/right_head_wide_cam/color/image_raw/compressed`

平均帧率按 MCAP 内 `message_count / duration` 计算。默认门槛为 29 Hz，可用 `--minimum-camera-fps` 提高，但不能设为 0 或借此跳过相机验收。该指标用于拦截低帧率交付，不代表瞬时帧率始终为 30 Hz。

10 秒是服务启停间的计划等待时间；录制器开始后约有 1 秒订阅跳过期，因此默认接受包内首末消息时间跨度 8～12 秒。必需 Topic 不以固定频率作通用承诺，但必须存在且消息数大于 0。

## 3. 交付产物与判定

```text
recording-deliveries/<run-id>/
├── <精确录制目录>/
│   ├── metadata.yaml
│   └── *.mcap
├── <run-id>/
│   ├── ros2_bag_info.txt
│   └── delivery_manifest.json
├── report.json
└── report.md
```

`report.json.status == "PASS"` 才表示本次文件集合、哈希、必需 Topic、相机平均帧率和时长全部通过。网络中断、SSH 超时或进程异常时，写操作结果可能未知：记录终端最先输出的 run ID，禁止立即重发 start；先检查精确录制目录、证据目录、录制服务和日志。

2026-07-17 的最终基线 run ID `e1d9eff2f7194a86` 已用新增帧率规则复算：四路图像分别为 30.123、29.902、30.013、30.013 Hz，结果仍为 PASS。

## 运行时参数限制

不要在录制节点运行期间用 `ros2 param set /mcap_recorder topics ...` 或修改压缩参数来热切换配置。实机测试发现参数接口可能返回成功，但下一包仍按节点启动时缓存的 Topic 录制。需要调整 Topic 或压缩方式时，应先停止录制、备份 YAML，在维护窗口重启对应录制节点，并以新 MCAP 的实际 Topic 列表作为唯一生效判据。

执行结束后，从终端首行复制正式 run ID 查看报告：

```bash
export RUN_ID='<本次正式执行输出的run_id>'
python3 -m json.tool "recording-deliveries/${RUN_ID}/report.json"
```

## 为什么默认不删除

拉取成功只证明文件到达本地，哈希一致只证明传输前后字节一致；它们都不能替代 Topic、时长和客户业务验收。网络中断、分析失败或审批未完成时，机器人端数据仍是可恢复原件。因此本 Demo 不实现“拉取即删”，也不提供通配符清理命令。后续清理必须由管理员针对精确的 run ID 目录单独授权执行。
