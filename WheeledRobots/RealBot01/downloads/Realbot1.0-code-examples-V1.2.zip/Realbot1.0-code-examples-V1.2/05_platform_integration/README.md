# 客户平台集成示例

实际可导入的平台桥代码位于 `examples.platform_bridge`，不要尝试从以数字开头的 `05_platform_integration` 目录导入 Python 包。

## 安全默认值

- HTTP 桥默认只监听 `127.0.0.1:8090`；平台可先通过 SSH 隧道访问。
- 启动时必须从环境变量读取 `REALBOT_BRIDGE_TOKEN`，所有三个端点都要求精确的 Bearer token。
- 非 loopback 绑定只允许在机器人受信私有 LAN 中显式开启。穿越不受信任网络时，在桥外层部署 TLS 终止、网络 ACL 与访问审计。
- 示例不自动删除录制目录。拉取、校验和审批后的精确目录清理由客户运维流程负责。

## 本地验证（不连机器人）

```bash
python3 -m unittest tests.test_bridge_core -v
python3 -m py_compile examples/platform_bridge/*.py examples/04_data_recording/*.py
```

## 机器人端启动模板

以下步骤会改变机器人进程和网络暴露面，只在取得授权、备份现有单元文件并准备回滚后由机器人管理员执行。

```bash
# Shell 归属：机器人端
source /opt/ros/humble/setup.bash
source /home/realman/workspace/rm_robot_ws/install/setup.bash
export REALBOT_BRIDGE_TOKEN='<由客户密钥管理系统注入>'
python3 -m examples.platform_bridge.secure_record_bridge
```

成功判据：日志仅显示 `record bridge listening on 127.0.0.1:8090`，无 token 内容；未带 token 的三个端点均返回 HTTP 401。失败时不要改为 `0.0.0.0` 绕过问题，先查看 ROS2 source、录制服务及环境变量。

`realbot-record-bridge.service.example` 是审查用 systemd 模板，凭据由 `/etc/realbot-record-bridge.env` 独立注入，不写进单元文件或命令行。

## 客户端请求

```bash
# Shell 归属：客户平台（通过 SSH 隧道映射 8090 后）
export REALBOT_BRIDGE_TOKEN='<与桥一致的 token>'
python3 -m examples.platform_bridge.record_client start \
  --scene kitchen --task pick_001 --operator op01 --device 110
python3 -m examples.platform_bridge.record_client stop \
  --scene kitchen --task pick_001 --operator op01 --device 110
python3 -m examples.platform_bridge.record_client list
```

请求失败时不重试 start，先查询录制器实际状态；超时不能证明命令未被执行。
