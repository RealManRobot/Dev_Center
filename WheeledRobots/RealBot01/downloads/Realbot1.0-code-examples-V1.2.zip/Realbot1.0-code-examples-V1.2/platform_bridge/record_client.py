#!/usr/bin/env python3
"""Dependency-free client for the authenticated recording bridge."""

from __future__ import annotations

import argparse
import json
import os
import urllib.error
import urllib.request

from examples.platform_bridge.bridge_core import (
    validate_meta,
    validate_recorder_response,
)


def make_request(
    base_url: str,
    token: str,
    action: str,
    meta: dict[str, str] | None = None,
) -> urllib.request.Request:
    if action not in {"start", "stop", "list"}:
        raise ValueError("action must be start, stop, or list")
    if not token or token.strip() != token:
        raise ValueError("REALBOT_BRIDGE_TOKEN is required")
    url = base_url.rstrip("/") + f"/record/{action}"
    headers = {"Authorization": f"Bearer {token}"}
    if action == "list":
        return urllib.request.Request(url, headers=headers, method="GET")
    body = json.dumps(
        validate_meta(meta), separators=(",", ":")
    ).encode("utf-8")
    headers["Content-Type"] = "application/json"
    return urllib.request.Request(
        url, data=body, headers=headers, method="POST"
    )


def call_bridge(request: urllib.request.Request, timeout: float = 15.0) -> dict:
    if not 0 < timeout <= 30:
        raise ValueError("timeout must be in 0..30 seconds")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("bridge request failed") from exc
    return validate_recorder_response(payload)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("start", "stop", "list"))
    parser.add_argument("--base-url", default="http://127.0.0.1:8090")
    parser.add_argument("--scene")
    parser.add_argument("--task")
    parser.add_argument("--operator")
    parser.add_argument("--device")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    token = os.environ.get("REALBOT_BRIDGE_TOKEN", "")
    meta = None
    if args.action != "list":
        meta = {
            "scene": args.scene,
            "task": args.task,
            "operator": args.operator,
            "device": args.device,
        }
    request = make_request(args.base_url, token, args.action, meta)
    print(json.dumps(call_bridge(request), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
