"""Security-hardened HTTP recording bridge example."""

from .bridge_core import authorized, validate_meta

__all__ = ["authorized", "validate_meta"]
