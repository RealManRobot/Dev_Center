#!/usr/bin/env python3
"""Authenticated HTTP adapter for the Realbot simplified MCAP recorder.

Run on the robot from the manual package root after sourcing ROS2.  Importing
this module does not require ROS2, which keeps configuration checks testable.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Mapping

from examples.platform_bridge.bridge_core import (
    BridgeApplication,
    PayloadTooLarge,
    SerializedRecorder,
    authorized,
    validate_content_length,
)


DEFAULT_BIND = "127.0.0.1"
DEFAULT_PORT = 8090
DEFAULT_RECORDED_DIR = Path("/home/realman/ssd/mcap_recorded")
REMOTE_ACK = "I_ACKNOWLEDGE_PRIVATE_LAN_ONLY"


@dataclass(frozen=True)
class BridgeConfig:
    bind: str
    port: int
    token: str
    recorded_dir: Path


def load_config(environment: Mapping[str, str] | None = None) -> BridgeConfig:
    """Load strict bridge settings without logging secret values."""
    env = os.environ if environment is None else environment
    token = env.get("REALBOT_BRIDGE_TOKEN", "")
    if not token or token.strip() != token or any(c in token for c in "\r\n"):
        raise ValueError("REALBOT_BRIDGE_TOKEN must be a non-empty secret")
    bind = env.get("REALBOT_BRIDGE_BIND", DEFAULT_BIND)
    if bind not in {"127.0.0.1", "::1", "localhost"}:
        if env.get("REALBOT_ALLOW_REMOTE_BIND") != REMOTE_ACK:
            raise ValueError(
                "non-loopback binding is allowed only on a private LAN with "
                f"REALBOT_ALLOW_REMOTE_BIND={REMOTE_ACK}"
            )
    raw_port = env.get("REALBOT_BRIDGE_PORT", str(DEFAULT_PORT))
    if not raw_port.isascii() or not raw_port.isdecimal():
        raise ValueError("REALBOT_BRIDGE_PORT must be a decimal integer")
    port = int(raw_port)
    if not 1 <= port <= 65535:
        raise ValueError("REALBOT_BRIDGE_PORT must be in 1..65535")
    recorded_dir = Path(env.get("REALBOT_RECORDED_DIR", str(DEFAULT_RECORDED_DIR)))
    if not recorded_dir.is_absolute():
        raise ValueError("REALBOT_RECORDED_DIR must be absolute")
    return BridgeConfig(bind, port, token, recorded_dir)


def format_access_log(method: str, path: str, status: int) -> str:
    """Format a minimal log record; this API cannot receive credentials."""
    safe_path = path.split("?", 1)[0]
    if safe_path not in {"/record/start", "/record/stop", "/record/list"}:
        safe_path = "<unknown>"
    return f"{method} {safe_path} -> {status}"


class RosRecorderAdapter:
    """Lazy ROS2 adapter for ``/mcap_recorder_service``."""

    def __init__(self) -> None:
        import rclpy
        from rclpy.node import Node
        from rm_robot_interfaces.srv import StringCmd

        self._rclpy = rclpy
        self._service_type = StringCmd
        rclpy.init()
        self._node = Node("realbot_secure_record_bridge")
        self._client = self._node.create_client(
            StringCmd, "/mcap_recorder_service"
        )

    def __call__(self, operate: int, meta: dict[str, str]) -> dict[str, object]:
        if not self._client.wait_for_service(timeout_sec=5.0):
            raise RuntimeError("recorder service unavailable")
        request = self._service_type.Request()
        request.data = json.dumps(
            {
                "operate": operate,
                "command": "capture",
                "sence_id": meta["scene"],
                "task_id": meta["task"],
                "operator_id": meta["operator"],
                "device_id": meta["device"],
            },
            separators=(",", ":"),
        )
        future = self._client.call_async(request)
        self._rclpy.spin_until_future_complete(
            self._node, future, timeout_sec=10.0
        )
        response = future.result() if future.done() else None
        if response is None:
            raise RuntimeError("recorder service timed out")
        try:
            decoded = json.loads(response.data)
        except (TypeError, json.JSONDecodeError) as exc:
            raise RuntimeError("recorder returned invalid JSON") from exc
        if not isinstance(decoded, dict):
            raise RuntimeError("recorder response must be a JSON object")
        return decoded

    def close(self) -> None:
        self._node.destroy_node()
        self._rclpy.shutdown()


def make_handler(application: BridgeApplication):
    """Create an HTTP handler bound to one configured application."""

    class BridgeRequestHandler(BaseHTTPRequestHandler):
        server_version = "RealbotRecordBridge/1.0"

        def _reply(self, status: int, payload: dict[str, object]) -> None:
            encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(encoded)
            print(format_access_log(self.command, self.path, status), flush=True)

        def _run(self, method: str) -> None:
            auth_header = self.headers.get("Authorization")
            if not authorized(auth_header, application._token):
                status, payload = application.handle(
                    method, self.path, auth_header, None, b""
                )
                self._reply(status, payload)
                return
            body = b""
            content_length = self.headers.get("Content-Length")
            if method == "POST":
                try:
                    length = validate_content_length(content_length)
                except (ValueError, PayloadTooLarge):
                    status, payload = application.handle(
                        method, self.path, auth_header, content_length, body
                    )
                    self._reply(status, payload)
                    return
                body = self.rfile.read(length)
            status, payload = application.handle(
                method, self.path, auth_header, content_length, body
            )
            self._reply(status, payload)

        def do_POST(self) -> None:
            self._run("POST")

        def do_GET(self) -> None:
            self._run("GET")

        def log_message(self, fmt: str, *args: object) -> None:
            return

    return BridgeRequestHandler


def main() -> int:
    config = load_config()
    adapter = RosRecorderAdapter()
    application = BridgeApplication(
        token=config.token,
        recorder=SerializedRecorder(adapter),
        recorded_dir=config.recorded_dir,
    )
    server = ThreadingHTTPServer(
        (config.bind, config.port), make_handler(application)
    )
    server.daemon_threads = True
    print(f"record bridge listening on {config.bind}:{config.port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        adapter.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
