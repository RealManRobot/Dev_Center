"""Pure validation and dispatch logic for the recording HTTP bridge."""

from __future__ import annotations

import hmac
import json
import re
import stat
import threading
from collections.abc import Callable
from pathlib import Path
from typing import Any


REQUIRED = ("scene", "task", "operator", "device")
MAX_BODY_BYTES = 64 * 1024
_META_RE = re.compile(r"[A-Za-z0-9._-]{1,128}\Z")


class LengthRequired(ValueError):
    """The request did not declare a Content-Length."""


class PayloadTooLarge(ValueError):
    """The declared request body exceeds the bridge limit."""


def authorized(header: str | None, token: str) -> bool:
    """Return true only for an exact, non-empty Bearer token match."""
    if (
        not isinstance(header, str)
        or not isinstance(token, str)
        or not token
        or token.strip() != token
        or any(char in token for char in "\r\n")
    ):
        return False
    return hmac.compare_digest(header, f"Bearer {token}")


def validate_meta(value: object) -> dict[str, str]:
    """Validate and normalize the four recorder metadata fields."""
    if not isinstance(value, dict):
        raise ValueError("JSON body must be an object")
    unknown = sorted(set(value) - set(REQUIRED))
    if unknown:
        raise ValueError("unknown metadata fields: " + ", ".join(map(str, unknown)))
    result: dict[str, str] = {}
    for key in REQUIRED:
        raw = value.get(key)
        normalized = raw.strip() if isinstance(raw, str) else ""
        if (
            not isinstance(raw, str)
            or not normalized
            or not _META_RE.fullmatch(normalized)
            or normalized in {".", ".."}
        ):
            raise ValueError(f"invalid {key}")
        result[key] = normalized
    return result


def validate_content_length(raw: str | None) -> int:
    """Parse a required decimal Content-Length in the range 1..64 KiB."""
    if raw is None or raw == "":
        raise LengthRequired("Content-Length is required")
    if not isinstance(raw, str) or not raw.isascii() or not raw.isdecimal():
        raise ValueError("Content-Length must be an unsigned decimal integer")
    length = int(raw)
    if length < 1:
        raise ValueError("Content-Length must be greater than zero")
    if length > MAX_BODY_BYTES:
        raise PayloadTooLarge(f"Content-Length exceeds {MAX_BODY_BYTES} bytes")
    return length


def validate_recorder_response(value: object) -> dict[str, Any]:
    """Accept only the recorder's exact integer success status."""
    if not isinstance(value, dict) or type(value.get("status")) is not int:
        raise RuntimeError("recorder returned an invalid response")
    if value["status"] != 0:
        raise RuntimeError("recorder rejected the request")
    return value


def list_recordings(root: Path) -> list[str]:
    """List only direct, non-symlink directories below the configured root."""
    try:
        entries = list(root.iterdir())
    except (FileNotFoundError, NotADirectoryError):
        return []
    result: list[str] = []
    for entry in entries:
        try:
            mode = entry.lstat().st_mode
        except FileNotFoundError:
            continue
        if stat.S_ISDIR(mode):
            result.append(entry.name)
    return sorted(result)


class SerializedRecorder:
    """Serialize start and stop calls around a process-local adapter."""

    def __init__(
        self,
        adapter: Callable[[int, dict[str, str]], dict[str, Any]],
    ) -> None:
        self._adapter = adapter
        self._lock = threading.Lock()

    def control(self, operate: int, meta: dict[str, str]) -> dict[str, Any]:
        if type(operate) is not int or operate not in (0, 1):
            raise ValueError("operate must be exact integer 0 or 1")
        clean_meta = validate_meta(meta)
        with self._lock:
            return validate_recorder_response(self._adapter(operate, clean_meta))


class BridgeApplication:
    """Transport-independent implementation of the three HTTP endpoints."""

    def __init__(
        self,
        token: str,
        recorder: SerializedRecorder,
        recorded_dir: Path,
    ) -> None:
        if not token or token.strip() != token or any(c in token for c in "\r\n"):
            raise ValueError("a non-empty REALBOT_BRIDGE_TOKEN is required")
        self._token = token
        self._recorder = recorder
        self._recorded_dir = Path(recorded_dir)

    def handle(
        self,
        method: str,
        path: str,
        authorization: str | None,
        content_length: str | None,
        body: bytes,
    ) -> tuple[int, dict[str, Any]]:
        if not authorized(authorization, self._token):
            return 401, {"msg": "unauthorized", "status": -1}

        if method == "GET" and path == "/record/list":
            return 200, {
                "msg": "success",
                "status": 0,
                "recordings": list_recordings(self._recorded_dir),
            }
        if method != "POST" or path not in {"/record/start", "/record/stop"}:
            return 404, {"msg": "unknown endpoint", "status": -1}

        try:
            declared = validate_content_length(content_length)
        except LengthRequired:
            return 411, {"msg": "Content-Length is required", "status": -1}
        except PayloadTooLarge:
            return 413, {"msg": "request body exceeds 65536 bytes", "status": -1}
        except ValueError:
            return 400, {"msg": "invalid Content-Length", "status": -1}
        if not isinstance(body, bytes) or len(body) != declared:
            return 400, {"msg": "request body length mismatch", "status": -1}

        try:
            decoded = json.loads(body.decode("utf-8"))
            meta = validate_meta(decoded)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
            return 400, {"msg": "invalid JSON metadata", "status": -1}

        try:
            response = self._recorder.control(
                1 if path == "/record/start" else 0,
                meta,
            )
        except (RuntimeError, ValueError):
            return 502, {"msg": "recorder request failed", "status": -1}
        return 200, response
