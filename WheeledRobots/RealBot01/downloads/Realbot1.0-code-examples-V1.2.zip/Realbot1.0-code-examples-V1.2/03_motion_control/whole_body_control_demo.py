#!/usr/bin/env python3
"""Build a fail-closed whole-body control plan from one live state snapshot.

This customer example never sends a command. It validates the state shape, keeps
every joint at its sampled position, selects at most one chassis velocity topic,
and emits terminal commands only when the target terminal reports ``dof > 0``.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


JOINT_COMPONENTS = {
    "left_arm": ("arm_left", 0, 7),
    "right_arm": ("arm_right", 1, 7),
    "body": ("body", 2, 5),
    "head": ("head", 3, 2),
}
CHASSIS_TOPICS = {
    "teleop_cmd_vel": "/teleop_cmd_vel",
    "cmd_vel": "/cmd_vel",
}


def _integer_vector(value: Any, size: int, label: str) -> list[int]:
    if not isinstance(value, list) or len(value) != size or any(type(item) is not int for item in value):
        raise ValueError(f"{label} must contain exactly {size} integers")
    return list(value)


def validate_joint_component(state: dict[str, Any], key: str, size: int) -> list[int]:
    component = state.get(key)
    if not isinstance(component, dict):
        raise ValueError(f"missing state component: {key}")
    position = _integer_vector(component.get("position"), size, f"{key}.position")
    enabled = _integer_vector(component.get("joint_en"), size, f"{key}.joint_en")
    errors = _integer_vector(component.get("joint_err"), size, f"{key}.joint_err")
    if enabled != [1] * size:
        raise ValueError(f"{key} is not fully enabled")
    if errors != [0] * size or component.get("sys_err") != 0:
        raise ValueError(f"{key} reports an error")
    return position


def validate_terminal(state: dict[str, Any], side: str) -> dict[str, Any]:
    key = f"hand_{side}"
    terminal = state.get(key)
    if not isinstance(terminal, dict):
        raise ValueError(f"missing state component: {key}")
    dof = terminal.get("dof")
    if type(dof) is not int or dof < 0:
        raise ValueError(f"{key}.dof must be a non-negative integer")
    if terminal.get("sys_state") != 0:
        raise ValueError(f"{key} reports an error")
    if dof == 0:
        return {
            "available": False,
            "reason": "runtime dof is 0; no terminal command is generated",
        }
    position = _integer_vector(terminal.get("position"), dof, f"{key}.position")
    low = _integer_vector(terminal.get("pos_low"), dof, f"{key}.pos_low")
    high = _integer_vector(terminal.get("pos_up"), dof, f"{key}.pos_up")
    for index, (current, minimum, maximum) in enumerate(zip(position, low, high), 1):
        if minimum > maximum or not minimum <= current <= maximum:
            raise ValueError(f"{key} channel {index} is outside its reported bounds")
    return {
        "available": True,
        "dof": dof,
        "position": position,
        "pos_low": low,
        "pos_up": high,
    }


def build_joint_wrapper(name: str, device: int, position: list[int]) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "command": "movej",
        "joint": position,
        "v": 1,
        "r": 0,
        "trajectory_connect": 0,
    }
    if name in {"body", "head"}:
        payload["device"] = device
    return {"device": device, "payload": payload}


def build_stop_wrapper(name: str, device: int) -> dict[str, Any]:
    if name in {"left_arm", "right_arm"}:
        return {"device": device, "payload": {"command": "set_arm_stop"}}
    return {
        "device": device,
        "payload": {"command": "set_stop_teach", "device": device, "v": 5, "r": 0},
    }


def build_plan(state: dict[str, Any], chassis_topic: str) -> dict[str, Any]:
    if chassis_topic not in CHASSIS_TOPICS:
        raise ValueError(f"unsupported chassis topic: {chassis_topic}")

    components: dict[str, Any] = {}
    for name, (state_key, device, size) in JOINT_COMPONENTS.items():
        position = validate_joint_component(state, state_key, size)
        components[name] = {
            "state_key": state_key,
            "device": device,
            "hold_current_request": build_joint_wrapper(name, device, position),
            "stop_request": build_stop_wrapper(name, device),
        }

    terminals: dict[str, Any] = {}
    for side, device in (("left", 0), ("right", 1)):
        checked = validate_terminal(state, side)
        entry: dict[str, Any] = {"device": device, **checked}
        if checked["available"]:
            entry["hold_current_request"] = {
                "device": device,
                "payload": {
                    "command": "hand_follow_pos",
                    "hand_pos": checked["position"],
                },
            }
            entry["stop_request"] = {
                "device": device,
                "payload": {"command": "set_rm_plus_ctrl", "mode": 0},
            }
        terminals[side] = entry

    return {
        "schema": "realbot.whole_body_control.plan.v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "plan_only": True,
        "command_service": {
            "name": "/robot/command",
            "type": "rm_robot_interfaces/srv/StringCmd",
        },
        "components": components,
        "terminals": terminals,
        "chassis": {
            "topic": CHASSIS_TOPICS[chassis_topic],
            "type": "geometry_msgs/msg/Twist",
            "rule": "publish continuously; use only this non-zero speed source",
            "stop": "publish zero Twist continuously and confirm /odom is stationary",
        },
        "execution_rules": [
            "sample fresh state and live limits before each motion",
            "one non-zero command owner per component",
            "test one component at a time before coordinated application control",
            "on timeout send one component-specific stop and read fresh state",
            "never auto-clear an error or replay an old target",
        ],
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Validate a live state snapshot and print a plan-only Realbot whole-body control map"
    )
    parser.add_argument("--state-json", type=Path, required=True, help="raw /robot_slave/states JSON file")
    parser.add_argument(
        "--chassis-topic",
        choices=sorted(CHASSIS_TOPICS),
        default="teleop_cmd_vel",
        help="select exactly one chassis velocity input",
    )
    parser.add_argument("--output", type=Path, help="optional output JSON path")
    parser.add_argument(
        "--execute",
        action="store_true",
        help="intentionally unsupported; use the staged examples for authorized motion",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.execute:
        print("REFUSED: this unified example is PLAN-ONLY; use a staged example for live motion", file=sys.stderr)
        return 2
    try:
        state = json.loads(args.state_json.read_text(encoding="utf-8"))
        if not isinstance(state, dict):
            raise ValueError("state JSON root must be an object")
        plan = build_plan(state, args.chassis_topic)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    rendered = json.dumps(plan, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
