#!/usr/bin/env python3
"""Dry-run-first, bounded chassis out-and-back verification."""

from __future__ import annotations

import argparse
import json
import math
import signal
import socket
import subprocess
import time
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class ChassisPlan:
    speed_mps: float = 0.05
    segment_seconds: float = 1.5
    pause_seconds: float = 1.0
    publish_hz: float = 20.0
    soft_stop_displacement_m: float = 0.10
    max_displacement_m: float = 0.12
    min_direction_progress_m: float = 0.001
    max_residual_m: float = 0.03
    state_timeout_seconds: float = 10.0
    odom_stale_seconds: float = 0.25
    stationary_seconds: float = 0.5
    stop_timeout_seconds: float = 2.0
    endpoint_timeout_seconds: float = 3.0


def build_plan() -> ChassisPlan:
    return ChassisPlan()


def validate_result(plan: ChassisPlan, max_displacement_m: float, residual_m: float) -> None:
    if not all(
        math.isfinite(value) and value >= 0
        for value in (max_displacement_m, residual_m)
    ):
        raise RuntimeError("odometry result is invalid")
    if max_displacement_m > plan.max_displacement_m:
        raise RuntimeError(
            f"maximum displacement {max_displacement_m:.4f} m exceeds "
            f"{plan.max_displacement_m:.4f} m"
        )
    if residual_m > plan.max_residual_m:
        raise RuntimeError(
            f"final residual {residual_m:.4f} m exceeds {plan.max_residual_m:.4f} m"
        )


def validate_directional_motion(
    plan: ChassisPlan,
    forward_progress_m: float,
    reverse_progress_m: float,
) -> None:
    values = (float(forward_progress_m), float(reverse_progress_m))
    if not all(math.isfinite(value) for value in values):
        raise RuntimeError("directional odometry result is invalid")
    if forward_progress_m < plan.min_direction_progress_m:
        raise RuntimeError(
            f"forward progress {forward_progress_m:.4f} m is below "
            f"{plan.min_direction_progress_m:.4f} m"
        )
    if reverse_progress_m < plan.min_direction_progress_m:
        raise RuntimeError(
            f"reverse progress {reverse_progress_m:.4f} m is below "
            f"{plan.min_direction_progress_m:.4f} m"
        )


def validate_displacement_guard(plan: ChassisPlan, displacement_m: float) -> None:
    if not math.isfinite(displacement_m) or displacement_m < 0:
        raise RuntimeError("odometry displacement is invalid")
    if displacement_m > plan.max_displacement_m:
        raise RuntimeError(
            f"hard stop displacement {displacement_m:.4f} m exceeds "
            f"{plan.max_displacement_m:.4f} m"
        )
    if displacement_m > plan.soft_stop_displacement_m:
        raise RuntimeError(
            f"soft stop displacement {displacement_m:.4f} m exceeds "
            f"{plan.soft_stop_displacement_m:.4f} m"
        )


def guarded_stop_until_stationary(
    plan: ChassisPlan,
    *,
    spin_once: Any,
    publish_stop: Any,
    read_sample: Any,
    ros_ok: Any,
) -> tuple[float, float, float]:
    """Keep asserting stop while checking every newly received odometry sample."""
    deadline = time.monotonic() + plan.stop_timeout_seconds
    stable_since: float | None = None
    observed_sequence = -1
    max_displacement = 0.0
    minimum_projection = math.inf
    maximum_projection = -math.inf
    try:
        while ros_ok() and time.monotonic() < deadline:
            publish_stop()
            spin_once(0.05)
            now = time.monotonic()
            (
                sequence,
                received_at,
                linear_speed,
                angular_speed,
                displacement,
                projection,
            ) = read_sample()
            validate_odom_freshness(received_at, now, plan.odom_stale_seconds)
            if sequence == observed_sequence:
                continue
            observed_sequence = sequence
            validate_displacement_guard(plan, displacement)
            max_displacement = max(max_displacement, displacement)
            minimum_projection = min(minimum_projection, projection)
            maximum_projection = max(maximum_projection, projection)
            if abs(linear_speed) <= 0.02 and abs(angular_speed) <= 0.05:
                stable_since = stable_since or now
                if now - stable_since >= plan.stationary_seconds:
                    return max_displacement, minimum_projection, maximum_projection
            else:
                stable_since = None
        if not ros_ok():
            raise RuntimeError("ROS context stopped while stopping chassis")
        raise TimeoutError(
            f"chassis did not stop within {plan.stop_timeout_seconds:.1f}s"
        )
    finally:
        # One final assertion is guaranteed even when odometry crosses a boundary.
        publish_stop()


def validate_odom_freshness(
    last_received_at: float | None,
    now: float,
    max_age_seconds: float,
) -> None:
    if last_received_at is None:
        raise TimeoutError("no valid /odom sample")
    age = float(now) - float(last_received_at)
    if (
        not math.isfinite(age)
        or not math.isfinite(max_age_seconds)
        or max_age_seconds <= 0
        or age < 0
        or age > max_age_seconds
    ):
        raise TimeoutError(
            f"stale /odom sample: age={age:.3f}s, limit={max_age_seconds:.3f}s"
        )


def raise_for_termination_signal(signum: int, _frame: Any) -> None:
    """Unwind through execute_plan's finally block instead of exiting abruptly."""
    raise KeyboardInterrupt(f"termination signal {signum}")


def discover_local_ipv4_addresses() -> set[str]:
    result = subprocess.run(
        ["ip", "-j", "-4", "addr", "show"],
        check=True,
        capture_output=True,
        text=True,
        timeout=3.0,
    )
    interfaces = json.loads(result.stdout)
    return {
        str(address["local"])
        for interface in interfaces
        for address in interface.get("addr_info", [])
        if isinstance(address, dict) and address.get("family") == "inet" and address.get("local")
    }


def validate_robot_identity(
    expected_hostname: str,
    expected_robot_ip: str,
    actual_hostname: str,
    local_ipv4_addresses: set[str],
) -> None:
    if (
        not expected_hostname
        or expected_hostname != actual_hostname
        or not expected_robot_ip
        or expected_robot_ip not in local_ipv4_addresses
    ):
        raise RuntimeError(
            "robot identity mismatch: "
            f"expected hostname/IP={expected_hostname!r}/{expected_robot_ip!r}, "
            f"actual hostname/IP={actual_hostname!r}/{sorted(local_ipv4_addresses)!r}"
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Check a 0.05 m/s, 1.5 s chassis out-and-back plan; motion is opt-in"
    )
    parser.add_argument("--execute", action="store_true", help="allow the checked motion")
    parser.add_argument(
        "--confirm-site-clear",
        action="store_true",
        help="confirm clear floor, no drop edge, reachable E-stop, and exclusive control",
    )
    parser.add_argument(
        "--expected-hostname",
        help="exact robot hostname; required for execute to prevent wrong-host operation",
    )
    parser.add_argument(
        "--expected-robot-ip",
        help="exact local robot IPv4 address; required for execute",
    )
    return parser


def validate_execution_gate(args: argparse.Namespace) -> None:
    if args.execute and not args.confirm_site_clear:
        raise ValueError("--execute also requires --confirm-site-clear")
    if args.execute and not args.expected_hostname:
        raise ValueError("--execute also requires --expected-hostname")
    if args.execute and not args.expected_robot_ip:
        raise ValueError("--execute also requires --expected-robot-ip")


def execute_plan(plan: ChassisPlan) -> dict[str, float]:
    import rclpy
    from geometry_msgs.msg import Twist
    from nav_msgs.msg import Odometry
    from rclpy.node import Node
    from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
    from std_msgs.msg import Empty

    qos = QoSProfile(
        history=HistoryPolicy.KEEP_LAST,
        depth=10,
        reliability=ReliabilityPolicy.RELIABLE,
        durability=DurabilityPolicy.VOLATILE,
    )

    class ChassisGuard(Node):
        def __init__(self) -> None:
            super().__init__("realbot_safe_chassis_guard")
            self.velocity_pub = self.create_publisher(Twist, "/cmd_vel", qos)
            self.enable_pub = self.create_publisher(Empty, "/EnableMotor", qos)
            self.stop_pub = self.create_publisher(Empty, "/StopMotor", qos)
            self.last_pose: tuple[float, float, float] | None = None
            self.last_odom_at: float | None = None
            self.odom_sequence = 0
            self.last_speed = (math.inf, math.inf)
            self.create_subscription(Odometry, "/odom", self.on_odom, qos)

        def on_odom(self, message: Any) -> None:
            position = message.pose.pose.position
            orientation = message.pose.pose.orientation
            twist = message.twist.twist
            values = (
                position.x,
                position.y,
                orientation.x,
                orientation.y,
                orientation.z,
                orientation.w,
                twist.linear.x,
                twist.angular.z,
            )
            if all(math.isfinite(float(value)) for value in values):
                yaw = math.atan2(
                    2.0 * (orientation.w * orientation.z + orientation.x * orientation.y),
                    1.0 - 2.0 * (orientation.y * orientation.y + orientation.z * orientation.z),
                )
                self.last_pose = (float(position.x), float(position.y), float(yaw))
                self.last_odom_at = time.monotonic()
                self.odom_sequence += 1
                self.last_speed = (float(twist.linear.x), float(twist.angular.z))

        def publish_velocity(self, linear_x: float) -> None:
            command = Twist()
            command.linear.x = float(linear_x)
            self.velocity_pub.publish(command)

        def publish_zero(self) -> None:
            self.publish_velocity(0.0)

    rclpy.init()
    node = ChassisGuard()
    guarded_signals = [signal.SIGINT, signal.SIGTERM]
    if hasattr(signal, "SIGHUP"):
        guarded_signals.append(signal.SIGHUP)
    previous_signal_handlers = {signum: signal.getsignal(signum) for signum in guarded_signals}
    for signum in previous_signal_handlers:
        signal.signal(signum, raise_for_termination_signal)
    origin: tuple[float, float, float] | None = None
    max_displacement = 0.0
    last_motion_odom_sequence: int | None = None

    def spin_until_odom(timeout_seconds: float) -> None:
        deadline = time.monotonic() + timeout_seconds
        while rclpy.ok() and node.last_pose is None and time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.1)
        if node.last_pose is None:
            raise TimeoutError("no valid /odom sample")

    def wait_for_endpoints() -> None:
        deadline = time.monotonic() + plan.endpoint_timeout_seconds
        publishers = (node.velocity_pub, node.enable_pub, node.stop_pub)
        while rclpy.ok() and time.monotonic() < deadline:
            if all(publisher.get_subscription_count() > 0 for publisher in publishers):
                return
            rclpy.spin_once(node, timeout_sec=0.1)
        raise RuntimeError("required chassis command endpoint is not matched")

    def wait_for_stationary() -> None:
        deadline = time.monotonic() + plan.state_timeout_seconds
        stable_since: float | None = None
        observed_sequence = -1
        while rclpy.ok() and time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.05)
            now = time.monotonic()
            validate_odom_freshness(node.last_odom_at, now, plan.odom_stale_seconds)
            if node.odom_sequence == observed_sequence:
                continue
            observed_sequence = node.odom_sequence
            if abs(node.last_speed[0]) <= 0.02 and abs(node.last_speed[1]) <= 0.05:
                stable_since = stable_since or now
                if now - stable_since >= plan.stationary_seconds:
                    return
            else:
                stable_since = None
        raise TimeoutError("chassis did not remain stationary on fresh /odom samples")

    def update_guard(require_new_sample: bool) -> tuple[float, float]:
        nonlocal max_displacement, last_motion_odom_sequence
        rclpy.spin_once(node, timeout_sec=0.02 if require_new_sample else 0.0)
        if origin is None or node.last_pose is None:
            raise TimeoutError("lost valid /odom state")
        validate_odom_freshness(
            node.last_odom_at,
            time.monotonic(),
            plan.odom_stale_seconds,
        )
        if require_new_sample and node.odom_sequence == last_motion_odom_sequence:
            raise TimeoutError("no new /odom sample before nonzero chassis command")
        if require_new_sample:
            last_motion_odom_sequence = node.odom_sequence
        dx = node.last_pose[0] - origin[0]
        dy = node.last_pose[1] - origin[1]
        displacement = math.hypot(dx, dy)
        projection = dx * math.cos(origin[2]) + dy * math.sin(origin[2])
        max_displacement = max(max_displacement, displacement)
        validate_displacement_guard(plan, displacement)
        return displacement, projection

    def publish_for(linear_x: float, duration_seconds: float) -> tuple[float, float]:
        period = 1.0 / plan.publish_hz
        deadline = time.monotonic() + duration_seconds
        minimum_projection = math.inf
        maximum_projection = -math.inf
        while rclpy.ok() and time.monotonic() < deadline:
            started = time.monotonic()
            _, projection = update_guard(require_new_sample=linear_x != 0.0)
            minimum_projection = min(minimum_projection, projection)
            maximum_projection = max(maximum_projection, projection)
            node.publish_velocity(linear_x)
            remaining = period - (time.monotonic() - started)
            if remaining > 0:
                time.sleep(remaining)
        if not rclpy.ok():
            raise RuntimeError("ROS context stopped during chassis command")
        return minimum_projection, maximum_projection

    def publish_stop_once() -> None:
        node.publish_zero()
        node.stop_pub.publish(Empty())

    def publish_stop() -> None:
        for _ in range(5):
            publish_stop_once()
            rclpy.spin_once(node, timeout_sec=0.05)

    def read_stop_sample() -> tuple[int, float | None, float, float, float, float]:
        if origin is None or node.last_pose is None:
            raise TimeoutError("lost valid /odom state while stopping chassis")
        dx = node.last_pose[0] - origin[0]
        dy = node.last_pose[1] - origin[1]
        displacement = math.hypot(dx, dy)
        projection = dx * math.cos(origin[2]) + dy * math.sin(origin[2])
        return (
            node.odom_sequence,
            node.last_odom_at,
            node.last_speed[0],
            node.last_speed[1],
            displacement,
            projection,
        )

    try:
        spin_until_odom(plan.state_timeout_seconds)
        wait_for_endpoints()
        wait_for_stationary()
        origin = node.last_pose
        for _ in range(3):
            node.enable_pub.publish(Empty())
            rclpy.spin_once(node, timeout_sec=0.05)
        _, forward_peak = publish_for(plan.speed_mps, plan.segment_seconds)
        _, pause_peak = publish_for(0.0, plan.pause_seconds)
        forward_peak = max(forward_peak, pause_peak)
        reverse_minimum, _ = publish_for(-plan.speed_mps, plan.segment_seconds)
        stop_maximum, stop_minimum_projection, _ = guarded_stop_until_stationary(
            plan,
            spin_once=lambda timeout: rclpy.spin_once(node, timeout_sec=timeout),
            publish_stop=publish_stop_once,
            read_sample=read_stop_sample,
            ros_ok=rclpy.ok,
        )
        max_displacement = max(max_displacement, stop_maximum)
        reverse_minimum = min(reverse_minimum, stop_minimum_projection)
        update_guard(require_new_sample=False)
        if node.last_pose is None or origin is None:
            raise TimeoutError("no final /odom state")
        residual = math.hypot(node.last_pose[0] - origin[0], node.last_pose[1] - origin[1])
        reverse_progress = forward_peak - reverse_minimum
        validate_directional_motion(plan, forward_peak, reverse_progress)
        validate_result(plan, max_displacement, residual)
        return {
            "max_displacement_m": max_displacement,
            "forward_progress_m": forward_peak,
            "reverse_progress_m": reverse_progress,
            "residual_m": residual,
        }
    finally:
        # Always publish zero and the dedicated stop event, including timeouts and Ctrl-C.
        try:
            publish_stop()
        finally:
            try:
                for signum, handler in previous_signal_handlers.items():
                    signal.signal(signum, handler)
            finally:
                node.destroy_node()
                if rclpy.ok():
                    rclpy.shutdown()


def main() -> int:
    args = build_parser().parse_args()
    validate_execution_gate(args)
    plan = build_plan()
    print(json.dumps({"mode": "execute" if args.execute else "dry-run", "plan": asdict(plan)}))
    if not args.execute:
        return 0
    validate_robot_identity(
        args.expected_hostname,
        args.expected_robot_ip,
        socket.gethostname(),
        discover_local_ipv4_addresses(),
    )
    result = execute_plan(plan)
    print(json.dumps({"result": "pass", **result}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
