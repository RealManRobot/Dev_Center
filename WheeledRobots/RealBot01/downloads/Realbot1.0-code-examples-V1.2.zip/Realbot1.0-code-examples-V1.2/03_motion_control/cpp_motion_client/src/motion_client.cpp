#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "rm_robot_interfaces/srv/string_cmd.hpp"

constexpr double kMaxDeltaDeg = 3.0;
constexpr double kHeadLimitDeg = 22.0;
constexpr int kSpeedLevel = 1;
constexpr char kServiceName[] = "/robot/command";
using MotionService = rm_robot_interfaces::srv::StringCmd;

struct Options {
  bool execute = false;
  bool confirm_site_clear = false;
  bool have_current = false;
  bool have_delta = false;
  std::array<double, 2> current_deg{};
  std::array<double, 2> delta_deg{};
};

Options parse_options(int argc, char** argv) {
  Options options;
  for (int index = 1; index < argc; ++index) {
    const std::string argument = argv[index];
    if (argument == "--execute") {
      options.execute = true;
    } else if (argument == "--confirm-site-clear") {
      options.confirm_site_clear = true;
    } else if (argument == "--current-deg" && index + 2 < argc) {
      options.current_deg = {std::stod(argv[++index]), std::stod(argv[++index])};
      options.have_current = true;
    } else if (argument == "--delta-deg" && index + 2 < argc) {
      options.delta_deg = {std::stod(argv[++index]), std::stod(argv[++index])};
      options.have_delta = true;
    } else {
      throw std::invalid_argument("unknown or incomplete argument: " + argument);
    }
  }
  if (!options.have_current || !options.have_delta) {
    throw std::invalid_argument("--current-deg J1 J2 and --delta-deg J1 J2 are required");
  }
  if (options.execute && !options.confirm_site_clear) {
    throw std::invalid_argument("--execute also requires --confirm-site-clear");
  }
  return options;
}

std::array<double, 2> checked_target(const Options& options) {
  std::array<double, 2> target{};
  for (std::size_t index = 0; index < target.size(); ++index) {
    if (!std::isfinite(options.current_deg[index]) ||
        !std::isfinite(options.delta_deg[index])) {
      throw std::invalid_argument("current and delta values must be finite");
    }
    if (std::abs(options.delta_deg[index]) > kMaxDeltaDeg) {
      throw std::out_of_range("relative target exceeds 3 degrees");
    }
    target[index] = options.current_deg[index] + options.delta_deg[index];
    if (std::abs(target[index]) > kHeadLimitDeg) {
      throw std::out_of_range("target exceeds verified head driver limit");
    }
  }
  return target;
}

std::string request_json(const std::array<double, 2>& target_deg) {
  const auto first = static_cast<long>(std::lround(target_deg[0] * 1000.0));
  const auto second = static_cast<long>(std::lround(target_deg[1] * 1000.0));
  std::ostringstream output;
  output << "{\"device\":3,\"payload\":{\"command\":\"movej\","
         << "\"joint\":[" << first << ',' << second << "],"
         << "\"v\":" << kSpeedLevel
         << ",\"r\":0,\"trajectory_connect\":0,\"device\":3}}";
  return output.str();
}

int main(int argc, char** argv) {
  try {
    const Options options = parse_options(argc, argv);
    if (options.execute) {
      static_cast<void>(sizeof(MotionService));
      throw std::runtime_error(
          "live C++ execution is disabled in V1.0: this example has no trusted live "
          "state readback, stop, and recovery loop; use safe_control.py after explicit authorization");
    }
    const auto target = checked_target(options);
    std::cout << "PLAN-ONLY" << std::fixed << std::setprecision(3)
              << " current=[" << options.current_deg[0] << ',' << options.current_deg[1]
              << "] target=[" << target[0] << ',' << target[1]
              << "] speed=" << kSpeedLevel << '\n'
              << "service=" << kServiceName << '\n'
              << "request=" << request_json(target) << '\n';
    return 0;
  } catch (const std::exception& error) {
    std::cerr << "ERROR: " << error.what() << '\n';
    return 2;
  }
}
