#!/usr/bin/env python3
"""Dry-run-first Realbot1.0 head/body control over /robot/command.

The head path permits a bounded relative move followed by recovery.  The body
path deliberately permits only a current-position hold probe.  Live execution
requires a fresh control-authority preflight report and explicit site/exclusive
control confirmations.  The program never clears errors or changes limits.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence


HEAD_DEVICE = 3
BODY_DEVICE = 2
HEAD_DOF = 2
BODY_DOF = 5
HEAD_MAX_RELATIVE_DEG = 3.0
SPEED_LEVEL = 1
STOP_DECEL_LEVEL = 5
POSITION_TOLERANCE_DEG = 0.05
STABILITY_DELTA_DEG = 0.02
STABILITY_SAMPLES = 2
STATE_TIMEOUT_SECONDS = 10.0
SERVICE_TIMEOUT_SECONDS = 3.0
AUTHORITY_REPORT_MAX_AGE_SECONDS = 120.0


@dataclass(frozen=True)
class ComponentSnapshot:
    component: str
    position_deg: tuple[float, ...]
    joint_error: tuple[int, ...]
    joint_enable: tuple[int, ...]
    system_error: int

    @property
    def healthy(self) -> bool:
        return (
            self.system_error == 0
            and all(error == 0 for error in self.joint_error)
            and bool(self.joint_enable)
            and all(enabled == 1 for enabled in self.joint_enable)
        )


@dataclass(frozen=True)
class MotionPlan:
    component: str
    device: int
    original_deg: tuple[float, ...]
    target_deg: tuple[float, ...]
    recovery_deg: tuple[float, ...]
    speed_level: int
    mode: str


def _finite_tuple(values: Sequence[float], expected: int, name: str) -> tuple[float, ...]:
    if len(values) != expected:
        raise ValueError(f"{name} must contain exactly {expected} values")
    result = tuple(float(value) for value in values)
    if not all(math.isfinite(value) for value in result):
        raise ValueError(f"{name} values must be finite")
    return result


def build_head_plan(current_deg: Sequence[float], delta_deg: Sequence[float]) -> MotionPlan:
    current = _finite_tuple(current_deg, HEAD_DOF, "head current")
    delta = _finite_tuple(delta_deg, HEAD_DOF, "head delta")
    if any(abs(value) > HEAD_MAX_RELATIVE_DEG for value in delta):
        raise ValueError(
            f"each relative head target must be within {HEAD_MAX_RELATIVE_DEG:.1f} degrees"
        )
    target = tuple(current_value + delta_value for current_value, delta_value in zip(current, delta))
    return MotionPlan("head", HEAD_DEVICE, current, target, current, SPEED_LEVEL, "relative_move")


def build_body_hold_plan(current_deg: Sequence[float]) -> MotionPlan:
    current = _finite_tuple(current_deg, BODY_DOF, "body current")
    return MotionPlan("body", BODY_DEVICE, current, current, current, SPEED_LEVEL, "hold_current")


def build_movej_wrapper(plan: MotionPlan, target_deg: Sequence[float]) -> dict[str, Any]:
    target = _finite_tuple(target_deg, len(plan.original_deg), f"{plan.component} target")
    joint = [int(round(value * 1000.0)) for value in target]
    payload = {
        "command": "movej",
        "joint": joint,
        "v": plan.speed_level,
        "r": 0,
        "trajectory_connect": 0,
        "device": plan.device,
    }
    return {"device": plan.device, "payload": payload}


def build_stop_wrapper(device: int) -> dict[str, Any]:
    if device not in (BODY_DEVICE, HEAD_DEVICE):
        raise ValueError("stop device must be 2 (body) or 3 (head)")
    return {
        "device": device,
        "payload": {
            "command": "set_stop_teach",
            "device": device,
            "v": STOP_DECEL_LEVEL,
            "r": 0,
        },
    }


def build_limit_wrapper(device: int, command: str) -> dict[str, Any]:
    if device not in (BODY_DEVICE, HEAD_DEVICE):
        raise ValueError("limit device must be 2 (body) or 3 (head)")
    if command not in ("get_joint_drive_min_pos", "get_joint_drive_max_pos"):
        raise ValueError("unsupported read-only limit command")
    return {"device": device, "payload": {"command": command, "device": device}}


def decode_component_snapshot(data: str, component: str) -> ComponentSnapshot:
    expected = HEAD_DOF if component == "head" else BODY_DOF if component == "body" else 0
    if expected == 0:
        raise ValueError("component must be head or body")
    parsed = json.loads(data)
    section = parsed.get(component) if isinstance(parsed, dict) else None
    if not isinstance(section, dict):
        raise ValueError(f"{component} state section is missing")
    position = section.get("position")
    joint_error = section.get("joint_err")
    joint_enable = section.get("joint_en")
    system_error = section.get("sys_err")
    if (
        not isinstance(position, list)
        or len(position) != expected
        or any(type(value) not in (int, float) for value in position)
    ):
        raise ValueError(f"{component} position must contain {expected} numeric values")
    if (
        not isinstance(joint_error, list)
        or len(joint_error) != expected
        or any(type(value) is not int for value in joint_error)
        or not isinstance(joint_enable, list)
        or len(joint_enable) != expected
        or any(type(value) is not int for value in joint_enable)
        or type(system_error) is not int
    ):
        raise ValueError(f"{component} error/enable fields have invalid types or lengths")
    position_deg = tuple(float(value) / 1000.0 for value in position)
    if not all(math.isfinite(value) for value in position_deg):
        raise ValueError(f"{component} position must be finite")
    return ComponentSnapshot(
        component,
        position_deg,
        tuple(joint_error),
        tuple(joint_enable),
        system_error,
    )


def validate_live_limits(target_deg: Sequence[float], minimum_deg: Sequence[float], maximum_deg: Sequence[float]) -> None:
    if not (len(target_deg) == len(minimum_deg) == len(maximum_deg)):
        raise ValueError("target and live limit lengths differ")
    for index, (target, minimum, maximum) in enumerate(zip(target_deg, minimum_deg, maximum_deg), start=1):
        if not (math.isfinite(target) and math.isfinite(minimum) and math.isfinite(maximum)):
            raise ValueError("target and live limits must be finite")
        if minimum > maximum or not minimum <= target <= maximum:
            raise ValueError(
                f"joint {index} target {target:.3f} deg is outside live limits "
                f"[{minimum:.3f}, {maximum:.3f}] deg"
            )


def validate_plan_origin(snapshot: ComponentSnapshot, plan: MotionPlan) -> None:
    if snapshot.component != plan.component or not snapshot.healthy:
        raise RuntimeError(
            f"{plan.component} is not healthy before execute: "
            f"sys_err={snapshot.system_error}, joint_err={snapshot.joint_error}, "
            f"joint_en={snapshot.joint_enable}"
        )
    if any(
        abs(actual - planned) > POSITION_TOLERANCE_DEG
        for actual, planned in zip(snapshot.position_deg, plan.original_deg)
    ):
        raise RuntimeError(
            f"{plan.component} position changed after planning: "
            f"planned={plan.original_deg}, current={snapshot.position_deg}"
        )


def validate_authority_report(path: Path, now: datetime | None = None) -> dict[str, Any]:
    report = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(report, dict) or report.get("motion_ready") is not True:
        raise ValueError("control-authority report does not contain motion_ready=true")
    generated = report.get("evidence", {}).get("generated_at_utc")
    if not isinstance(generated, str):
        raise ValueError("control-authority report has no generation timestamp")
    generated_at = datetime.fromisoformat(generated.replace("Z", "+00:00"))
    if generated_at.tzinfo is None:
        raise ValueError("control-authority timestamp must include a timezone")
    current = now or datetime.now(timezone.utc)
    age = (current.astimezone(timezone.utc) - generated_at.astimezone(timezone.utc)).total_seconds()
    if age < -5.0 or age > AUTHORITY_REPORT_MAX_AGE_SECONDS:
        raise ValueError(
            f"control-authority report age {age:.1f}s is outside 0-"
            f"{AUTHORITY_REPORT_MAX_AGE_SECONDS:.0f}s"
        )
    return report


def validate_service_response(text: str) -> dict[str, Any]:
    try:
        response = json.loads(text)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"controller response is not JSON: {text!r}") from exc
    if not isinstance(response, dict):
        raise RuntimeError(f"controller response is not an object: {response!r}")
    if response.get("state") is False or response.get("command") is False:
        raise RuntimeError(f"controller rejected or did not acknowledge command: {response!r}")
    return response


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Plan or execute bounded head/body commands through /robot/command"
    )
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--head-delta-deg", nargs=2, type=float, metavar=("J1", "J2"))
    mode.add_argument("--body-hold-current", action="store_true")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--confirm-site-clear", action="store_true")
    parser.add_argument("--confirm-exclusive-control", action="store_true")
    parser.add_argument("--confirm-body-hold-only", action="store_true")
    parser.add_argument("--authority-report", type=Path)
    parser.add_argument("--json-output", type=Path)
    return parser


def validate_execution_gate(args: argparse.Namespace) -> None:
    if not args.execute:
        return
    if not args.confirm_site_clear:
        raise ValueError("--execute also requires --confirm-site-clear")
    if not args.confirm_exclusive_control:
        raise ValueError("--execute also requires --confirm-exclusive-control")
    if args.authority_report is None:
        raise ValueError("--execute also requires --authority-report")
    validate_authority_report(args.authority_report)
    if args.body_hold_current and not args.confirm_body_hold_only:
        raise ValueError("body execution also requires --confirm-body-hold-only")


class RosHeadBodyClient:
    def __init__(self) -> None:
        import rclpy
        from rclpy.node import Node
        from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
        from rm_robot_interfaces.srv import StringCmd
        from std_msgs.msg import String

        self._rclpy = rclpy
        self._string_cmd = StringCmd
        rclpy.init()
        self.node = Node("realbot_safe_head_body_control")
        qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
        )
        self._latest_state: str | None = None
        self.node.create_subscription(String, "/robot_slave/states", self._on_state, qos)
        self.client = self.node.create_client(StringCmd, "/robot/command")
        if not self.client.wait_for_service(timeout_sec=5.0):
            self.close()
            raise RuntimeError("/robot/command is not available within 5 seconds")

    def _on_state(self, message: Any) -> None:
        self._latest_state = message.data

    def read_state(self, component: str, timeout_seconds: float = STATE_TIMEOUT_SECONDS) -> ComponentSnapshot:
        self._latest_state = None
        deadline = time.monotonic() + timeout_seconds
        while self._rclpy.ok() and time.monotonic() < deadline:
            self._rclpy.spin_once(self.node, timeout_sec=0.2)
            if self._latest_state is not None:
                return decode_component_snapshot(self._latest_state, component)
        raise TimeoutError(f"no valid {component} state within {timeout_seconds:.1f} seconds")

    def call(self, wrapper: dict[str, Any], timeout_seconds: float = SERVICE_TIMEOUT_SECONDS) -> dict[str, Any]:
        request = self._string_cmd.Request()
        request.data = json.dumps(wrapper, separators=(",", ":"))
        future = self.client.call_async(request)
        self._rclpy.spin_until_future_complete(self.node, future, timeout_sec=timeout_seconds)
        if not future.done() or future.result() is None:
            raise TimeoutError(f"/robot/command did not respond within {timeout_seconds:.1f} seconds")
        return validate_service_response(future.result().data)

    def read_drive_limits(self, plan: MotionPlan) -> tuple[tuple[float, ...], tuple[float, ...]]:
        minimum_response = self.call(build_limit_wrapper(plan.device, "get_joint_drive_min_pos"))
        maximum_response = self.call(build_limit_wrapper(plan.device, "get_joint_drive_max_pos"))
        minimum = minimum_response.get("min_pos")
        maximum = maximum_response.get("max_pos")
        expected = len(plan.original_deg)
        if (
            not isinstance(minimum, list)
            or not isinstance(maximum, list)
            or len(minimum) != expected
            or len(maximum) != expected
            or any(type(value) not in (int, float) for value in (*minimum, *maximum))
        ):
            raise RuntimeError("drive limit response has invalid fields or lengths")
        return (
            tuple(float(value) / 1000.0 for value in minimum),
            tuple(float(value) / 1000.0 for value in maximum),
        )

    def close(self) -> None:
        if hasattr(self, "node"):
            self.node.destroy_node()
        if hasattr(self, "_rclpy") and self._rclpy.ok():
            self._rclpy.shutdown()


def wait_for_target(
    client: RosHeadBodyClient,
    plan: MotionPlan,
    target_deg: Sequence[float],
    timeout_seconds: float = STATE_TIMEOUT_SECONDS,
) -> ComponentSnapshot:
    deadline = time.monotonic() + timeout_seconds
    previous: ComponentSnapshot | None = None
    stable_count = 0
    last: ComponentSnapshot | None = None
    while time.monotonic() < deadline:
        snapshot = client.read_state(plan.component, min(2.0, deadline - time.monotonic()))
        if not snapshot.healthy:
            raise RuntimeError(
                f"{plan.component} error during motion: sys_err={snapshot.system_error}, "
                f"joint_err={snapshot.joint_error}, joint_en={snapshot.joint_enable}"
            )
        in_tolerance = all(
            abs(actual - target) <= POSITION_TOLERANCE_DEG
            for actual, target in zip(snapshot.position_deg, target_deg)
        )
        stable = previous is not None and all(
            abs(actual - prior) <= STABILITY_DELTA_DEG
            for actual, prior in zip(snapshot.position_deg, previous.position_deg)
        )
        stable_count = stable_count + 1 if in_tolerance and stable else (1 if in_tolerance else 0)
        previous = snapshot
        last = snapshot
        if stable_count >= STABILITY_SAMPLES:
            return snapshot
    raise TimeoutError(f"{plan.component} did not reach {tuple(target_deg)}; last={last}")


def execute_plan(client: RosHeadBodyClient, plan: MotionPlan) -> dict[str, Any]:
    stop_attempted = False
    stop_acknowledged = False

    def stop_once() -> dict[str, Any] | None:
        nonlocal stop_attempted, stop_acknowledged
        if stop_attempted:
            return None
        stop_attempted = True
        response = client.call(build_stop_wrapper(plan.device))
        stop_acknowledged = True
        return response

    try:
        validate_plan_origin(client.read_state(plan.component), plan)
        move_response = client.call(build_movej_wrapper(plan, plan.target_deg))
        reached = wait_for_target(client, plan, plan.target_deg)
        recovery_response: dict[str, Any] | None = None
        recovered = reached
        if plan.target_deg != plan.recovery_deg:
            recovery_response = client.call(build_movej_wrapper(plan, plan.recovery_deg))
            recovered = wait_for_target(client, plan, plan.recovery_deg)
        stop_response = stop_once()
        final = wait_for_target(client, plan, plan.recovery_deg)
        return {
            "status": "PASS",
            "move_response": move_response,
            "recovery_response": recovery_response,
            "stop_response": stop_response,
            "reached_deg": reached.position_deg,
            "recovered_deg": recovered.position_deg,
            "final_deg": final.position_deg,
            "stop_count": 1,
            "clear_error_count": 0,
        }
    except BaseException:
        if stop_attempted and not stop_acknowledged:
            print(
                "CRITICAL: software stop was attempted but not acknowledged; "
                "activate the physical E-stop immediately",
                file=sys.stderr,
            )
        else:
            try:
                stop_once()
            except Exception as stop_error:
                print(
                    "CRITICAL: software stop failed; activate the physical E-stop immediately; "
                    f"stop error={stop_error}",
                    file=sys.stderr,
                )
        raise


def main() -> int:
    args = build_parser().parse_args()
    validate_execution_gate(args)
    component = "body" if args.body_hold_current else "head"
    client = RosHeadBodyClient()
    try:
        initial = client.read_state(component)
        if not initial.healthy:
            raise RuntimeError(
                f"{component} is not healthy: sys_err={initial.system_error}, "
                f"joint_err={initial.joint_error}, joint_en={initial.joint_enable}"
            )
        plan = (
            build_body_hold_plan(initial.position_deg)
            if component == "body"
            else build_head_plan(initial.position_deg, args.head_delta_deg)
        )
        minimum, maximum = client.read_drive_limits(plan)
        validate_live_limits(plan.target_deg, minimum, maximum)
        validate_live_limits(plan.recovery_deg, minimum, maximum)
        report: dict[str, Any] = {
            "status": "PLANNED" if not args.execute else "RUNNING",
            "transport": "ros2_service",
            "service": "/robot/command",
            "state_topic": "/robot_slave/states",
            "plan": asdict(plan),
            "live_limits_deg": {"minimum": minimum, "maximum": maximum},
            "safety": {
                "authority_report_required": True,
                "auto_clear_errors": False,
                "body_motion_mode": "hold_current_only",
            },
        }
        if args.execute:
            report["execution"] = execute_plan(client, plan)
            report["status"] = "PASS"
        output = json.dumps(report, ensure_ascii=False, indent=2)
        print(output)
        if args.json_output:
            args.json_output.parent.mkdir(parents=True, exist_ok=True)
            with args.json_output.open("x", encoding="utf-8") as stream:
                stream.write(output + "\n")
            args.json_output.chmod(0o600)
        return 0
    finally:
        client.close()


if __name__ == "__main__":
    raise SystemExit(main())
