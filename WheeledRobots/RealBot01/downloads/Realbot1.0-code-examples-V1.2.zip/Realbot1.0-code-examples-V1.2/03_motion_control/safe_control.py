#!/usr/bin/env python3
"""Dry-run-first head control using the verified REST moveJ path."""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
import urllib.request
from dataclasses import dataclass
from typing import Any, Sequence


MAX_RELATIVE_DEG = 3.0
HEAD_DRIVER_LIMIT_DEG = 22.0
SPEED_LEVEL = 1
STATE_TIMEOUT_SECONDS = 10.0
HTTP_TIMEOUT_SECONDS = 3.0
RECOVERY_TOLERANCE_DEG = 0.05
STABILITY_DELTA_DEG = 0.02
STABILITY_SAMPLES = 2


@dataclass(frozen=True)
class HeadPlan:
    original_deg: tuple[float, float]
    target_deg: tuple[float, float]
    recovery_deg: tuple[float, float]
    speed_level: int
    max_error_deg: float


@dataclass(frozen=True)
class HeadSnapshot:
    position_deg: tuple[float, float]
    joint_error: tuple[int, ...]
    system_error: int

    @property
    def healthy(self) -> bool:
        return self.system_error == 0 and all(error == 0 for error in self.joint_error)


def build_head_plan(current_deg: Sequence[float], delta_deg: Sequence[float]) -> HeadPlan:
    if len(current_deg) != 2 or len(delta_deg) != 2:
        raise ValueError("head current and delta must each contain two values")
    current = (float(current_deg[0]), float(current_deg[1]))
    delta = (float(delta_deg[0]), float(delta_deg[1]))
    if not all(math.isfinite(value) for value in (*current, *delta)):
        raise ValueError("head current and delta values must be finite")
    if any(abs(value) > MAX_RELATIVE_DEG for value in delta):
        raise ValueError(f"each relative head target must be within {MAX_RELATIVE_DEG:.1f} degrees")
    target = (current[0] + delta[0], current[1] + delta[1])
    if any(abs(value) > HEAD_DRIVER_LIMIT_DEG for value in target):
        raise ValueError(f"head target exceeds verified driver limit +/-{HEAD_DRIVER_LIMIT_DEG:.1f} degrees")
    return HeadPlan(current, target, current, SPEED_LEVEL, RECOVERY_TOLERANCE_DEG)


def verify_recovery(actual: HeadSnapshot, plan: HeadPlan) -> bool:
    return actual.healthy and all(
        abs(float(actual) - expected) <= plan.max_error_deg
        for actual, expected in zip(actual.position_deg, plan.recovery_deg)
    )


def validate_plan_current(actual: HeadSnapshot, plan: HeadPlan) -> None:
    if not actual.healthy:
        raise RuntimeError(
            f"head is not healthy before execute: sys_err={actual.system_error}, "
            f"joint_err={actual.joint_error}"
        )
    if any(
        abs(value - expected) > RECOVERY_TOLERANCE_DEG
        for value, expected in zip(actual.position_deg, plan.original_deg)
    ):
        raise RuntimeError(
            f"head position changed after planning: planned={plan.original_deg}, "
            f"current={actual.position_deg}"
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Check a <=3 degree head move; actual motion is opt-in"
    )
    parser.add_argument("--robot-ip", default=os.environ.get("ROBOT_IP"))
    parser.add_argument("--head-delta-deg", type=float, nargs=2, required=True, metavar=("J1", "J2"))
    parser.add_argument("--execute", action="store_true", help="allow the checked motion")
    parser.add_argument(
        "--confirm-site-clear",
        action="store_true",
        help="confirm clear site, reachable E-stop, correct mode, and exclusive control",
    )
    return parser


def validate_execution_gate(args: argparse.Namespace) -> None:
    if args.execute and not args.confirm_site_clear:
        raise ValueError("--execute also requires --confirm-site-clear")


def _post_json(robot_ip: str, endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
    request = urllib.request.Request(
        f"http://{robot_ip}:9091/{endpoint}",
        data=json.dumps(payload, separators=(",", ":")).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=HTTP_TIMEOUT_SECONDS) as response:
        result = json.loads(response.read().decode("utf-8"))
    return validate_rest_response(result)


def validate_rest_response(result: Any) -> dict[str, Any]:
    if not isinstance(result, dict) or type(result.get("code")) is not int or result["code"] != 200:
        raise RuntimeError(f"REST request failed: {result!r}")
    return result


def _data_object(response: dict[str, Any]) -> dict[str, Any]:
    data = response.get("data")
    if isinstance(data, str):
        data = json.loads(data)
    if not isinstance(data, dict):
        raise RuntimeError("REST response data is not an object")
    return data


def read_head_limits(robot_ip: str) -> tuple[tuple[float, float], tuple[float, float]]:
    data = _data_object(_post_json(robot_ip, "joints/getJointLimit", {"device": 3}))
    maximum = (
        data.get("driver_max")
        or data.get("max_pos")
        or data.get("drive_max")
        or data.get("max")
    )
    minimum = (
        data.get("driver_min")
        or data.get("min_pos")
        or data.get("drive_min")
        or data.get("min")
    )
    if not isinstance(maximum, list) or not isinstance(minimum, list) or len(maximum) < 2 or len(minimum) < 2:
        raise RuntimeError("head limit response fields are not recognized; stop without motion")
    return (float(minimum[0]), float(minimum[1])), (float(maximum[0]), float(maximum[1]))


def decode_head_snapshot(data: str) -> HeadSnapshot:
    parsed = json.loads(data)
    if not isinstance(parsed, dict) or not isinstance(parsed.get("head"), dict):
        raise ValueError("head state section is missing")
    head = parsed["head"]
    position = head.get("position")
    joint_error = head.get("joint_err")
    system_error = head.get("sys_err")
    if not isinstance(position, list) or len(position) != 2:
        raise ValueError("head position must contain exactly two values")
    if any(type(value) not in (int, float) for value in position):
        raise ValueError("head position must contain numeric values")
    if (
        not isinstance(joint_error, list)
        or len(joint_error) != 2
        or any(type(error) is not int for error in joint_error)
        or type(system_error) is not int
    ):
        raise ValueError("head error fields must contain two integer joint errors and one integer system error")
    try:
        position_deg = (float(position[0]) / 1000.0, float(position[1]) / 1000.0)
    except (TypeError, ValueError) as exc:
        raise ValueError("head state contains invalid numeric fields") from exc
    if not all(math.isfinite(value) for value in position_deg):
        raise ValueError("head position must be finite")
    return HeadSnapshot(position_deg, tuple(joint_error), system_error)


def read_head_state(timeout_seconds: float = STATE_TIMEOUT_SECONDS) -> HeadSnapshot:
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
    from std_msgs.msg import String

    qos = QoSProfile(
        history=HistoryPolicy.KEEP_LAST,
        depth=10,
        reliability=ReliabilityPolicy.BEST_EFFORT,
        durability=DurabilityPolicy.VOLATILE,
    )

    class HeadStateReader(Node):
        def __init__(self) -> None:
            super().__init__("realbot_safe_control_state")
            self.snapshot: HeadSnapshot | None = None
            self.create_subscription(String, "/robot_slave/states", self.on_state, qos)

        def on_state(self, message: Any) -> None:
            try:
                self.snapshot = decode_head_snapshot(message.data)
            except (TypeError, ValueError, json.JSONDecodeError):
                return

    rclpy.init()
    node = HeadStateReader()
    deadline = time.monotonic() + timeout_seconds
    try:
        while rclpy.ok() and time.monotonic() < deadline and node.snapshot is None:
            rclpy.spin_once(node, timeout_sec=0.2)
        if node.snapshot is None:
            raise TimeoutError(f"no valid head state within {timeout_seconds:.1f} seconds")
        return node.snapshot
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


def validate_live_limits(
    target_deg: Sequence[float], limits: tuple[tuple[float, float], tuple[float, float]]
) -> None:
    minimum, maximum = limits
    if any(not low <= value <= high for value, low, high in zip(target_deg, minimum, maximum)):
        raise ValueError(f"target {tuple(target_deg)} exceeds live head limits {limits}")


def send_head_target(robot_ip: str, target_deg: Sequence[float]) -> None:
    joint_millideg = [int(round(value * 1000.0)) for value in target_deg]
    _post_json(
        robot_ip,
        "move/moveJ",
        {"device": 3, "joint": joint_millideg, "v": SPEED_LEVEL},
    )


def stop_head(robot_ip: str) -> None:
    _post_json(robot_ip, "move/setArmStop", {"device": 3})


def wait_for_head(target_deg: Sequence[float], timeout_seconds: float = STATE_TIMEOUT_SECONDS) -> HeadSnapshot:
    deadline = time.monotonic() + timeout_seconds
    last: HeadSnapshot | None = None
    stable_samples = 0
    while time.monotonic() < deadline:
        current = read_head_state(min(2.0, max(0.2, deadline - time.monotonic())))
        if not current.healthy:
            raise RuntimeError(
                f"head error state: sys_err={current.system_error}, joint_err={current.joint_error}"
            )
        in_tolerance = all(
            abs(actual - target) <= RECOVERY_TOLERANCE_DEG
            for actual, target in zip(current.position_deg, target_deg)
        )
        stable = last is not None and all(
            abs(actual - previous) <= STABILITY_DELTA_DEG
            for actual, previous in zip(current.position_deg, last.position_deg)
        )
        stable_samples = stable_samples + 1 if in_tolerance and stable else (1 if in_tolerance else 0)
        last = current
        if stable_samples >= STABILITY_SAMPLES:
            return current
    raise TimeoutError(f"head did not reach {tuple(target_deg)}; last={last}")


def read_stable_head_after_stop() -> HeadSnapshot:
    first = read_head_state()
    second = read_head_state()
    for snapshot in (first, second):
        if not snapshot.healthy:
            raise RuntimeError(
                f"post-stop head error: sys_err={snapshot.system_error}, "
                f"joint_err={snapshot.joint_error}"
            )
    if any(
        abs(current - previous) > STABILITY_DELTA_DEG
        for current, previous in zip(second.position_deg, first.position_deg)
    ):
        raise RuntimeError(
            f"head is still moving after stop: first={first.position_deg}, "
            f"second={second.position_deg}"
        )
    return second


def _best_effort_stop(robot_ip: str) -> bool:
    try:
        stop_head(robot_ip)
        return True
    except Exception as error:
        # Preserve the triggering exception while making stop failure visible.
        print(
            "CRITICAL: software stop failed; activate the physical E-stop immediately; "
            f"stop error={error}",
            file=sys.stderr,
        )
        return False


def _recover_head(robot_ip: str, plan: HeadPlan) -> None:
    send_head_target(robot_ip, plan.recovery_deg)
    recovered = wait_for_head(plan.recovery_deg)
    if not verify_recovery(recovered, plan):
        raise RuntimeError(f"head recovery error exceeds {plan.max_error_deg} degrees")


def execute_head_plan(robot_ip: str, plan: HeadPlan) -> None:
    try:
        send_head_target(robot_ip, plan.target_deg)
        wait_for_head(plan.target_deg)
    except BaseException:
        # A transport timeout does not prove the controller rejected the move.
        # Never issue another move unless stop succeeded and a fresh healthy
        # state was read back after that stop.
        if not _best_effort_stop(robot_ip):
            raise
        try:
            read_stable_head_after_stop()
            _recover_head(robot_ip, plan)
        except BaseException as recovery_error:
            _best_effort_stop(robot_ip)
            print(
                "CRITICAL: head recovery was not completed after stop/readback; "
                f"keep the area clear and inspect state; recovery error={recovery_error}",
                file=sys.stderr,
            )
        raise

    try:
        _recover_head(robot_ip, plan)
    except BaseException:
        _best_effort_stop(robot_ip)
        raise


def main() -> int:
    args = build_parser().parse_args()
    validate_execution_gate(args)
    if not args.robot_ip:
        raise ValueError("set ROBOT_IP or pass --robot-ip")

    current = read_head_state()
    if not current.healthy:
        raise RuntimeError(
            f"head is not healthy: sys_err={current.system_error}, joint_err={current.joint_error}"
        )
    limits = read_head_limits(args.robot_ip)
    plan = build_head_plan(current.position_deg, args.head_delta_deg)
    validate_live_limits(plan.target_deg, limits)
    validate_live_limits(plan.recovery_deg, limits)
    print(json.dumps({"mode": "execute" if args.execute else "dry-run", "plan": plan.__dict__}, ensure_ascii=False))
    if not args.execute:
        return 0

    validate_plan_current(read_head_state(), plan)
    execute_head_plan(args.robot_ip, plan)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
