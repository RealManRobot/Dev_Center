#!/usr/bin/env python3
"""Fail-closed staged control for a right arm, body, or configured terminal.

The script is a dry-run-first customer example.  It defaults to live-state dry-run,
never clears errors, sends at most one stop, returns to the exact sampled origin,
and requires a fresh ``MOTION_READY=true`` authority report for execution.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence


AUTHORITY_MAX_AGE_SECONDS = 120.0
POSITION_TOLERANCE_RAW = 100  # 0.100 degree
STABILITY_TOLERANCE_RAW = 20  # 0.020 degree/sample
TERMINAL_TOLERANCE_RAW = 10


@dataclass(frozen=True)
class JointPlan:
    stage: str
    state_key: str
    device: int
    origin_raw: tuple[int, ...]
    target_raw: tuple[int, ...]
    max_delta_raw: int


def validate_authority_report(path: Path, now: datetime | None = None) -> dict[str, Any]:
    report = json.loads(path.read_text(encoding="utf-8"))
    if report.get("motion_ready") is not True:
        raise ValueError("authority report must contain motion_ready=true")
    stamp = report.get("evidence", {}).get("generated_at_utc")
    if not isinstance(stamp, str):
        raise ValueError("authority report is missing evidence.generated_at_utc")
    generated = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
    current = now or datetime.now(timezone.utc)
    age = (current - generated.astimezone(timezone.utc)).total_seconds()
    if not 0 <= age <= AUTHORITY_MAX_AGE_SECONDS:
        raise ValueError(f"authority report age {age:.1f}s exceeds gate")
    return report


def validate_component(state: dict[str, Any], key: str, expected_joints: int) -> tuple[int, ...]:
    component = state.get(key)
    if not isinstance(component, dict):
        raise RuntimeError(f"state component {key!r} is missing")
    position = component.get("position")
    if (
        not isinstance(position, list)
        or len(position) != expected_joints
        or any(type(value) is not int for value in position)
    ):
        raise RuntimeError(f"{key} position must contain {expected_joints} integers")
    if component.get("sys_err") != 0:
        raise RuntimeError(f"{key} sys_err is not zero: {component.get('sys_err')!r}")
    if component.get("joint_err") != [0] * expected_joints:
        raise RuntimeError(f"{key} joint_err is not clear: {component.get('joint_err')!r}")
    if component.get("joint_en") != [1] * expected_joints:
        raise RuntimeError(f"{key} is not fully enabled: {component.get('joint_en')!r}")
    return tuple(position)


def validate_common_state(state: dict[str, Any]) -> None:
    chassis = state.get("chassis")
    try:
        linear = float(chassis["linear"]["x"])
        angular = float(chassis["angular"]["z"])
        aloha = int(state["system"]["aloha"]["state"])
    except (KeyError, TypeError, ValueError) as exc:
        raise RuntimeError("chassis or teleoperation state is missing") from exc
    if abs(linear) > 1e-4 or abs(angular) > 1e-4:
        raise RuntimeError(f"chassis is moving: linear={linear}, angular={angular}")
    if aloha != 0:
        raise RuntimeError(f"teleoperation is not idle: aloha.state={aloha}")


def build_joint_plan(
    stage: str,
    origin_raw: Sequence[int],
    joint_index: int,
    delta_deg: float,
) -> JointPlan:
    specs = {
        "right_arm": ("arm_right", 1, 7, 500),
        "body": ("body", 2, 5, 200),
    }
    if stage not in specs:
        raise ValueError("stage must be right_arm or body")
    key, device, expected, max_delta_raw = specs[stage]
    if len(origin_raw) != expected or any(type(value) is not int for value in origin_raw):
        raise ValueError(f"{stage} origin must contain {expected} integers")
    if not 1 <= joint_index <= expected:
        raise ValueError(f"joint index must be 1-{expected}")
    if not math.isfinite(delta_deg):
        raise ValueError("delta must be finite")
    delta_raw = int(round(delta_deg * 1000.0))
    if delta_raw == 0 or abs(delta_raw) > max_delta_raw:
        raise ValueError(f"{stage} delta must be non-zero and <= {max_delta_raw / 1000:g} deg")
    target = list(origin_raw)
    target[joint_index - 1] += delta_raw
    return JointPlan(stage, key, device, tuple(origin_raw), tuple(target), max_delta_raw)


def build_move_wrapper(plan: JointPlan, target_raw: Sequence[int]) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "command": "movej",
        "joint": list(target_raw),
        "v": 1,
        "r": 0,
        "trajectory_connect": 0,
    }
    if plan.stage == "body":
        payload["device"] = 2
    return {"device": plan.device, "payload": payload}


def build_stop_wrapper(plan: JointPlan) -> dict[str, Any]:
    if plan.stage == "body":
        return {
            "device": 2,
            "payload": {"command": "set_stop_teach", "device": 2, "v": 5, "r": 0},
        }
    return {"device": 1, "payload": {"command": "set_arm_stop"}}


def validate_drive_limits(
    target_raw: Sequence[int], minimum_raw: Sequence[int], maximum_raw: Sequence[int]
) -> None:
    if not (len(target_raw) == len(minimum_raw) == len(maximum_raw)):
        raise RuntimeError("drive limit vector length mismatch")
    for index, (target, minimum, maximum) in enumerate(
        zip(target_raw, minimum_raw, maximum_raw), 1
    ):
        if not minimum <= target <= maximum:
            raise RuntimeError(
                f"joint {index} target {target} is outside live limits [{minimum}, {maximum}]"
            )


def validate_terminal(state: dict[str, Any], arm: str = "right") -> dict[str, Any]:
    key = f"hand_{arm}"
    terminal = state.get(key)
    if not isinstance(terminal, dict):
        raise RuntimeError(f"{key} state missing")
    dof = terminal.get("dof")
    position = terminal.get("position")
    low = terminal.get("pos_low")
    high = terminal.get("pos_up")
    if dof != 1 or not all(isinstance(value, list) and len(value) == 1 for value in (position, low, high)):
        raise RuntimeError("right terminal must be configured as one DOF with one-element bounds")
    if terminal.get("sys_state") != 0:
        raise RuntimeError(f"right terminal sys_state is not zero: {terminal.get('sys_state')!r}")
    if not all(type(value[0]) is int for value in (position, low, high)):
        raise RuntimeError("right terminal positions and bounds must be integers")
    if not low[0] <= position[0] <= high[0]:
        raise RuntimeError("right terminal position is outside reported bounds")
    return {"origin": position[0], "minimum": low[0], "maximum": high[0]}


def choose_terminal_target(origin: int, minimum: int, maximum: int, delta_raw: int) -> int:
    if not 1 <= delta_raw <= 50:
        raise ValueError("terminal delta must be 1-50 raw units")
    if origin + delta_raw <= maximum:
        return origin + delta_raw
    if origin - delta_raw >= minimum:
        return origin - delta_raw
    raise RuntimeError("terminal has no room for the requested bounded displacement")


def build_terminal_wrapper(target_raw: int) -> dict[str, Any]:
    return {"device": 1, "payload": {"command": "hand_follow_pos", "hand_pos": [target_raw]}}


def build_terminal_stop_wrapper() -> dict[str, Any]:
    return {"device": 1, "payload": {"command": "set_rm_plus_ctrl", "mode": 0}}


def response_is_success(response: dict[str, Any]) -> bool:
    if not isinstance(response, dict):
        return False
    if response.get("receive_state") is True or response.get("stop_teach") is True:
        return True
    if isinstance(response.get("min_pos"), list) or isinstance(response.get("max_pos"), list):
        return True
    return any(value is True for value in response.values()) and not any(
        value is False for value in response.values()
    )


class RobotClient:
    def __init__(self) -> None:
        import rclpy
        from rclpy.node import Node
        from rm_robot_interfaces.srv import StringCmd
        from std_msgs.msg import String

        self._rclpy = rclpy
        self._StringCmd = StringCmd
        rclpy.init()
        self.node = Node("sequential_actuator_probe")
        self.client = self.node.create_client(StringCmd, "/robot/command")
        self.latest_state: dict[str, Any] | None = None
        self.sequence = 0

        def callback(message: Any) -> None:
            try:
                state = json.loads(message.data)
            except (json.JSONDecodeError, TypeError):
                return
            if isinstance(state, dict):
                self.latest_state = state
                self.sequence += 1

        self.subscription = self.node.create_subscription(
            String, "/robot_slave/states", callback, 1
        )

    def read_state(self, timeout: float = 3.0) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        initial_sequence = self.sequence
        while time.monotonic() < deadline:
            self._rclpy.spin_once(
                self.node, timeout_sec=max(0.0, min(0.1, deadline - time.monotonic()))
            )
            if self.latest_state is not None and self.sequence > initial_sequence:
                return self.latest_state
        raise TimeoutError("fresh /robot_slave/states timeout")

    def call(self, wrapper: dict[str, Any], timeout: float = 3.0) -> dict[str, Any]:
        if not self.client.wait_for_service(timeout_sec=timeout):
            raise TimeoutError("/robot/command unavailable")
        request = self._StringCmd.Request()
        request.data = json.dumps(wrapper, separators=(",", ":")) + "\r\n"
        future = self.client.call_async(request)
        self._rclpy.spin_until_future_complete(self.node, future, timeout_sec=timeout)
        if not future.done() or future.result() is None:
            raise TimeoutError("/robot/command response timeout")
        response = json.loads(future.result().data)
        if not response_is_success(response):
            raise RuntimeError(f"controller rejected command: {response!r}")
        return response

    def drive_limits(self, device: int, expected: int) -> tuple[tuple[int, ...], tuple[int, ...]]:
        responses = []
        for command in ("get_joint_drive_min_pos", "get_joint_drive_max_pos"):
            wrapper = {"device": device, "payload": {"command": command}}
            if device == 2:
                wrapper["payload"]["device"] = 2
            responses.append(self.call(wrapper))
        minimum = responses[0].get("min_pos")
        maximum = responses[1].get("max_pos")
        if not all(
            isinstance(value, list)
            and len(value) == expected
            and all(
                type(item) in (int, float)
                and math.isfinite(float(item))
                and float(item).is_integer()
                for item in value
            )
            for value in (minimum, maximum)
        ):
            raise RuntimeError("invalid live drive limits")
        return tuple(int(item) for item in minimum), tuple(int(item) for item in maximum)

    def close(self) -> None:
        self.node.destroy_node()
        self._rclpy.shutdown()


def wait_joint_target(
    client: RobotClient, plan: JointPlan, target: Sequence[int], timeout: float = 12.0
) -> tuple[int, ...]:
    deadline = time.monotonic() + timeout
    previous: tuple[int, ...] | None = None
    stable = 0
    while time.monotonic() < deadline:
        state = client.read_state(min(2.0, max(0.1, deadline - time.monotonic())))
        validate_common_state(state)
        current = validate_component(state, plan.state_key, len(target))
        in_target = all(abs(value - desired) <= POSITION_TOLERANCE_RAW for value, desired in zip(current, target))
        settled = previous is not None and all(
            abs(value - prior) <= STABILITY_TOLERANCE_RAW for value, prior in zip(current, previous)
        )
        stable = stable + 1 if in_target and settled else (1 if in_target else 0)
        previous = current
        if stable >= 2:
            return current
    raise TimeoutError(f"{plan.stage} did not reach target {tuple(target)}")


def wait_terminal_target(client: RobotClient, target: int, timeout: float = 5.0) -> int:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        state = client.read_state(min(1.0, max(0.1, deadline - time.monotonic())))
        validate_common_state(state)
        current = validate_terminal(state)["origin"]
        if abs(current - target) <= TERMINAL_TOLERANCE_RAW:
            return current
    raise TimeoutError(f"terminal did not reach target {target}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("right_arm", "body", "terminal"), required=True)
    parser.add_argument("--joint-index", type=int, default=1)
    parser.add_argument("--delta-deg", type=float)
    parser.add_argument("--terminal-delta", type=int, default=50)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--confirm-site-clear", action="store_true")
    parser.add_argument("--confirm-exclusive-control", action="store_true")
    parser.add_argument("--authority-report", type=Path)
    parser.add_argument("--output", type=Path)
    return parser


def validate_execution_gate(args: argparse.Namespace) -> None:
    if not args.execute:
        return
    if not args.confirm_site_clear or not args.confirm_exclusive_control:
        raise ValueError("execution requires site-clear and exclusive-control confirmations")
    if args.authority_report is None:
        raise ValueError("execution requires --authority-report")
    validate_authority_report(args.authority_report)


def run(args: argparse.Namespace) -> dict[str, Any]:
    validate_execution_gate(args)
    client = RobotClient()
    stop_attempted = False
    report: dict[str, Any] = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "stage": args.stage,
        "mode": "LIVE" if args.execute else "DRY_RUN",
        "stop_count": 0,
        "clear_error_count": 0,
    }
    try:
        state = client.read_state()
        validate_common_state(state)
        if args.stage in ("right_arm", "body"):
            expected = 7 if args.stage == "right_arm" else 5
            origin = validate_component(state, "arm_right" if args.stage == "right_arm" else "body", expected)
            if args.delta_deg is None:
                raise ValueError("joint stages require --delta-deg")
            plan = build_joint_plan(args.stage, origin, args.joint_index, args.delta_deg)
            minimum, maximum = client.drive_limits(plan.device, expected)
            validate_drive_limits(plan.target_raw, minimum, maximum)
            validate_drive_limits(plan.origin_raw, minimum, maximum)
            report.update(
                origin_raw=plan.origin_raw,
                target_raw=plan.target_raw,
                drive_min_raw=minimum,
                drive_max_raw=maximum,
            )
            if args.execute:
                report["move_response"] = client.call(build_move_wrapper(plan, plan.target_raw))
                report["reached_raw"] = wait_joint_target(client, plan, plan.target_raw)
                report["recovery_response"] = client.call(build_move_wrapper(plan, plan.origin_raw))
                report["recovered_raw"] = wait_joint_target(client, plan, plan.origin_raw)
                stop_attempted = True
                report["stop_response"] = client.call(build_stop_wrapper(plan))
                report["stop_count"] = 1
                report["final_raw"] = wait_joint_target(client, plan, plan.origin_raw)
        else:
            terminal = validate_terminal(state)
            target = choose_terminal_target(
                terminal["origin"], terminal["minimum"], terminal["maximum"], args.terminal_delta
            )
            report.update(origin_raw=terminal["origin"], target_raw=target, **terminal)
            if args.execute:
                report["move_response"] = client.call(build_terminal_wrapper(target))
                report["reached_raw"] = wait_terminal_target(client, target)
                report["recovery_response"] = client.call(build_terminal_wrapper(terminal["origin"]))
                report["recovered_raw"] = wait_terminal_target(client, terminal["origin"])
                stop_attempted = True
                report["stop_response"] = client.call(build_terminal_stop_wrapper())
                report["stop_count"] = 1
                report["final_raw"] = wait_terminal_target(client, terminal["origin"])
        report["result"] = "PASS"
        return report
    except BaseException:
        if args.execute and not stop_attempted:
            stop_attempted = True
            try:
                if args.stage == "body":
                    client.call({"device": 2, "payload": {"command": "set_stop_teach", "device": 2, "v": 5, "r": 0}})
                elif args.stage == "right_arm":
                    client.call({"device": 1, "payload": {"command": "set_arm_stop"}})
                else:
                    client.call(build_terminal_stop_wrapper())
                report["stop_count"] = 1
            except Exception as stop_error:
                print(f"CRITICAL: software stop failed: {stop_error}; use physical E-stop", file=sys.stderr)
        raise
    finally:
        client.close()


def main() -> int:
    args = build_parser().parse_args()
    try:
        report = run(args)
    except BaseException as exc:
        report = {
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "stage": args.stage,
            "mode": "LIVE" if args.execute else "DRY_RUN",
            "result": "FAIL",
            "error": f"{type(exc).__name__}: {exc}",
        }
        code = 2
    else:
        code = 0
    text = json.dumps(report, ensure_ascii=False, indent=2)
    print(text)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
