# 整机运动控制示例

本目录中的运动示例默认不运动。先完成整机只读检查和控制权门禁，再按具体对象执行。

## 统一控制入口总览

`whole_body_control_demo.py` 读取一次 `/robot_slave/states` 原始 JSON，检查左右臂、腰部、
头部的使能与错误位，按末端工具实时 `dof/pos_low/pos_up` 决定是否生成末端计划，并明确选择
一条底盘速度 Topic：

```bash
python3 examples/03_motion_control/whole_body_control_demo.py \
  --state-json /tmp/realbot-states.json \
  --chassis-topic teleop_cmd_vel \
  --output /tmp/whole-body-plan.json
```

输入文件应是 `/robot_slave/states` 消息 `data` 字段中的原始 JSON 对象。该程序始终为
`PLAN-ONLY`，即使显式增加 `--execute` 也会拒绝执行；它用于让客户先看清每个部件的
`device`、Service wrapper、停止命令和底盘入口。需要实机运动时，按下面的分部示例逐项验证，
不要一次同时驱动整机。

## 头部 / 腰部 ROS2 服务路线

`safe_head_body_control.py` 使用当前实机验证的 `/robot/command` 服务和
`/robot_slave/states` 反馈：

```bash
python3 examples/03_motion_control/safe_head_body_control.py \
  --head-delta-deg 1 0
```

默认只读取当前位置、驱动器限位并输出计划。头部每轴相对变化上限为 3°，速度档固定为
1。腰部当前位置保持可用于只读核对 wrapper：

```bash
python3 examples/03_motion_control/safe_head_body_control.py \
  --body-hold-current
```

实机执行前先在机器人 ROS2 环境生成新的门禁报告：

```bash
python3 examples/07_control_authority_preflight/control_authority_preflight.py \
  --json-output /tmp/control-authority.json
```

只有终端输出 `MOTION_READY=true`，且报告生成时间不超过 120 秒，才能按现场授权增加
`--execute --confirm-site-clear --confirm-exclusive-control --authority-report ...`。腰部当前位置
保持还需要 `--confirm-body-hold-only`。正常机器人拓扑可能存在多个潜在控制发布者；没有
项目级隔离或正式仲裁器时，门禁应返回 false，不能为了运行示例绕过。

程序使用的停止 payload 包含 `device`、`v=5` 和 `r=0`。任何响应超时代表结果未知：
程序只发送一次停止，不重发旧运动目标，不自动清错。

## 右臂、非零腰部与末端工具

`safe_staged_actuator_control.py` 使用同一个 `/robot/command` 与状态反馈闭环，
默认只读取当前值、实时限位并打印计划：

```bash
python3 examples/03_motion_control/safe_staged_actuator_control.py \
  --stage right_arm --joint-index 1 --delta-deg 0.5

python3 examples/03_motion_control/safe_staged_actuator_control.py \
  --stage body --joint-index 5 --delta-deg 0.2

python3 examples/03_motion_control/safe_staged_actuator_control.py \
  --stage terminal --terminal-delta 50
```

公开示例上限固定为右臂单关节 `0.5°`、腰部单关节 `0.2°`。末端程序必须先读取目标设备
实时上报的 `dof`、当前位置和上下限；`dof=0` 时不发送动作。右侧当前单自由度工具已完成
0→250→500→750→1000→0 全量程实机验证，但首次接入仍从当前位置做小步进。所有实机执行
都必须使用 120 秒内的 `MOTION_READY=true` 报告，同时增加
`--execute --confirm-site-clear --confirm-exclusive-control --authority-report ...`。程序只改一个关节
或一个末端位置，精确回到现场采样的起点，不使用预设或历史姿态。

## 头部 REST 路线

`safe_control.py` 是此前验证的 REST 头部小幅、回原示例，默认同样为 dry-run。新项目优先
使用上面的 ROS2 服务示例，以便与头腰现行 wrapper 指令和状态反馈保持一致。

## 底盘

`safe_chassis.py` 默认只输出低速有界计划。`/teleop_cmd_vel` 和 `/cmd_vel` 都使用
`geometry_msgs/msg/Twist`，但前者用于人工控制/遥操作并进入当前平滑链路，后者用于 Nav2
等自动导航；两者不是同义别名，同一时刻只能有一条非零速度来源。底盘实机运动需要独立
授权、机器人身份校验、新鲜里程反馈和持续零速/`StopMotor` 收尾。

## C++

`cpp_motion_client` 只构造头部 wrapper，固定为 `PLAN-ONLY`，不开放实机执行。
