# 客户首次验收一页流程

本页是从代码包零起步执行的顺序入口。先在解压后的 `Realbot1.0-code-examples-V1.2` 目录打开终端；除了明确标注的 SSH 交互登录，以下命令都在本地开发电脑执行。

## 1. 核对交付与设备

- 默认 IP：`192.168.127.10`
- SSH 用户：`realman`
- 基线设备 ED25519 指纹：`SHA256:cd72+nnsg2FEjLuZ0i3GwsdsLarAtxwonXZP3KeogZ0`
- 指纹实机核对日期：`2026-07-17`

指纹必须与设备交付记录一致后才输入 `yes`。若机器人重装系统、更换主控或重生 SSH 密钥，指纹可能合理变更；只能向交付方复核，不能仅因 IP 相同就接受新指纹。密码只在 SSH/SCP 的交互提示中输入，不写入命令、脚本或截图。

macOS/Linux 完整性校验：

```bash
shasum -a 256 -c MANIFEST.sha256
```

Windows PowerShell 完整性校验：

```powershell
Get-Content .\MANIFEST.sha256 | ForEach-Object {
  if ($_ -match '^([0-9a-f]{64})  (.+)$') {
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $Matches[2]).Hash.ToLower()
    if ($actual -ne $Matches[1]) { throw "FAIL: $($Matches[2])" }
  }
}
"PASS: delivery manifest"
```

## 2. 连接与版本

macOS/Linux/WSL 在交付包根目录执行：

```bash
export ROBOT_IP=192.168.127.10
bash examples/01_quick_start/quick_readonly.sh
ssh "realman@${ROBOT_IP}"
```

核对指纹并登录成功后，在机器人 Shell 只执行：

```bash
exit
```

返回客户开发电脑 Shell 后再继续。

## 3. 健康快照

以 SSH 标准输入执行，不在机器人留下脚本副本：

```bash
ssh "realman@${ROBOT_IP}" 'bash -s' \
  < examples/01_quick_start/robot_health_snapshot.sh
echo "health exit=$?"
```

- `PASS` / 退出码 `0`：继续。
- `WARN` / 退出码 `1`：逐项复核。当且仅当唯一警告是已知 `/scan` 无正频率，且当次任务及必需 Topic 不依赖 `/scan` 时，可登记该限制后继续本页录制验收。
- `FAIL` / 退出码 `2`，或出现其他未解释的 `WARN`：停止，不自动重启服务、不修改 QoS、不转动雷达。

## 4. 状态读取

```bash
ssh "realman@${ROBOT_IP}" \
  "bash -lc 'source /opt/ros/humble/setup.bash &&
             source /home/realman/workspace/rm_robot_ws/install/setup.bash &&
             python3 - --timeout 10'" \
  < examples/02_state_reading/read_state.py
echo "state exit=$?"
```

必须读到 `/odom`、电量和 `/robot_slave/states` 三类非空样本，且退出码为 `0`。

## 5. 10 秒录制交付

先看离线计划。下方元数据是示例，客户应替换为自己的英文/数字标识；每项只允许 `A-Z a-z 0-9 . _ -`，长度 1～128，不接受中文或空格。

```bash
python3 examples/04_data_recording/recording_delivery_demo.py \
  --scene demo --task delivery --operator customer01 --device realbot01 \
  --dry-run
```

`--dry-run` 只生成本次计划的 run ID；正式 `--execute` 会生成新的唯一 run ID，不复用计划 ID。确认无其他录制/上传任务，取得写盘授权后执行：

```bash
python3 examples/04_data_recording/recording_delivery_demo.py \
  --scene demo --task delivery --operator customer01 --device realbot01 \
  --duration 10 --minimum-duration 8 --maximum-duration 12 \
  --output ./recording-deliveries \
  --execute --confirm-recording-write
```

从终端首行复制本次正式 run ID，再查看报告：

```bash
export RUN_ID='<本次正式执行输出的run_id>'
python3 -m json.tool "recording-deliveries/${RUN_ID}/report.json"
```

只有 `report.json` 的 `status` 为 `PASS`，远端与本地逐文件 SHA-256 一致，五个必需 `/mcap/*` Topic 均有消息，且包时长在 8～12 秒内，才算交付通过。

默认保留机器人的 `mcap_recorded/<精确目录>`、`mcap_delivery_evidence/<run-id>` 以及 `~/.cache/realbot-recording-demo/<run-id>` 中的 5 个已审核 Python 运行文件；脚本没有删除选项。清理数据必须另行授权。

## 立即停止并保留现场

遇到指纹不符、非独立块设备挂载、剩余空间不足、`mcap_recording` 非空、录制锁已被占用、录制服务不存在、录制状态不可唯一确认、SSH/SCP 中断、哈希不一致、必需 Topic 缺失或时长越界时，不重试 start、不手工挑选近似目录、不删数据，保留终端输出和 run ID 联系技术支持。
